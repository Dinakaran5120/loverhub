import axios from 'axios';
import * as SecureStore from 'expo-secure-store';

const BASE_URL = process.env.EXPO_PUBLIC_API_URL || 'http://localhost:5000/api';

const api = axios.create({ baseURL: BASE_URL, timeout: 30000 });

// Attach token
api.interceptors.request.use(async (config) => {
  const token = await SecureStore.getItemAsync('spark_token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

// Handle 401
api.interceptors.response.use(
  (res) => res,
  async (err) => {
    if (err.response?.status === 401) {
      await SecureStore.deleteItemAsync('spark_token');
    }
    return Promise.reject(err);
  }
);

// ── Auth ───────────────────────────────────────────────────────────────────────
export const authAPI = {
  register: (data: any) => api.post('/auth/register', data),
  login: (email: string, password: string) => api.post('/auth/login', { email, password }),
  logout: () => api.post('/auth/logout'),
  getMe: () => api.get('/auth/me'),
  forgotPassword: (email: string) => api.post('/auth/forgot-password', { email }),
  resetPassword: (token: string, password: string) => api.put(`/auth/reset-password/${token}`, { password }),
  changePassword: (currentPassword: string, newPassword: string) => api.put('/auth/change-password', { currentPassword, newPassword }),
  deleteAccount: (password: string, reason: string) => api.delete('/auth/delete-account', { data: { password, reason } }),
};

// ── Users ──────────────────────────────────────────────────────────────────────
export const userAPI = {
  updateProfile: (data: any) => api.put('/users/profile', data),
  updateSettings: (settings: any) => api.put('/users/settings', settings),
  updateLocation: (lat: number, lng: number, city?: string, country?: string) =>
    api.put('/users/location', { latitude: lat, longitude: lng, city, country }),
  blockUser: (userId: string) => api.post(`/users/block/${userId}`),
  getUser: (userId: string) => api.get(`/users/${userId}`),
};

// ── Swipes / Discovery ─────────────────────────────────────────────────────────
export const swipeAPI = {
  getFeed: () => api.get('/swipes/feed'),
  swipe: (targetId: string, direction: 'like' | 'nope' | 'super') =>
    api.post('/swipes', { targetId, direction }),
  getLikes: () => api.get('/swipes/likes'),
};

// ── Matches ────────────────────────────────────────────────────────────────────
export const matchAPI = {
  getMatches: () => api.get('/matches'),
  unmatch: (matchId: string) => api.delete(`/matches/${matchId}`),
};

// ── Messages ───────────────────────────────────────────────────────────────────
export const messageAPI = {
  getMessages: (matchId: string) => api.get(`/messages/${matchId}`),
  sendMessage: (matchId: string, text?: string, mediaUrl?: string, mediaType?: string) =>
    api.post(`/messages/${matchId}`, { text, mediaUrl, mediaType }),
  deleteMessage: (matchId: string, messageId: string) =>
    api.delete(`/messages/${matchId}/${messageId}`),
};

// ── Posts ──────────────────────────────────────────────────────────────────────
export const postAPI = {
  getPosts: (tab?: string, communityId?: string, page?: number) =>
    api.get('/posts', { params: { tab, communityId, page } }),
  createPost: (data: any) => api.post('/posts', data),
  likePost: (postId: string) => api.put(`/posts/${postId}/like`),
  commentPost: (postId: string, text: string, isAnonymous?: boolean) =>
    api.post(`/posts/${postId}/comment`, { text, isAnonymous }),
  deletePost: (postId: string) => api.delete(`/posts/${postId}`),
};

// ── Communities ────────────────────────────────────────────────────────────────
export const communityAPI = {
  getCommunities: (search?: string, category?: string, page?: number) =>
    api.get('/communities', { params: { search, category, page } }),
  createCommunity: (data: any) => api.post('/communities', data),
  joinCommunity: (id: string, message?: string) => api.post(`/communities/${id}/join`, { message }),
  approveMember: (communityId: string, userId: string) =>
    api.put(`/communities/${communityId}/approve/${userId}`),
  leaveCommunity: (id: string) => api.delete(`/communities/${id}/leave`),
};

// ── Media ──────────────────────────────────────────────────────────────────────
export const mediaAPI = {
  uploadProfilePhoto: async (uri: string) => {
    const form = new FormData();
    form.append('photo', { uri, type: 'image/jpeg', name: 'photo.jpg' } as any);
    return api.post('/media/profile-photo', form, { headers: { 'Content-Type': 'multipart/form-data' } });
  },
  uploadPostMedia: async (uri: string, type: 'image' | 'video') => {
    const form = new FormData();
    form.append('media', { uri, type: type === 'video' ? 'video/mp4' : 'image/jpeg', name: `media.${type === 'video' ? 'mp4' : 'jpg'}` } as any);
    return api.post('/media/post-media', form, { headers: { 'Content-Type': 'multipart/form-data' } });
  },
  uploadChatMedia: async (uri: string, type: 'image' | 'video') => {
    const form = new FormData();
    form.append('media', { uri, type: type === 'video' ? 'video/mp4' : 'image/jpeg', name: `media.${type === 'video' ? 'mp4' : 'jpg'}` } as any);
    return api.post('/media/chat-media', form, { headers: { 'Content-Type': 'multipart/form-data' } });
  },
};

// ── Notifications ──────────────────────────────────────────────────────────────
export const notifAPI = {
  getNotifications: () => api.get('/notifications'),
  markAllRead: () => api.put('/notifications/read-all'),
};

// ── Reports ────────────────────────────────────────────────────────────────────
export const reportAPI = {
  report: (data: any) => api.post('/reports', data),
};

// ── Premium ────────────────────────────────────────────────────────────────────
export const premiumAPI = {
  subscribe: (plan: string, paymentMethodId: string) =>
    api.post('/premium/create-subscription', { plan, paymentMethodId }),
};

export default api;
