const User = require('../models/User');
const { Swipe, Match, Notification } = require('../models/Models');

// ── Get Discovery Feed (Location-based) ───────────────────────────────────────
exports.getDiscoveryFeed = async (req, res, next) => {
  try {
    const me = await User.findById(req.user._id);
    if (!me.location?.coordinates || me.location.coordinates[0] === 0) {
      return res.status(400).json({ success: false, message: 'Location required. Please enable location access.' });
    }

    const maxDist = (me.settings.maxDistance || 50) * 1000; // km -> meters
    const { ageRangeMin, ageRangeMax } = me.settings;

    // Get already swiped user IDs
    const swiped = await Swipe.find({ swiper: me._id }).select('swiped');
    const swipedIds = swiped.map(s => s.swiped);
    swipedIds.push(me._id);

    // Build interest filter
    const genderFilter = me.interestedIn?.length
      ? { gender: { $in: me.interestedIn.map(i => i === 'men' ? 'man' : i === 'women' ? 'woman' : i) } }
      : {};

    const candidates = await User.aggregate([
      {
        $geoNear: {
          near: { type: 'Point', coordinates: me.location.coordinates },
          distanceField: 'distance',
          maxDistance: me.settings.globalMode ? 20000000 : maxDist,
          spherical: true,
          query: {
            _id: { $nin: swipedIds },
            isDeleted: false,
            isBanned: false,
            'settings.discoveryEnabled': true,
            'settings.incognitoMode': false,
            age: { $gte: ageRangeMin || 18, $lte: ageRangeMax || 60 },
            ...genderFilter
          }
        }
      },
      { $limit: 20 },
      {
        $project: {
          name: 1, age: 1, gender: 1, orientation: 1, lookingFor: 1,
          bio: 1, interests: 1, photos: 1, distance: 1,
          isOnline: 1, lastActive: 1, 'settings.showDistance': 1
        }
      }
    ]);

    // Calculate match score
    const scored = candidates.map(c => {
      let score = 0;
      const sharedInterests = (c.interests || []).filter(i => (me.interests || []).includes(i));
      score += sharedInterests.length * 10;
      if (c.lookingFor === me.lookingFor) score += 20;
      if (c.isOnline) score += 15;
      const distKm = (c.distance || 0) / 1000;
      score += Math.max(0, 30 - distKm);
      return { ...c, matchScore: Math.min(99, Math.round(score)), distanceKm: Math.round(distKm) };
    }).sort((a, b) => b.matchScore - a.matchScore);

    res.status(200).json({ success: true, count: scored.length, profiles: scored });
  } catch (err) {
    next(err);
  }
};

// ── Swipe ──────────────────────────────────────────────────────────────────────
exports.swipe = async (req, res, next) => {
  try {
    const { targetId, direction } = req.body;
    const swiperId = req.user._id;
    const me = await User.findById(swiperId);

    if (String(targetId) === String(swiperId)) {
      return res.status(400).json({ success: false, message: "Can't swipe yourself." });
    }

    // Like limit for free users
    if (direction !== 'nope' && !me.canLike()) {
      return res.status(429).json({
        success: false,
        message: 'Daily like limit reached. Upgrade to Spark Gold for unlimited likes!',
        code: 'LIKE_LIMIT_REACHED'
      });
    }

    // Super like limit
    if (direction === 'super') {
      if (me.superLikesRemaining <= 0) {
        return res.status(429).json({
          success: false,
          message: 'No super likes remaining today.',
          code: 'SUPER_LIKE_LIMIT'
        });
      }
      me.superLikesRemaining -= 1;
    }

    // Record swipe
    const existing = await Swipe.findOne({ swiper: swiperId, swiped: targetId });
    if (existing) return res.status(400).json({ success: false, message: 'Already swiped.' });

    await Swipe.create({ swiper: swiperId, swiped: targetId, direction });

    if (direction !== 'nope') {
      me.likesGivenToday += 1;
      me.stats.totalLikes += 1;
    }
    await me.save();

    // Check for mutual like → create match
    let match = null;
    if (direction !== 'nope') {
      const theirLike = await Swipe.findOne({
        swiper: targetId,
        swiped: swiperId,
        direction: { $in: ['like', 'super'] }
      });

      if (theirLike) {
        const existingMatch = await Match.findOne({ users: { $all: [swiperId, targetId] } });
        if (!existingMatch) {
          match = await Match.create({
            users: [swiperId, targetId],
            initiatedBy: swiperId,
            isSuperLike: direction === 'super'
          });

          // Update stats
          await User.updateMany({ _id: { $in: [swiperId, targetId] } }, { $inc: { 'stats.totalMatches': 1 } });

          // Create notification
          await Notification.create({
            recipient: targetId,
            type: 'match',
            title: '🎉 New Match!',
            body: `You matched with ${me.name}!`,
            sender: swiperId,
            data: { matchId: match._id }
          });

          const populatedMatch = await Match.findById(match._id).populate('users', 'name age photos orientation isOnline');
          return res.status(200).json({ success: true, matched: true, match: populatedMatch });
        }
      }

      // If direction is 'like' and no mutual — notify them of the like (premium feature)
      if (direction === 'super') {
        await Notification.create({
          recipient: targetId,
          type: 'super_like',
          title: '⭐ Super Like!',
          body: `${me.name} super liked you!`,
          sender: swiperId
        });
      }
    }

    res.status(200).json({ success: true, matched: false, match: null });
  } catch (err) {
    next(err);
  }
};

// ── Get Matches ────────────────────────────────────────────────────────────────
exports.getMatches = async (req, res, next) => {
  try {
    const matches = await Match.find({
      users: req.user._id,
      isActive: true
    })
    .populate('users', 'name age photos orientation isOnline lastActive')
    .populate('lastMessage')
    .sort({ lastMessageAt: -1, createdAt: -1 });

    const formatted = matches.map(m => ({
      ...m.toObject(),
      otherUser: m.users.find(u => String(u._id) !== String(req.user._id)),
      unread: m.lastMessage && !m.readBy?.includes(req.user._id) ? 1 : 0
    }));

    res.status(200).json({ success: true, matches: formatted });
  } catch (err) {
    next(err);
  }
};

// ── Unmatch ────────────────────────────────────────────────────────────────────
exports.unmatch = async (req, res, next) => {
  try {
    const match = await Match.findOne({ _id: req.params.matchId, users: req.user._id });
    if (!match) return res.status(404).json({ success: false, message: 'Match not found.' });

    match.isActive = false;
    match.unmatchedBy = req.user._id;
    await match.save();

    res.status(200).json({ success: true, message: 'Unmatched.' });
  } catch (err) {
    next(err);
  }
};

// ── Who Liked Me (Premium) ─────────────────────────────────────────────────────
exports.getLikes = async (req, res, next) => {
  try {
    const me = await User.findById(req.user._id);
    if (!me.premium.isActive) {
      return res.status(403).json({
        success: false,
        message: 'Upgrade to Spark Gold to see who liked you.',
        code: 'PREMIUM_REQUIRED'
      });
    }

    const likes = await Swipe.find({ swiped: req.user._id, direction: { $in: ['like', 'super'] } })
      .populate('swiper', 'name age photos orientation distance')
      .sort({ createdAt: -1 })
      .limit(50);

    res.status(200).json({ success: true, likes: likes.map(l => l.swiper) });
  } catch (err) {
    next(err);
  }
};
