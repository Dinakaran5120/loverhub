import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Colors, Spacing, Radius } from '../utils/theme';
import { PrideBar } from '../components/SharedComponents';

const TERMS = [
  {
    title: '1. Eligibility',
    icon: '✅',
    content: `You must be at least 18 years old to use Spark. By creating an account, you confirm that:
• You are 18 years of age or older
• You are legally permitted to use online dating services in your jurisdiction
• You have not been convicted of a felony or registered as a sex offender
• You will maintain only one active account
• You are a human — no bots or automated accounts permitted`,
  },
  {
    title: '2. Account Responsibilities',
    icon: '👤',
    content: `You are responsible for:
• Maintaining the confidentiality of your login credentials
• All activity that occurs under your account
• Ensuring your profile information is accurate and up to date
• Notifying us immediately of any unauthorized use of your account

You agree not to share your account with others or allow others to access your account.`,
  },
  {
    title: '3. Prohibited Conduct',
    icon: '🚫',
    content: `You agree NOT to:
• Post false, misleading, or fraudulent information
• Harass, bully, stalk, or threaten other users
• Share explicit content without consent
• Use Spark for commercial solicitation or advertising
• Attempt to scrape, hack, or reverse-engineer the platform
• Impersonate another person or entity
• Use the app while operating a motor vehicle
• Create multiple accounts after being banned
• Solicit money from other users

Violation of these rules may result in immediate account termination.`,
  },
  {
    title: '4. Content Guidelines',
    icon: '📸',
    content: `All content you post must comply with our Community Guidelines:
• No nudity or sexually explicit content in profile photos
• No hate speech, discrimination, or content targeting protected groups
• No content that promotes violence or self-harm
• No spam or repetitive content
• Photos must be of you — no celebrity photos or group shots as main photo
• No images of minors, even with adults present

We reserve the right to remove any content that violates these guidelines.`,
  },
  {
    title: '5. Premium Subscriptions',
    icon: '💎',
    content: `Spark Gold and Spark Platinum subscriptions:
• Are billed monthly or annually as selected
• Automatically renew unless cancelled at least 24 hours before the renewal date
• Are non-refundable except where required by law
• Can be managed and cancelled through your device's App Store settings (iOS) or Google Play (Android)
• Pricing is subject to change with 30 days notice

Features included in premium tiers are subject to change. We will notify you of significant feature removals.`,
  },
  {
    title: '6. Intellectual Property',
    icon: '©️',
    content: `Spark owns all rights to the app, its design, features, and underlying technology. You retain ownership of content you post, but grant us a worldwide, royalty-free license to use, display, and distribute your content within the platform.

You agree not to copy, modify, or distribute any part of our platform without written permission.`,
  },
  {
    title: '7. Disclaimer & Limitation of Liability',
    icon: '⚖️',
    content: `Spark is provided "as is" without warranties of any kind. We do not guarantee:
• That you will find a match or relationship
• That other users' representations are accurate
• Uninterrupted or error-free service

To the maximum extent permitted by law, Spark shall not be liable for indirect, incidental, special, or consequential damages arising from your use of the service.

PLEASE EXERCISE CAUTION when meeting people from online platforms in person. Always meet in public places and inform someone of your plans.`,
  },
  {
    title: '8. Termination',
    icon: '🚪',
    content: `We reserve the right to suspend or terminate your account at any time for violations of these Terms. You may also delete your account at any time from Settings.

Upon termination:
• Your profile will be immediately deactivated
• Access to matches and messages will be removed
• Premium benefits will not be refunded for remaining subscription period
• Data retention follows our Privacy Policy`,
  },
  {
    title: '9. Governing Law',
    icon: '🌐',
    content: `These Terms are governed by the laws of [Your Jurisdiction]. Any disputes shall be resolved through binding arbitration, except for claims that may be brought in small claims court.

You waive the right to participate in class action lawsuits against Spark.

If any provision of these Terms is found unenforceable, the remaining provisions will remain in full effect.`,
  },
  {
    title: '10. Contact',
    icon: '📬',
    content: `For questions about these Terms of Service:
• Email: legal@sparkdating.app
• Trust & Safety: safety@sparkdating.app
• General Support: support@sparkdating.app

Last updated: April 2026`,
  },
];

export default function TermsOfServiceScreen({ navigation }: any) {
  const [expanded, setExpanded] = useState<number | null>(0);

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <PrideBar />
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
          <Text style={{ fontSize: 22, color: Colors.text }}>←</Text>
        </TouchableOpacity>
        <Text style={styles.title}>Terms of Service</Text>
        <View style={{ width: 40 }} />
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ padding: 16 }}>
        <View style={styles.heroBanner}>
          <Text style={styles.heroEmoji}>📜</Text>
          <Text style={styles.heroTitle}>Our Terms of Service</Text>
          <Text style={styles.heroSub}>
            Please read these terms carefully before using Spark. By creating an account,
            you agree to be bound by these terms.
          </Text>
        </View>

        {TERMS.map((section, index) => (
          <TouchableOpacity
            key={index}
            style={[styles.section, expanded === index && styles.sectionExpanded]}
            onPress={() => setExpanded(expanded === index ? null : index)}
            activeOpacity={0.85}
          >
            <View style={styles.sectionHeader}>
              <View style={styles.sectionHeaderLeft}>
                <Text style={styles.sectionIcon}>{section.icon}</Text>
                <Text style={styles.sectionTitle}>{section.title}</Text>
              </View>
              <Text style={[styles.chevron, expanded === index && styles.chevronOpen]}>›</Text>
            </View>
            {expanded === index && (
              <Text style={styles.sectionContent}>{section.content}</Text>
            )}
          </TouchableOpacity>
        ))}

        <View style={styles.footer}>
          <Text style={styles.footerText}>
            These Terms of Service constitute the entire agreement between you and Spark
            regarding the use of our services.
          </Text>
        </View>
        <View style={{ height: 32 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.bg },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: Spacing.xl, paddingVertical: Spacing.md },
  backBtn: { width: 40, height: 40, alignItems: 'center', justifyContent: 'center' },
  title: { fontSize: 18, fontWeight: '900', color: Colors.text },
  heroBanner: { backgroundColor: Colors.bg3, borderRadius: Radius.xl, padding: 20, alignItems: 'center', marginBottom: 16, borderWidth: 1, borderColor: Colors.border },
  heroEmoji: { fontSize: 44, marginBottom: 10 },
  heroTitle: { fontSize: 20, fontWeight: '900', color: Colors.text, marginBottom: 8, textAlign: 'center' },
  heroSub: { fontSize: 13, color: Colors.text2, textAlign: 'center', lineHeight: 20 },
  section: { backgroundColor: Colors.bg2, borderRadius: Radius.xl, marginBottom: 10, overflow: 'hidden', borderWidth: 1, borderColor: Colors.border },
  sectionExpanded: { borderColor: Colors.accent },
  sectionHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 16 },
  sectionHeaderLeft: { flexDirection: 'row', alignItems: 'center', gap: 10, flex: 1 },
  sectionIcon: { fontSize: 20 },
  sectionTitle: { fontSize: 14, fontWeight: '800', color: Colors.text, flex: 1 },
  chevron: { fontSize: 22, color: Colors.text3 },
  chevronOpen: { transform: [{ rotate: '90deg' }], color: Colors.accent },
  sectionContent: { fontSize: 13, color: Colors.text2, lineHeight: 22, padding: 16, paddingTop: 0 },
  footer: { backgroundColor: Colors.bg3, borderRadius: Radius.xl, padding: 20, marginTop: 8, borderWidth: 1, borderColor: Colors.border },
  footerText: { fontSize: 12, color: Colors.text2, lineHeight: 20, textAlign: 'center' },
});
