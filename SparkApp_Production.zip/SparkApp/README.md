# ✦ Spark Dating App — Production Ready

A fully inclusive dating app for both straight and LGBTQ+ users. Built with **Expo SDK 54 + React Native** (frontend) and **Node.js + Express + MongoDB** (backend). Ready to submit to the App Store and Google Play.

---

## 🏗️ Project Structure

```
SparkApp/
├── frontend/          ← Expo React Native app
│   ├── App.tsx
│   ├── app.json
│   ├── eas.json       ← App Store build config
│   └── src/
│       ├── screens/
│       │   ├── AuthScreens.tsx         ← Login, Register, Forgot Password
│       │   ├── DiscoverScreen.tsx      ← Tinder-style swipe + location matching
│       │   ├── MatchesScreen.tsx       ← Matches grid + real-time chat
│       │   ├── ExploreScreen.tsx       ← Feed, Reels, Moods, Trending + upload
│       │   ├── CommunitiesScreen.tsx   ← Public/private communities + join logic
│       │   ├── ProfileScreen.tsx       ← Full profile + settings + delete account
│       │   ├── PrivacyPolicyScreen.tsx ← Full GDPR-compliant privacy policy
│       │   ├── TermsOfServiceScreen.tsx
│       │   └── HelpCenterScreen.tsx    ← Searchable FAQ + contact support
│       ├── navigation/
│       │   └── RootNavigator.tsx       ← Auth guard + tab + stack navigation
│       ├── store/
│       │   └── authStore.ts            ← Zustand store with SecureStore
│       ├── services/
│       │   └── api.ts                  ← Axios API layer for all endpoints
│       └── utils/
│           └── theme.ts                ← Colors, spacing, radius
│
└── backend/           ← Node.js/Express API
    ├── src/
    │   ├── server.js             ← Express + Socket.io server
    │   ├── models/
    │   │   ├── User.js           ← User schema (auth, profile, location, premium)
    │   │   └── Models.js         ← Swipe, Match, Message, Post, Community, etc.
    │   ├── controllers/
    │   │   ├── authController.js  ← Register, login, logout, delete account
    │   │   ├── swipeController.js ← Location-based feed + swipe + match logic
    │   │   └── mediaController.js ← Cloudinary upload for photos/videos/reels
    │   ├── routes/               ← All API routes
    │   └── middleware/
    │       └── auth.js           ← JWT protect middleware
    └── .env.example
```

---

## 🚀 Quick Start (Local Development)

### 1. Backend Setup

```bash
cd SparkApp/backend
npm install
cp .env.example .env
# Fill in all values in .env (MongoDB URI, Cloudinary, etc.)
npm run dev
# API runs at http://localhost:5000
```

**Required services to set up:**
- **MongoDB Atlas** (free tier): https://cloud.mongodb.com
- **Cloudinary** (free tier for photos/videos): https://cloudinary.com
- **Stripe** (for premium): https://stripe.com

### 2. Frontend Setup

```bash
cd SparkApp/frontend
npm install
# Create .env file
echo "EXPO_PUBLIC_API_URL=http://localhost:5000/api" > .env

npx expo start
# Press 'i' for iOS simulator, 'a' for Android emulator
# Or scan QR code with Expo Go app
```

---

## 📱 App Features

### 🔥 Core Dating (Tinder-style)
- Gesture-based swipe cards (drag left/right/up for super like)
- **Location-based matching** using MongoDB 2dsphere geospatial queries
- Match score calculation (shared interests, relationship goal, online status, distance)
- Match popup with confetti animation
- Undo last swipe (free: 1/day, Gold: unlimited)
- Daily like limit (free: 100/day, Gold: unlimited)
- Recently Active profiles section
- Profile boost feature
- Discovery filters: gender, orientation, age range, distance, relationship goal
- Global Mode (see people worldwide)

### 💬 Matches & Messaging
- Matches grid with compatibility percentage
- Real-time chat via Socket.io
- Message read receipts
- Media sharing in chat (photos/videos via Cloudinary)
- Typing indicators
- Unmatch functionality

### ✦ Explore
- **Global Feed** — text, image, video posts
- **Image upload** from gallery or camera → Cloudinary
- **Reel/Video upload** from gallery or camera → Cloudinary with thumbnail
- Like / Comment / Vibe reactions (Relate, Hot take, Mood, Hugs)
- Anonymous posting toggle
- Mood sharing system with anonymous mood feed
- **Reels viewer** with swipe-style navigation
- Trending hashtags
- Pull-to-refresh

### 👥 Communities
- Public communities — instant join
- Private communities — join request → owner approval
- Create community with emoji, description, rules, public/private
- Community feed with posts
- Search & filter by category (LGBTQ+, Dating, Lifestyle, etc.)

### 👤 Profile
- Photo upload + management (Cloudinary)
- Edit name, bio, orientation, interests, looking-for
- Profile stats (matches, likes, interests)
- **Settings**: notifications, incognito mode, online status
- **Spark Premium** (Gold / Platinum via Stripe)

### 🔐 Auth & Safety
- Email registration with verification link
- JWT authentication stored in Expo SecureStore
- Forgot password / reset password via email
- Block user
- Report user/post
- **Delete Account** (soft-delete, permanently purged in 30 days)
- **Log Out**
- Age verification (18+ only)

### 📋 Legal
- Full **Privacy Policy** (GDPR/CCPA compliant, LGBTQ+ specific protections)
- Full **Terms of Service**
- **Help Center** with 30+ searchable FAQs across 6 categories
- Contact support links (email)

---

## 🌐 Backend API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/auth/register` | Create account |
| POST | `/api/auth/login` | Login |
| POST | `/api/auth/logout` | Logout |
| GET | `/api/auth/me` | Get current user |
| DELETE | `/api/auth/delete-account` | Delete account |
| PUT | `/api/auth/change-password` | Change password |
| GET | `/api/swipes/feed` | Location-based discovery feed |
| POST | `/api/swipes` | Swipe (like/nope/super) |
| GET | `/api/matches` | Get all matches |
| DELETE | `/api/matches/:id` | Unmatch |
| GET | `/api/messages/:matchId` | Get messages |
| POST | `/api/messages/:matchId` | Send message |
| GET | `/api/posts` | Get explore posts |
| POST | `/api/posts` | Create post |
| PUT | `/api/posts/:id/like` | Like/unlike post |
| GET | `/api/communities` | Get communities |
| POST | `/api/communities` | Create community |
| POST | `/api/communities/:id/join` | Join/request community |
| POST | `/api/media/profile-photo` | Upload profile photo |
| POST | `/api/media/post-media` | Upload post image/video |
| POST | `/api/reports` | Report user/post |
| GET | `/api/notifications` | Get notifications |
| POST | `/api/premium/create-subscription` | Stripe subscription |

---

## 📦 App Store Submission

### Prerequisites
1. Apple Developer Account ($99/year) — https://developer.apple.com
2. Google Play Developer Account ($25 one-time) — https://play.google.com/console
3. EAS CLI: `npm install -g eas-cli`

### Build & Submit to App Store (iOS)

```bash
cd frontend

# Login to Expo
eas login

# Configure project (first time)
eas build:configure

# Build for iOS production
eas build --platform ios --profile production

# Submit to App Store Connect
eas submit --platform ios --profile production
```

### Build & Submit to Google Play (Android)

```bash
# Build Android App Bundle
eas build --platform android --profile production

# Submit to Google Play internal track
eas submit --platform android --profile production
```

### App Store Connect Requirements
Before submitting, prepare:
- [ ] App icon (1024×1024 PNG, no alpha)
- [ ] Screenshots for iPhone 6.5" and 5.5" displays
- [ ] App description (see below template)
- [ ] Privacy Policy URL: `https://sparkdating.app/privacy`
- [ ] Age rating: 17+ (Dating apps)
- [ ] Categories: Lifestyle > Dating

### App Store Description Template
```
✦ Spark — Dating for Everyone

Find real connections with Spark, the inclusive dating app for straight, gay, lesbian, bisexual, pansexual, queer, and non-binary people.

🔥 SWIPE & MATCH
• Tinder-style swiping with location-based matching
• Smart match scores based on shared interests
• Super Likes to stand out
• See who's recently active near you

💬 CONNECT
• Real-time messaging with your matches
• Share photos and videos in chat
• Know when your message is read

✦ EXPLORE COMMUNITY
• Post thoughts, photos, and short videos (Reels)
• Anonymous mood sharing
• Like, comment, and send vibes
• Trending topics in the dating community

👥 COMMUNITIES
• Join public or private communities
• Connect with like-minded people
• LGBTQ+ safe spaces

🏳️‍🌈 INCLUSIVE BY DESIGN
• All orientations welcome
• Gender-inclusive options
• LGBTQ+ community spaces built-in
• Anonymous posting for safe expression

💎 SPARK PREMIUM
• Unlimited likes
• See who liked you
• Incognito mode
• Global mode — match worldwide

Download Spark and find your person today. 💜
```

---

## 🗄️ Database Indexes

Ensure these MongoDB indexes exist for optimal performance:

```javascript
// Run in MongoDB Shell or Atlas UI
db.users.createIndex({ location: "2dsphere" })
db.users.createIndex({ age: 1, gender: 1, orientation: 1 })
db.swipes.createIndex({ swiper: 1, swiped: 1 }, { unique: true })
db.matches.createIndex({ users: 1 })
db.posts.createIndex({ isPublic: 1, isDeleted: 1, createdAt: -1 })
db.notifications.createIndex({ recipient: 1, createdAt: -1 })
```

---

## 🔒 Security Checklist

Before going live:
- [ ] Set strong `JWT_SECRET` in production .env
- [ ] Enable MongoDB Atlas IP Whitelist
- [ ] Set CORS origin to your actual domain
- [ ] Enable Cloudinary signed uploads
- [ ] Configure Stripe webhook signature verification
- [ ] Set up SSL certificate for your API domain
- [ ] Enable rate limiting (already configured)
- [ ] Set up automated database backups in MongoDB Atlas
- [ ] Configure Firebase for push notifications

---

## 📧 Support Contacts

Configure these email addresses:
- `support@sparkdating.app` — General support
- `privacy@sparkdating.app` — Privacy/GDPR requests
- `safety@sparkdating.app` — Safety/abuse reports
- `legal@sparkdating.app` — Legal inquiries

---

Built with 💜 for everyone — straight, gay, lesbian, bisexual, pansexual, queer, non-binary, and beyond.
