import { Colors } from "@constants/theme";
import type { Conversation, ChatMessage, ChatParticipant } from "@/types/connections";

export const ME_ID = "me";

export const PARTICIPANTS: Record<string, ChatParticipant> = {
  arjun:  { id: "u1", name: "Arjun",   avatarEmoji: "😊", gradient: [Colors.secondary, Colors.rose]  as [string,string], online: true,  lastSeen: new Date().toISOString(),                          verified: true  },
  priya:  { id: "u2", name: "Priya",   avatarEmoji: "🥰", gradient: [Colors.violet, Colors.sky]      as [string,string], online: true,  lastSeen: new Date().toISOString(),                          verified: true  },
  dev:    { id: "u3", name: "Dev",     avatarEmoji: "😎", gradient: [Colors.primary, Colors.accent]  as [string,string], online: false, lastSeen: new Date(Date.now()-25*60000).toISOString(),        verified: true  },
  zara:   { id: "u4", name: "Zara",    avatarEmoji: "🌈", gradient: [Colors.accent, Colors.gold]     as [string,string], online: true,  lastSeen: new Date().toISOString(),                          verified: false },
  riya:   { id: "u5", name: "Riya",    avatarEmoji: "💫", gradient: [Colors.rose, Colors.violet]     as [string,string], online: false, lastSeen: new Date(Date.now()-2*3600000).toISOString(),       verified: true  },
  karan:  { id: "u6", name: "Karan",   avatarEmoji: "🏏", gradient: [Colors.sky, Colors.mint]        as [string,string], online: true,  lastSeen: new Date().toISOString(),                          verified: true  },
  morgan: { id: "u7", name: "Morgan",  avatarEmoji: "✨", gradient: [Colors.gold, Colors.accent]     as [string,string], online: false, lastSeen: new Date(Date.now()-3*86400000).toISOString(),      verified: false },
};

const t = (minsAgo: number) => new Date(Date.now() - minsAgo * 60000).toISOString();

export const MOCK_CONVERSATIONS: Conversation[] = [
  {
    id: "conv_1", type: "direct",
    participants: [PARTICIPANTS.arjun],
    lastMessage: "Hey! Are you free this weekend? 😊",
    lastMessageTime: t(2), lastSenderId: "u1",
    unreadCount: 3, isTyping: false, isPinned: true, isMuted: false,
  },
  {
    id: "conv_2", type: "direct",
    participants: [PARTICIPANTS.priya],
    lastMessage: "That photo you posted was stunning 🔥",
    lastMessageTime: t(14), lastSenderId: "u2",
    unreadCount: 0, isTyping: true, isPinned: false, isMuted: false,
  },
  {
    id: "conv_3", type: "direct",
    participants: [PARTICIPANTS.dev],
    lastMessage: "Lmao yes exactly!! 😂",
    lastMessageTime: t(60), lastSenderId: "me",
    unreadCount: 1, isTyping: false, isPinned: false, isMuted: false,
  },
  {
    id: "conv_4", type: "direct",
    participants: [PARTICIPANTS.zara],
    lastMessage: "ok so i found this amazing spot 🌅",
    lastMessageTime: t(3*60), lastSenderId: "u4",
    unreadCount: 2, isTyping: false, isPinned: false, isMuted: false,
  },
  {
    id: "conv_5", type: "direct",
    participants: [PARTICIPANTS.riya],
    lastMessage: "Sent you a voice note 🎤",
    lastMessageTime: t(180), lastSenderId: "u5",
    unreadCount: 0, isTyping: false, isPinned: false, isMuted: false,
  },
  {
    id: "conv_6", type: "direct",
    participants: [PARTICIPANTS.morgan],
    lastMessage: "Thanks for the rec! ✨",
    lastMessageTime: t(3*24*60), lastSenderId: "me",
    unreadCount: 0, isTyping: false, isPinned: false, isMuted: false,
  },
  // Group chats
  {
    id: "conv_g1", type: "group",
    participants: [PARTICIPANTS.arjun, PARTICIPANTS.priya, PARTICIPANTS.dev, PARTICIPANTS.zara],
    groupName: "Mumbai Singles Meetup 🌆",
    groupEmoji: "🌆",
    groupGradient: [Colors.primary, Colors.accent],
    groupAdminId: "u1",
    lastMessage: "Arjun: See you all Saturday! 🎉",
    lastMessageTime: t(30), lastSenderId: "u1",
    unreadCount: 5, isTyping: false, isPinned: true, isMuted: false,
  },
  {
    id: "conv_g2", type: "group",
    participants: [PARTICIPANTS.zara, PARTICIPANTS.karan, PARTICIPANTS.riya],
    groupName: "Queer Crew 🌈",
    groupEmoji: "🌈",
    groupGradient: [Colors.violet, Colors.rose],
    groupAdminId: "u4",
    lastMessage: "Karan: Pride parade this Sunday? 🏳️‍🌈",
    lastMessageTime: t(90), lastSenderId: "u6",
    unreadCount: 0, isTyping: false, isPinned: false, isMuted: false,
  },
];

// Pre-seeded messages per conversation
export const MOCK_MESSAGES: Record<string, ChatMessage[]> = {
  conv_1: [
    { id: "m1", conversationId: "conv_1", senderId: "u1", type: "text", text: "Hey there! Matched with you earlier 😊", reactions: [], status: "read", createdAt: t(120), deletedForMe: false },
    { id: "m2", conversationId: "conv_1", senderId: "me", type: "text", text: "Hi Arjun! Yeah I saw, exciting 🎉", reactions: [{ emoji: "❤️", count: 1, reactedByMe: false }], status: "read", createdAt: t(115), deletedForMe: false },
    { id: "m3", conversationId: "conv_1", senderId: "u1", type: "text", text: "So I was thinking — there's this amazing café in Bandra called Prithvi. Have you been? ☕", reactions: [], status: "read", createdAt: t(110), deletedForMe: false },
    { id: "m4", conversationId: "conv_1", senderId: "me", type: "text", text: "Oh yes! Love that place. The cold brew is unreal.", reactions: [], status: "read", createdAt: t(95), deletedForMe: false },
    { id: "m5", conversationId: "conv_1", senderId: "u1", type: "audio", text: "Voice note", audioDuration: "0:24", reactions: [], status: "read", createdAt: t(80), deletedForMe: false },
    { id: "m6", conversationId: "conv_1", senderId: "me", type: "text", text: "Haha okay that's a yes from me 😂", reactions: [], status: "read", createdAt: t(75), deletedForMe: false },
    { id: "m7", conversationId: "conv_1", senderId: "u1", type: "text", text: "Hey! Are you free this weekend? 😊", reactions: [], status: "delivered", createdAt: t(2), deletedForMe: false },
  ],
  conv_2: [
    { id: "m10", conversationId: "conv_2", senderId: "u2", type: "text", text: "Hi! I saw your profile and loved your travel pics ✈️", reactions: [], status: "read", createdAt: t(60), deletedForMe: false },
    { id: "m11", conversationId: "conv_2", senderId: "me", type: "text", text: "Thank you! 22 countries and counting 😅", reactions: [{ emoji: "😮", count: 1, reactedByMe: false }], status: "read", createdAt: t(55), deletedForMe: false },
    { id: "m12", conversationId: "conv_2", senderId: "u2", type: "text", text: "That photo you posted was stunning 🔥", reactions: [], status: "read", createdAt: t(14), deletedForMe: false },
  ],
  conv_g1: [
    { id: "mg1", conversationId: "conv_g1", senderId: "u1", type: "system", text: "Arjun created the group 🎉", reactions: [], status: "read", createdAt: t(2880), deletedForMe: false },
    { id: "mg2", conversationId: "conv_g1", senderId: "u1", type: "text", text: "Hey everyone! This is the group for our Saturday meetup at Social, Bandra 🙌", reactions: [], status: "read", createdAt: t(2870), deletedForMe: false },
    { id: "mg3", conversationId: "conv_g1", senderId: "u2", type: "text", text: "So excited!! What time are we meeting?", reactions: [], status: "read", createdAt: t(2860), deletedForMe: false },
    { id: "mg4", conversationId: "conv_g1", senderId: "u1", type: "text", text: "7pm sharp! Make sure to look for the Lovrhub table 😂", reactions: [{ emoji: "😂", count: 3, reactedByMe: true }], status: "read", createdAt: t(2850), deletedForMe: false },
    { id: "mg5", conversationId: "conv_g1", senderId: "me", type: "text", text: "Can't wait! Do we need to RSVP anywhere?", reactions: [], status: "read", createdAt: t(2800), deletedForMe: false },
    { id: "mg6", conversationId: "conv_g1", senderId: "u4", type: "text", text: "No just show up! The more the merrier 🌈", reactions: [], status: "read", createdAt: t(2790), deletedForMe: false },
    { id: "mg7", conversationId: "conv_g1", senderId: "u3", type: "audio", text: "Voice note", audioDuration: "0:42", reactions: [], status: "read", createdAt: t(60), deletedForMe: false },
    { id: "mg8", conversationId: "conv_g1", senderId: "u1", type: "text", text: "See you all Saturday! 🎉", reactions: [], status: "delivered", createdAt: t(30), deletedForMe: false },
  ],
  conv_g2: [
    { id: "mg10", conversationId: "conv_g2", senderId: "u4", type: "text", text: "Hey crew 🌈 Planning something for pride this Sunday", reactions: [], status: "read", createdAt: t(300), deletedForMe: false },
    { id: "mg11", conversationId: "conv_g2", senderId: "u5", type: "text", text: "Omg YES. Where are we gathering?", reactions: [], status: "read", createdAt: t(290), deletedForMe: false },
    { id: "mg12", conversationId: "conv_g2", senderId: "u6", type: "text", text: "Pride parade this Sunday? 🏳️‍🌈", reactions: [{ emoji: "❤️", count: 2, reactedByMe: false }], status: "read", createdAt: t(90), deletedForMe: false },
  ],
};
