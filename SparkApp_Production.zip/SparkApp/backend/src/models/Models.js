const mongoose = require('mongoose');

// ── Swipe Model ────────────────────────────────────────────────────────────────
const SwipeSchema = new mongoose.Schema({
  swiper: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  swiped: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  direction: { type: String, enum: ['like', 'nope', 'super'], required: true },
  isRead: { type: Boolean, default: false }
}, { timestamps: true });

SwipeSchema.index({ swiper: 1, swiped: 1 }, { unique: true });
SwipeSchema.index({ swiped: 1, direction: 1 });
const Swipe = mongoose.model('Swipe', SwipeSchema);

// ── Match Model ────────────────────────────────────────────────────────────────
const MatchSchema = new mongoose.Schema({
  users: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true }],
  initiatedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  isSuperLike: { type: Boolean, default: false },
  lastMessage: { type: mongoose.Schema.Types.ObjectId, ref: 'Message' },
  lastMessageAt: Date,
  unmatchedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  isActive: { type: Boolean, default: true },
  readBy: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }]
}, { timestamps: true });

MatchSchema.index({ users: 1 });
MatchSchema.index({ lastMessageAt: -1 });
const Match = mongoose.model('Match', MatchSchema);

// ── Message Model ──────────────────────────────────────────────────────────────
const MessageSchema = new mongoose.Schema({
  match: { type: mongoose.Schema.Types.ObjectId, ref: 'Match', required: true },
  sender: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  text: { type: String, maxlength: 2000 },
  mediaUrl: String,
  mediaType: { type: String, enum: ['image', 'video', 'gif', 'audio'] },
  mediaPublicId: String,
  isDeleted: { type: Boolean, default: false },
  readBy: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
  reactions: [{
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    emoji: String
  }]
}, { timestamps: true });

MessageSchema.index({ match: 1, createdAt: -1 });
const Message = mongoose.model('Message', MessageSchema);

// ── Post Model ─────────────────────────────────────────────────────────────────
const PostSchema = new mongoose.Schema({
  author: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  community: { type: mongoose.Schema.Types.ObjectId, ref: 'Community' }, // null = global
  type: { type: String, enum: ['text', 'image', 'video', 'reel', 'mood'], required: true },
  content: { type: String, maxlength: 1000 },
  mediaUrl: String,
  mediaPublicId: String,
  thumbnailUrl: String,
  mood: String,
  isAnonymous: { type: Boolean, default: false },
  isPublic: { type: Boolean, default: true },
  tags: [String],
  likes: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
  vibes: [{
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    type: { type: String, enum: ['relate', 'hottake', 'mood', 'hugs', 'true', 'lol'] }
  }],
  comments: [{
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    text: { type: String, maxlength: 500 },
    isAnonymous: { type: Boolean, default: false },
    createdAt: { type: Date, default: Date.now }
  }],
  views: { type: Number, default: 0 },
  isDeleted: { type: Boolean, default: false },
  reportCount: { type: Number, default: 0 }
}, { timestamps: true });

PostSchema.index({ community: 1, createdAt: -1 });
PostSchema.index({ isPublic: 1, isDeleted: 1, createdAt: -1 });
PostSchema.index({ tags: 1 });
const Post = mongoose.model('Post', PostSchema);

// ── Community Model ────────────────────────────────────────────────────────────
const CommunitySchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true, maxlength: 100 },
  slug: { type: String, unique: true, lowercase: true },
  description: { type: String, maxlength: 500 },
  emoji: { type: String, default: '✨' },
  coverImage: String,
  coverImagePublicId: String,
  category: { type: String, enum: ['dating', 'lgbtq', 'lifestyle', 'hobbies', 'support', 'wellness', 'other'], default: 'other' },
  isPublic: { type: Boolean, default: true },
  owner: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  admins: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
  members: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
  pendingRequests: [{
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    requestedAt: { type: Date, default: Date.now },
    message: String
  }],
  rules: [{ type: String, maxlength: 200 }],
  isDeleted: { type: Boolean, default: false },
  memberCount: { type: Number, default: 0 },
  postCount: { type: Number, default: 0 }
}, { timestamps: true });

CommunitySchema.index({ slug: 1 });
CommunitySchema.index({ category: 1, memberCount: -1 });
const Community = mongoose.model('Community', CommunitySchema);

// ── Report Model ───────────────────────────────────────────────────────────────
const ReportSchema = new mongoose.Schema({
  reporter: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  reportedUser: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  reportedPost: { type: mongoose.Schema.Types.ObjectId, ref: 'Post' },
  reason: { type: String, enum: ['inappropriate', 'harassment', 'spam', 'fake', 'underage', 'violence', 'other'], required: true },
  description: { type: String, maxlength: 500 },
  status: { type: String, enum: ['pending', 'reviewed', 'actioned', 'dismissed'], default: 'pending' }
}, { timestamps: true });

const Report = mongoose.model('Report', ReportSchema);

// ── Notification Model ─────────────────────────────────────────────────────────
const NotificationSchema = new mongoose.Schema({
  recipient: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  type: { type: String, enum: ['match', 'message', 'like', 'super_like', 'community_join', 'community_post', 'boost'], required: true },
  title: String,
  body: String,
  data: mongoose.Schema.Types.Mixed,
  isRead: { type: Boolean, default: false },
  sender: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }
}, { timestamps: true });

NotificationSchema.index({ recipient: 1, isRead: 1, createdAt: -1 });
const Notification = mongoose.model('Notification', NotificationSchema);

module.exports = { Swipe, Match, Message, Post, Community, Report, Notification };
