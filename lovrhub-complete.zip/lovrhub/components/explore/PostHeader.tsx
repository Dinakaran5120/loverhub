import { View, Text, Pressable } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { Colors } from "@constants/theme";
import { useTimeAgo } from "@/hooks/useExploreFeed";
import type { ExplorePost } from "@/types/explore";

export function PostHeader({ post }: { post: ExplorePost }) {
  const ago = useTimeAgo(post.createdAt);
  const { author } = post;

  return (
    <View
      style={{
        flexDirection: "row",
        alignItems: "center",
        paddingHorizontal: 16,
        paddingVertical: 12,
        gap: 10,
      }}
    >
      {/* Avatar */}
      <LinearGradient
        colors={author.gradient}
        start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
        style={{ width: 42, height: 42, borderRadius: 21, alignItems: "center", justifyContent: "center" }}
      >
        <Text style={{ fontSize: 20 }}>
          {author.isAnonymous ? "👤" : author.avatarEmoji}
        </Text>
      </LinearGradient>

      {/* Name + meta */}
      <View style={{ flex: 1, gap: 2 }}>
        <View style={{ flexDirection: "row", alignItems: "center", gap: 6 }}>
          <Text style={{ fontSize: 14, fontWeight: "700", color: Colors.text }}>
            {author.isAnonymous ? "Anonymous" : author.name}
          </Text>
          {author.verified && (
            <View
              style={{
                width: 16, height: 16, borderRadius: 8,
                backgroundColor: "#3b82f6",
                alignItems: "center", justifyContent: "center",
              }}
            >
              <Text style={{ color: "#fff", fontSize: 9, fontWeight: "800" }}>✓</Text>
            </View>
          )}
          {author.isAnonymous && (
            <View
              style={{
                paddingHorizontal: 7, paddingVertical: 2,
                borderRadius: 8, backgroundColor: Colors.card,
                borderWidth: 1, borderColor: Colors.border,
              }}
            >
              <Text style={{ fontSize: 10, color: Colors.textMuted, fontWeight: "600" }}>anon</Text>
            </View>
          )}
          {post.isTrending && (
            <View
              style={{
                paddingHorizontal: 7, paddingVertical: 2,
                borderRadius: 8, backgroundColor: Colors.primary + "18",
                borderWidth: 1, borderColor: Colors.primary + "44",
              }}
            >
              <Text style={{ fontSize: 10, color: Colors.primary, fontWeight: "700" }}>🔥 trending</Text>
            </View>
          )}
        </View>
        <View style={{ flexDirection: "row", alignItems: "center", gap: 6 }}>
          <Text style={{ fontSize: 12, color: Colors.textMuted }}>{ago}</Text>
          {post.location && (
            <>
              <Text style={{ fontSize: 10, color: Colors.border }}>·</Text>
              <Text style={{ fontSize: 12, color: Colors.textMuted }}>📍 {post.location}</Text>
            </>
          )}
        </View>
      </View>

      {/* More */}
      <Pressable
        style={({ pressed }) => ({
          width: 32, height: 32, borderRadius: 16,
          backgroundColor: Colors.card, alignItems: "center", justifyContent: "center",
          opacity: pressed ? 0.6 : 1,
        })}
      >
        <Text style={{ fontSize: 16, color: Colors.textMuted }}>•••</Text>
      </Pressable>
    </View>
  );
}
