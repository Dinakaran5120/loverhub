import React, { useState, useRef, useCallback } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  TextInput, Modal, FlatList, ActivityIndicator,
  Dimensions, Alert, RefreshControl,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Image } from 'expo-image';
import * as ImagePicker from 'expo-image-picker';
import * as Haptics from 'expo-haptics';
import { LinearGradient } from 'expo-linear-gradient';
import { Colors, Spacing, Radius } from '../utils/theme';
import { postAPI, mediaAPI } from '../services/api';
import { useAuthStore } from '../store/authStore';
import { PrimaryButton, SecondaryButton, PrideBar, OrientationBadge } from '../components/SharedComponents';

const { width: W, height: H } = Dimensions.get('window');

const MOODS = [
  { emoji: '💫', label: 'Dreamy' }, { emoji: '🔥', label: 'Flirty' },
  { emoji: '😌', label: 'Chill' }, { emoji: '🌈', label: 'Pride' },
  { emoji: '💔', label: 'Healing' }, { emoji: '⚡', label: 'Hyped' },
  { emoji: '🌙', label: 'Dreaming' }, { emoji: '☕', label: 'Cozy' },
];
const VIBES = ['💙 Relate', '🔥 Hot take', '✨ Mood', '🫂 Hugs', '💯 True', '😂 Lol'];

// ── Post Card ─────────────────────────────────────────────────────────────────
const PostCard = ({ post, onLike, onComment }: any) => {
  const [vibed, setVibed] = useState<string | null>(null);
  const [showComments, setShowComments] = useState(false);
  const [commentText, setCommentText] = useState('');

  return (
    <View style={styles.postCard}>
      <View style={styles.postHeader}>
        <View style={styles.postAvatar}>
          {post.author?.photos?.[0]?.url
            ? <Image source={{ uri: post.author.photos[0].url }} style={styles.postAvatarImg} />
            : <Text style={{ fontSize: 20 }}>{post.isAnonymous ? '👤' : '😊'}</Text>}
        </View>
        <View style={{ flex: 1 }}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, flexWrap: 'wrap' }}>
            <Text style={styles.postAuthor}>
              {post.isAnonymous ? 'Anonymous' : `${post.author?.name}, ${post.author?.age}`}
            </Text>
            {post.isAnonymous && <View style={styles.anonBadge}><Text style={styles.anonText}>anon</Text></View>}
            {!post.isAnonymous && post.author?.orientation && (
              <OrientationBadge orientation={post.author.orientation} />
            )}
          </View>
          <Text style={styles.postMeta}>{post.timeAgo || 'Just now'}{post.mood ? ` • ${post.mood}` : ''}</Text>
        </View>
        <TouchableOpacity><Text style={{ fontSize: 18, color: Colors.text3 }}>⋯</Text></TouchableOpacity>
      </View>

      {/* Image post */}
      {(post.type === 'image') && post.mediaUrl && (
        <Image source={{ uri: post.mediaUrl }} style={styles.postImage} contentFit="cover" />
      )}

      {/* Video / Reel post */}
      {(post.type === 'video' || post.type === 'reel') && (
        <TouchableOpacity style={styles.postVideoArea} onPress={() => Alert.alert('▶ Playing reel...')}>
          {post.thumbnailUrl
            ? <Image source={{ uri: post.thumbnailUrl }} style={StyleSheet.absoluteFill} contentFit="cover" />
            : <Text style={{ fontSize: 56 }}>🎬</Text>}
          <View style={styles.playBtn}><Text style={{ fontSize: 22 }}>▶</Text></View>
          <View style={styles.reelBadge}><Text style={styles.reelBadgeText}>REEL</Text></View>
        </TouchableOpacity>
      )}

      {post.content ? <Text style={styles.postText}>{post.content}</Text> : null}

      {/* Vibes */}
      <ScrollView horizontal showsHorizontalScrollIndicator={false}>
        <View style={styles.vibeRow}>
          {VIBES.map((v) => (
            <TouchableOpacity key={v}
              style={[styles.vibeChip, vibed === v && styles.vibeChipActive]}
              onPress={() => { setVibed(vibed === v ? null : v); Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); }}>
              <Text style={[styles.vibeChipText, vibed === v && styles.vibeChipTextActive]}>{v}</Text>
            </TouchableOpacity>
          ))}
        </View>
      </ScrollView>

      {/* Actions */}
      <View style={styles.postActions}>
        <TouchableOpacity style={styles.postAction} onPress={() => { onLike(post._id); Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium); }}>
          <Text style={{ fontSize: 16, color: post.liked ? Colors.pink : Colors.text2 }}>
            {post.liked ? '♥' : '♡'}
          </Text>
          <Text style={[styles.postActionText, post.liked && { color: Colors.pink }]}>{post.likeCount || post.likes?.length || 0}</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.postAction} onPress={() => setShowComments(!showComments)}>
          <Text style={{ fontSize: 16, color: Colors.text2 }}>💬</Text>
          <Text style={styles.postActionText}>{post.comments?.length || 0}</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.postAction}>
          <Text style={{ fontSize: 16, color: Colors.text2 }}>↗</Text>
          <Text style={styles.postActionText}>Share</Text>
        </TouchableOpacity>
      </View>

      {/* Comments section */}
      {showComments && (
        <View style={styles.commentsSection}>
          {(post.comments || []).slice(0, 3).map((c: any, i: number) => (
            <View key={i} style={styles.commentRow}>
              <Text style={styles.commentAuthor}>{c.isAnonymous ? 'Anon' : c.user?.name || 'User'}</Text>
              <Text style={styles.commentText}>{c.text}</Text>
            </View>
          ))}
          <View style={styles.commentInputRow}>
            <TextInput
              style={styles.commentInput}
              value={commentText}
              onChangeText={setCommentText}
              placeholder="Add a comment..."
              placeholderTextColor={Colors.text3}
            />
            <TouchableOpacity
              style={[styles.commentSend, !commentText.trim() && { opacity: 0.4 }]}
              onPress={() => { onComment(post._id, commentText); setCommentText(''); }}
              disabled={!commentText.trim()}>
              <Text style={{ fontSize: 16 }}>↑</Text>
            </TouchableOpacity>
          </View>
        </View>
      )}
    </View>
  );
};

// ── Create Post Modal ─────────────────────────────────────────────────────────
const CreatePostModal = ({ visible, onClose, onCreated }: any) => {
  const { user } = useAuthStore();
  const [postType, setPostType] = useState<'text' | 'image' | 'video' | 'reel'>('text');
  const [content, setContent] = useState('');
  const [mood, setMood] = useState('');
  const [isAnon, setIsAnon] = useState(false);
  const [mediaUri, setMediaUri] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const [uploadedUrl, setUploadedUrl] = useState<string | null>(null);
  const [uploadedThumb, setUploadedThumb] = useState<string | null>(null);

  const pickMedia = async (type: 'image' | 'video') => {
    const perm = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!perm.granted) { Alert.alert('Permission needed', 'Allow photo access to upload media.'); return; }

    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: type === 'image' ? ImagePicker.MediaTypeOptions.Images : ImagePicker.MediaTypeOptions.Videos,
      quality: 0.85,
      allowsEditing: true,
      aspect: type === 'image' ? [1, 1] : [9, 16],
    });

    if (!result.canceled && result.assets[0]) {
      const uri = result.assets[0].uri;
      setMediaUri(uri);
      setUploading(true);
      try {
        const res = await mediaAPI.uploadPostMedia(uri, type);
        setUploadedUrl(res.data.url);
        setUploadedThumb(res.data.thumbnailUrl);
      } catch {
        Alert.alert('Upload failed', 'Could not upload media. Please try again.');
        setMediaUri(null);
      } finally {
        setUploading(false);
      }
    }
  };

  const takeCameraMedia = async (type: 'image' | 'video') => {
    const perm = await ImagePicker.requestCameraPermissionsAsync();
    if (!perm.granted) { Alert.alert('Permission needed', 'Allow camera access.'); return; }

    const result = await ImagePicker.launchCameraAsync({
      mediaTypes: type === 'image' ? ImagePicker.MediaTypeOptions.Images : ImagePicker.MediaTypeOptions.Videos,
      quality: 0.85,
      allowsEditing: true,
    });

    if (!result.canceled && result.assets[0]) {
      const uri = result.assets[0].uri;
      setMediaUri(uri);
      setUploading(true);
      try {
        const res = await mediaAPI.uploadPostMedia(uri, type);
        setUploadedUrl(res.data.url);
        setUploadedThumb(res.data.thumbnailUrl);
      } catch {
        Alert.alert('Upload failed', 'Please try again.');
        setMediaUri(null);
      } finally { setUploading(false); }
    }
  };

  const handlePost = async () => {
    if (!content.trim() && !uploadedUrl) return;
    setUploading(true);
    try {
      const finalType = postType === 'reel' ? 'reel' : postType;
      await postAPI.createPost({
        type: finalType,
        content: content.trim(),
        mediaUrl: uploadedUrl,
        thumbnailUrl: uploadedThumb,
        mood: mood || undefined,
        isAnonymous: isAnon,
      });
      onCreated();
      setContent(''); setMood(''); setMediaUri(null); setUploadedUrl(null); setIsAnon(false);
      onClose();
    } catch {
      Alert.alert('Error', 'Failed to post. Please try again.');
    } finally { setUploading(false); }
  };

  const resetMedia = () => { setMediaUri(null); setUploadedUrl(null); setUploadedThumb(null); };

  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
      <View style={styles.modalOverlay}>
        <View style={styles.modalSheet}>
          <View style={styles.modalHandle} />
          <Text style={styles.modalTitle}>Create Post</Text>
          <ScrollView showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">
            {/* Post type selector */}
            <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 16 }}>
              <View style={{ flexDirection: 'row', gap: 8 }}>
                {[
                  { id: 'text', label: '✏️ Text' },
                  { id: 'image', label: '📸 Photo' },
                  { id: 'video', label: '🎬 Video' },
                  { id: 'reel', label: '🎵 Reel' },
                ].map((t) => (
                  <TouchableOpacity key={t.id}
                    style={[styles.typeBtn, postType === t.id && styles.typeBtnActive]}
                    onPress={() => { setPostType(t.id as any); resetMedia(); }}>
                    <Text style={[styles.typeBtnText, postType === t.id && styles.typeBtnTextActive]}>{t.label}</Text>
                  </TouchableOpacity>
                ))}
              </View>
            </ScrollView>

            {/* Media picker area */}
            {(postType === 'image' || postType === 'video' || postType === 'reel') && (
              <View style={{ marginBottom: 16 }}>
                {mediaUri ? (
                  <View style={styles.mediaPreview}>
                    {postType === 'image'
                      ? <Image source={{ uri: mediaUri }} style={styles.mediaPreviewImg} contentFit="cover" />
                      : <View style={styles.videoPreview}>
                          {uploadedThumb ? <Image source={{ uri: uploadedThumb }} style={StyleSheet.absoluteFill} contentFit="cover" /> : null}
                          <Text style={{ fontSize: 40 }}>🎬</Text>
                          <Text style={{ color: '#fff', fontSize: 12, marginTop: 8 }}>Video selected</Text>
                        </View>}
                    {uploading && (
                      <View style={styles.uploadingOverlay}>
                        <ActivityIndicator color={Colors.accent} size="large" />
                        <Text style={{ color: '#fff', marginTop: 8, fontSize: 13 }}>Uploading...</Text>
                      </View>
                    )}
                    <TouchableOpacity style={styles.removeMediaBtn} onPress={resetMedia}>
                      <Text style={{ color: '#fff', fontSize: 16 }}>✕</Text>
                    </TouchableOpacity>
                  </View>
                ) : (
                  <View style={styles.mediaPicker}>
                    <TouchableOpacity style={styles.mediaPickerBtn}
                      onPress={() => pickMedia(postType === 'image' ? 'image' : 'video')}>
                      <Text style={{ fontSize: 28 }}>{postType === 'image' ? '🖼️' : '📹'}</Text>
                      <Text style={styles.mediaPickerText}>Choose from Library</Text>
                    </TouchableOpacity>
                    <View style={styles.mediaPickerDivider} />
                    <TouchableOpacity style={styles.mediaPickerBtn}
                      onPress={() => takeCameraMedia(postType === 'image' ? 'image' : 'video')}>
                      <Text style={{ fontSize: 28 }}>📷</Text>
                      <Text style={styles.mediaPickerText}>Use Camera</Text>
                    </TouchableOpacity>
                  </View>
                )}
              </View>
            )}

            {/* Caption */}
            <Text style={styles.formLabel}>
              {postType === 'text' ? "What's on your mind?" : 'Caption (optional)'}
            </Text>
            <TextInput
              style={styles.formTextarea}
              value={content}
              onChangeText={setContent}
              placeholder={postType === 'text' ? 'Share a thought, story or feeling...' : 'Add a caption...'}
              placeholderTextColor={Colors.text3}
              multiline numberOfLines={4}
              textAlignVertical="top"
            />

            {/* Mood tag */}
            <Text style={styles.formLabel}>Mood tag</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 16 }}>
              <View style={{ flexDirection: 'row', gap: 8 }}>
                {MOODS.map((m) => (
                  <TouchableOpacity key={m.label}
                    style={[styles.moodChip, mood === m.label && styles.moodChipActive]}
                    onPress={() => setMood(mood === m.label ? '' : m.label)}>
                    <Text style={[styles.moodChipText, mood === m.label && styles.moodChipTextActive]}>
                      {m.emoji} {m.label}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>
            </ScrollView>

            {/* Post as */}
            <Text style={styles.formLabel}>Post as</Text>
            <View style={{ flexDirection: 'row', gap: 10, marginBottom: 20 }}>
              {[{ val: false, label: '👤 My Name' }, { val: true, label: '🕶️ Anonymous' }].map((o) => (
                <TouchableOpacity key={String(o.val)}
                  style={[styles.optChip, isAnon === o.val && styles.optChipActive]}
                  onPress={() => setIsAnon(o.val)}>
                  <Text style={[isAnon === o.val ? styles.optChipTextActive : styles.optChipText]}>{o.label}</Text>
                </TouchableOpacity>
              ))}
            </View>

            <PrimaryButton
              label={uploading ? 'Posting...' : 'Publish Post'}
              onPress={handlePost}
              disabled={(!content.trim() && !uploadedUrl) || uploading}
              loading={uploading}
            />
            <View style={{ height: 8 }} />
            <SecondaryButton label="Cancel" onPress={onClose} />
            <View style={{ height: 32 }} />
          </ScrollView>
        </View>
      </View>
    </Modal>
  );
};

// ── Reels Viewer ──────────────────────────────────────────────────────────────
const ReelsViewer = ({ posts }: { posts: any[] }) => {
  const reelPosts = posts.filter(p => p.type === 'video' || p.type === 'reel');
  const [index, setIndex] = useState(0);

  if (!reelPosts.length) {
    return (
      <View style={styles.emptyReels}>
        <Text style={{ fontSize: 56 }}>🎬</Text>
        <Text style={styles.emptyReelsText}>No reels yet</Text>
        <Text style={styles.emptyReelsSub}>Be the first to share a reel!</Text>
      </View>
    );
  }

  const reel = reelPosts[index];

  return (
    <View style={styles.reelContainer}>
      {/* Progress bars */}
      <View style={styles.reelProgressBar}>
        {reelPosts.map((_, i) => (
          <View key={i} style={[styles.reelProg, { opacity: i === index ? 1 : 0.3 }]}>
            <View style={[styles.reelProgFill, { width: i < index ? '100%' : i === index ? '50%' : '0%' }]} />
          </View>
        ))}
      </View>

      {/* Video placeholder / thumbnail */}
      <TouchableOpacity style={styles.reelVideo} onPress={() => Alert.alert('▶ Playing reel', reel.content || '')}>
        {reel.thumbnailUrl
          ? <Image source={{ uri: reel.thumbnailUrl }} style={StyleSheet.absoluteFill} contentFit="cover" />
          : <View style={[StyleSheet.absoluteFill, { backgroundColor: '#111', alignItems: 'center', justifyContent: 'center' }]}>
              <Text style={{ fontSize: 80 }}>🎬</Text>
            </View>}
        <View style={styles.playOverlay}><Text style={{ fontSize: 30 }}>▶</Text></View>
      </TouchableOpacity>

      {/* Info overlay */}
      <LinearGradient colors={['transparent', 'rgba(0,0,0,0.9)']} style={styles.reelInfoGrad}>
        <View style={styles.reelInfo}>
          <Text style={styles.reelUser}>
            {reel.isAnonymous ? '@anonymous' : `@${reel.author?.name?.toLowerCase().replace(' ', '_')}`}
          </Text>
          {reel.content && <Text style={styles.reelCaption} numberOfLines={2}>{reel.content}</Text>}
          {reel.mood && <Text style={{ fontSize: 13, color: Colors.accent, marginTop: 4 }}>{reel.mood}</Text>}
        </View>
      </LinearGradient>

      {/* Side actions */}
      <View style={styles.reelActions}>
        <TouchableOpacity style={styles.reelActionBtn}>
          <Text style={{ fontSize: 24 }}>♡</Text>
          <Text style={styles.reelActionCount}>{reel.likeCount || 0}</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.reelActionBtn}>
          <Text style={{ fontSize: 24 }}>💬</Text>
          <Text style={styles.reelActionCount}>{reel.comments?.length || 0}</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.reelActionBtn}>
          <Text style={{ fontSize: 24 }}>↗</Text>
          <Text style={styles.reelActionCount}>Share</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.reelActionBtn}>
          <Text style={{ fontSize: 24 }}>✦</Text>
          <Text style={styles.reelActionCount}>Vibe</Text>
        </TouchableOpacity>
      </View>

      {/* Navigation */}
      <View style={styles.reelNavBtns}>
        <TouchableOpacity
          style={[styles.reelNavBtn, index === 0 && { opacity: 0.3 }]}
          onPress={() => setIndex(i => Math.max(0, i - 1))} disabled={index === 0}>
          <Text style={styles.reelNavText}>← Prev</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.reelNavBtn, index === reelPosts.length - 1 && { opacity: 0.3 }]}
          onPress={() => setIndex(i => Math.min(reelPosts.length - 1, i + 1))}
          disabled={index === reelPosts.length - 1}>
          <Text style={styles.reelNavText}>Next →</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

// ── Main Screen ───────────────────────────────────────────────────────────────
export default function ExploreScreen() {
  const [activeTab, setActiveTab] = useState('feed');
  const [posts, setPosts] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [createVisible, setCreateVisible] = useState(false);
  const [selectedMood, setSelectedMood] = useState<string | null>(null);

  const loadPosts = useCallback(async (tab = activeTab) => {
    setLoading(true);
    try {
      const res = await postAPI.getPosts(tab);
      setPosts(res.data.posts || []);
    } catch {
      // fallback to empty
    } finally { setLoading(false); }
  }, [activeTab]);

  React.useEffect(() => { loadPosts(); }, []);

  const handleLike = async (postId: string) => {
    try {
      const res = await postAPI.likePost(postId);
      setPosts(prev => prev.map(p => p._id === postId ? { ...p, liked: res.data.liked, likeCount: res.data.likeCount } : p));
    } catch {}
  };

  const handleComment = async (postId: string, text: string) => {
    try {
      await postAPI.commentPost(postId, text);
      setPosts(prev => prev.map(p => p._id === postId ? { ...p, comments: [...(p.comments || []), { text, user: null }] } : p));
    } catch {}
  };

  const TABS = [
    { id: 'feed', label: '🌍 Global' },
    { id: 'moods', label: '😊 Moods' },
    { id: 'reels', label: '🎬 Reels' },
    { id: 'trending', label: '🔥 Trending' },
  ];

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <PrideBar />
      <View style={styles.header}>
        <Text style={styles.title}>Explore ✦</Text>
        <TouchableOpacity style={styles.createBtn} onPress={() => setCreateVisible(true)}>
          <Text style={styles.createBtnText}>+ Post</Text>
        </TouchableOpacity>
      </View>

      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.tabsScroll}>
        <View style={{ flexDirection: 'row', gap: 8, paddingHorizontal: 16, paddingBottom: 8 }}>
          {TABS.map((tab) => (
            <TouchableOpacity key={tab.id}
              style={[styles.tab, activeTab === tab.id && styles.tabActive]}
              onPress={() => { setActiveTab(tab.id); loadPosts(tab.id); }}>
              <Text style={[styles.tabText, activeTab === tab.id && styles.tabTextActive]}>{tab.label}</Text>
            </TouchableOpacity>
          ))}
        </View>
      </ScrollView>

      {/* FEED */}
      {activeTab === 'feed' && (
        <ScrollView showsVerticalScrollIndicator={false}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); loadPosts().finally(() => setRefreshing(false)); }} tintColor={Colors.accent} />}>
          {/* Mood banner */}
          <View style={styles.moodBanner}>
            <Text style={styles.moodBannerTitle}>SHARE YOUR MOOD</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false}>
              <View style={{ flexDirection: 'row', gap: 8 }}>
                {MOODS.map((m) => (
                  <TouchableOpacity key={m.label}
                    style={[styles.moodChip, selectedMood === m.label && styles.moodChipActive]}
                    onPress={() => setSelectedMood(selectedMood === m.label ? null : m.label)}>
                    <Text style={[styles.moodChipText, selectedMood === m.label && styles.moodChipTextActive]}>
                      {m.emoji} {m.label}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>
            </ScrollView>
          </View>
          {loading && !refreshing ? (
            <ActivityIndicator color={Colors.accent} style={{ marginTop: 32 }} />
          ) : posts.length === 0 ? (
            <View style={{ alignItems: 'center', padding: 48 }}>
              <Text style={{ fontSize: 48 }}>🌍</Text>
              <Text style={{ color: Colors.text2, marginTop: 12 }}>No posts yet. Be the first!</Text>
            </View>
          ) : (
            posts.map((post) => <PostCard key={post._id} post={post} onLike={handleLike} onComment={handleComment} />)
          )}
          <View style={{ height: 20 }} />
        </ScrollView>
      )}

      {/* MOODS */}
      {activeTab === 'moods' && (
        <ScrollView style={{ padding: 16 }}>
          <Text style={styles.tabSectionTitle}>Anonymous Mood Feed</Text>
          <View style={styles.moodGrid}>
            {MOODS.map((m) => (
              <TouchableOpacity key={m.label}
                style={[styles.moodCard, selectedMood === m.label && styles.moodCardActive]}
                onPress={() => setSelectedMood(selectedMood === m.label ? null : m.label)}>
                <Text style={{ fontSize: 32, marginBottom: 6 }}>{m.emoji}</Text>
                <Text style={styles.moodCardLabel}>{m.label}</Text>
                <View style={styles.moodBar}>
                  <View style={[styles.moodBarFill, { width: `${Math.min(100, Math.random() * 80 + 20)}%` }]} />
                </View>
              </TouchableOpacity>
            ))}
          </View>
          <View style={{ height: 24 }} />
        </ScrollView>
      )}

      {/* REELS */}
      {activeTab === 'reels' && <ReelsViewer posts={posts} />}

      {/* TRENDING */}
      {activeTab === 'trending' && (
        <ScrollView style={{ padding: 16 }}>
          <Text style={styles.tabSectionTitle}>🔥 Trending Now</Text>
          {['#FirstDateVibes', '#PrideAndDating', '#ChillAndConnect', '#QueerLove', '#AuthenticSelf', '#SparkMoment'].map((tag, i) => (
            <View key={tag} style={styles.trendCard}>
              <Text style={styles.trendRank}>{i + 1}</Text>
              <View style={{ flex: 1 }}>
                <Text style={styles.trendTag}>{tag}</Text>
                <Text style={styles.trendCount}>{Math.floor(Math.random() * 4000 + 500)} posts today</Text>
              </View>
              <TouchableOpacity style={styles.trendBtn}>
                <Text style={styles.trendBtnText}>Explore</Text>
              </TouchableOpacity>
            </View>
          ))}
          <View style={{ height: 24 }} />
        </ScrollView>
      )}

      <CreatePostModal visible={createVisible} onClose={() => setCreateVisible(false)} onCreated={() => loadPosts()} />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.bg },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: Spacing.xl, paddingVertical: Spacing.md },
  title: { fontSize: 22, fontWeight: '900', color: Colors.text },
  createBtn: { backgroundColor: Colors.accent, paddingHorizontal: 16, paddingVertical: 8, borderRadius: Radius.md },
  createBtnText: { color: '#000', fontSize: 13, fontWeight: '800' },
  tabsScroll: { flexGrow: 0, marginBottom: 4 },
  tab: { paddingHorizontal: 16, paddingVertical: 8, borderRadius: Radius.full, backgroundColor: Colors.bg3 },
  tabActive: { backgroundColor: Colors.accent },
  tabText: { fontSize: 13, fontWeight: '700', color: Colors.text2 },
  tabTextActive: { color: '#000' },
  moodBanner: { marginHorizontal: 16, marginBottom: 16, backgroundColor: Colors.bg3, borderRadius: Radius.xl, padding: 16, borderWidth: 1, borderColor: Colors.border },
  moodBannerTitle: { fontSize: 11, fontWeight: '800', color: Colors.text2, letterSpacing: 0.5, marginBottom: 10 },
  moodChip: { paddingHorizontal: 14, paddingVertical: 7, borderRadius: Radius.full, borderWidth: 1.5, borderColor: Colors.border },
  moodChipActive: { borderColor: Colors.accent, backgroundColor: 'rgba(232,255,71,0.1)' },
  moodChipText: { fontSize: 13, fontWeight: '700', color: Colors.text2 },
  moodChipTextActive: { color: Colors.accent },
  postCard: { backgroundColor: Colors.bg2, borderRadius: Radius.xl, marginHorizontal: 16, marginBottom: 16, overflow: 'hidden', borderWidth: 1, borderColor: Colors.border },
  postHeader: { flexDirection: 'row', alignItems: 'center', gap: 10, padding: 14 },
  postAvatar: { width: 42, height: 42, borderRadius: 21, backgroundColor: Colors.bg4, alignItems: 'center', justifyContent: 'center', overflow: 'hidden' },
  postAvatarImg: { width: 42, height: 42, borderRadius: 21 },
  postAuthor: { fontSize: 14, fontWeight: '800', color: Colors.text },
  postMeta: { fontSize: 12, color: Colors.text2, marginTop: 2 },
  anonBadge: { backgroundColor: Colors.bg4, paddingHorizontal: 8, paddingVertical: 2, borderRadius: Radius.full },
  anonText: { fontSize: 10, color: Colors.text2 },
  postImage: { width: '100%', height: 300 },
  postVideoArea: { width: '100%', height: 280, backgroundColor: '#000', alignItems: 'center', justifyContent: 'center' },
  playBtn: { position: 'absolute', width: 64, height: 64, borderRadius: 32, backgroundColor: 'rgba(0,0,0,0.6)', alignItems: 'center', justifyContent: 'center' },
  reelBadge: { position: 'absolute', top: 12, right: 12, backgroundColor: Colors.pink, paddingHorizontal: 8, paddingVertical: 3, borderRadius: 8 },
  reelBadgeText: { fontSize: 10, fontWeight: '900', color: '#fff' },
  postText: { paddingHorizontal: 14, paddingVertical: 10, fontSize: 14, color: '#e0e0e8', lineHeight: 22 },
  vibeRow: { flexDirection: 'row', gap: 8, paddingHorizontal: 14, paddingVertical: 10, borderTopWidth: 1, borderTopColor: Colors.border },
  vibeChip: { paddingHorizontal: 12, paddingVertical: 6, borderRadius: Radius.full, backgroundColor: Colors.bg4 },
  vibeChipActive: { backgroundColor: Colors.accent },
  vibeChipText: { fontSize: 12, fontWeight: '700', color: Colors.text2 },
  vibeChipTextActive: { color: '#000' },
  postActions: { flexDirection: 'row', paddingHorizontal: 14, paddingVertical: 10, borderTopWidth: 1, borderTopColor: Colors.border },
  postAction: { flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 10, paddingVertical: 6 },
  postActionText: { fontSize: 13, color: Colors.text2, fontWeight: '600' },
  commentsSection: { borderTopWidth: 1, borderTopColor: Colors.border, padding: 12 },
  commentRow: { marginBottom: 8 },
  commentAuthor: { fontSize: 12, fontWeight: '800', color: Colors.text, marginBottom: 2 },
  commentText: { fontSize: 13, color: Colors.text2 },
  commentInputRow: { flexDirection: 'row', alignItems: 'center', gap: 8, marginTop: 8 },
  commentInput: { flex: 1, backgroundColor: Colors.bg3, borderRadius: Radius.full, paddingHorizontal: 14, paddingVertical: 8, color: Colors.text, fontSize: 13, borderWidth: 1, borderColor: Colors.border },
  commentSend: { width: 34, height: 34, borderRadius: 17, backgroundColor: Colors.pink, alignItems: 'center', justifyContent: 'center' },
  // Moods tab
  tabSectionTitle: { fontSize: 15, fontWeight: '800', color: Colors.text, marginBottom: 14 },
  moodGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
  moodCard: { width: '47%', backgroundColor: Colors.bg3, borderRadius: Radius.xl, padding: 16, borderWidth: 1.5, borderColor: Colors.border, alignItems: 'flex-start' },
  moodCardActive: { borderColor: Colors.accent, backgroundColor: 'rgba(232,255,71,0.05)' },
  moodCardLabel: { fontSize: 14, fontWeight: '800', color: Colors.text, marginBottom: 8 },
  moodBar: { width: '100%', height: 4, backgroundColor: Colors.bg4, borderRadius: 2, overflow: 'hidden' },
  moodBarFill: { height: '100%', backgroundColor: Colors.accent, borderRadius: 2 },
  // Reels
  reelContainer: { flex: 1, backgroundColor: '#000' },
  reelProgressBar: { flexDirection: 'row', gap: 4, position: 'absolute', top: 16, left: 16, right: 16, zIndex: 10 },
  reelProg: { flex: 1, height: 2, borderRadius: 1, backgroundColor: 'rgba(255,255,255,0.3)', overflow: 'hidden' },
  reelProgFill: { height: '100%', backgroundColor: '#fff' },
  reelVideo: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  playOverlay: { position: 'absolute', width: 70, height: 70, borderRadius: 35, backgroundColor: 'rgba(0,0,0,0.5)', alignItems: 'center', justifyContent: 'center' },
  reelInfoGrad: { position: 'absolute', bottom: 80, left: 0, right: 60, height: 160, justifyContent: 'flex-end' },
  reelInfo: { padding: 16 },
  reelUser: { fontSize: 15, fontWeight: '800', color: '#fff', marginBottom: 4 },
  reelCaption: { fontSize: 13, color: '#ddd', lineHeight: 20 },
  reelActions: { position: 'absolute', right: 12, bottom: 100, gap: 20 },
  reelActionBtn: { alignItems: 'center', gap: 4 },
  reelActionCount: { fontSize: 12, fontWeight: '700', color: '#fff' },
  reelNavBtns: { position: 'absolute', bottom: 20, left: 0, right: 0, flexDirection: 'row', justifyContent: 'space-around', paddingHorizontal: 24 },
  reelNavBtn: { backgroundColor: 'rgba(255,255,255,0.15)', paddingHorizontal: 20, paddingVertical: 10, borderRadius: Radius.full },
  reelNavText: { color: '#fff', fontWeight: '700', fontSize: 13 },
  emptyReels: { flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: '#000' },
  emptyReelsText: { fontSize: 20, fontWeight: '800', color: '#fff', marginTop: 16 },
  emptyReelsSub: { fontSize: 14, color: 'rgba(255,255,255,0.5)', marginTop: 8 },
  // Trending
  trendCard: { flexDirection: 'row', alignItems: 'center', gap: 14, backgroundColor: Colors.bg3, borderRadius: Radius.xl, padding: 14, marginBottom: 10, borderWidth: 1, borderColor: Colors.border },
  trendRank: { fontSize: 22, fontWeight: '900', color: Colors.accent, minWidth: 28 },
  trendTag: { fontSize: 15, fontWeight: '800', color: Colors.text },
  trendCount: { fontSize: 12, color: Colors.text2, marginTop: 2 },
  trendBtn: { backgroundColor: Colors.bg4, paddingHorizontal: 12, paddingVertical: 6, borderRadius: Radius.full },
  trendBtnText: { fontSize: 12, fontWeight: '700', color: Colors.text2 },
  // Create post modal
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.8)', justifyContent: 'flex-end' },
  modalSheet: { backgroundColor: Colors.bg2, borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 20, maxHeight: '95%' },
  modalHandle: { width: 40, height: 4, borderRadius: 2, backgroundColor: Colors.border, alignSelf: 'center', marginBottom: 16 },
  modalTitle: { fontSize: 18, fontWeight: '900', color: Colors.text, textAlign: 'center', marginBottom: 16 },
  typeBtn: { paddingHorizontal: 16, paddingVertical: 9, borderRadius: Radius.md, borderWidth: 1.5, borderColor: Colors.border },
  typeBtnActive: { borderColor: Colors.accent, backgroundColor: 'rgba(232,255,71,0.1)' },
  typeBtnText: { fontSize: 13, fontWeight: '700', color: Colors.text2 },
  typeBtnTextActive: { color: Colors.accent },
  mediaPicker: { flexDirection: 'row', backgroundColor: Colors.bg3, borderRadius: Radius.xl, overflow: 'hidden', borderWidth: 1, borderColor: Colors.border, height: 120 },
  mediaPickerBtn: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 6 },
  mediaPickerText: { fontSize: 12, fontWeight: '700', color: Colors.text2, textAlign: 'center' },
  mediaPickerDivider: { width: 1, backgroundColor: Colors.border },
  mediaPreview: { borderRadius: Radius.xl, overflow: 'hidden', height: 200, backgroundColor: Colors.bg4, marginBottom: 4 },
  mediaPreviewImg: { width: '100%', height: '100%' },
  videoPreview: { width: '100%', height: '100%', alignItems: 'center', justifyContent: 'center', backgroundColor: '#111' },
  uploadingOverlay: { ...StyleSheet.absoluteFillObject, backgroundColor: 'rgba(0,0,0,0.7)', alignItems: 'center', justifyContent: 'center' },
  removeMediaBtn: { position: 'absolute', top: 8, right: 8, width: 28, height: 28, borderRadius: 14, backgroundColor: 'rgba(0,0,0,0.7)', alignItems: 'center', justifyContent: 'center' },
  formLabel: { fontSize: 13, fontWeight: '700', color: Colors.text2, marginBottom: 8 },
  formTextarea: { backgroundColor: Colors.bg3, borderWidth: 1, borderColor: Colors.border, borderRadius: Radius.md, padding: 12, color: Colors.text, fontSize: 14, height: 90, marginBottom: 16 },
  optChip: { paddingHorizontal: 14, paddingVertical: 8, borderRadius: Radius.full, borderWidth: 1.5, borderColor: Colors.border },
  optChipActive: { borderColor: Colors.accent, backgroundColor: 'rgba(232,255,71,0.1)' },
  optChipText: { fontSize: 13, fontWeight: '700', color: Colors.text2 },
  optChipTextActive: { fontSize: 13, fontWeight: '700', color: Colors.accent },
});
