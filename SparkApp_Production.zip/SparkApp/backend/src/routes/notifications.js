const { notificationRoutes } = require('./allRoutes'); module.exports = notificationRoutes;
