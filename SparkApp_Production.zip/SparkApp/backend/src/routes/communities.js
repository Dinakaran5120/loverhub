const { communityRoutes } = require('./allRoutes'); module.exports = communityRoutes;
