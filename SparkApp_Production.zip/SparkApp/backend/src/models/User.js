const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const UserSchema = new mongoose.Schema({
  // ── Auth ────────────────────────────────────────────────
  email: { type: String, unique: true, lowercase: true, trim: true, sparse: true },
  phone: { type: String, unique: true, sparse: true },
  passwordHash: { type: String, select: false },
  authProvider: { type: String, enum: ['email', 'phone', 'google', 'apple'], default: 'email' },
  isEmailVerified: { type: Boolean, default: false },
  isPhoneVerified: { type: Boolean, default: false },
  emailVerifyToken: String,
  phoneOTP: String,
  phoneOTPExpires: Date,
  passwordResetToken: String,
  passwordResetExpires: Date,

  // ── Profile ─────────────────────────────────────────────
  name: { type: String, required: true, trim: true },
  age: { type: Number, required: true, min: 18, max: 100 },
  gender: { type: String, enum: ['woman', 'man', 'non-binary', 'other'], required: true },
  orientation: {
    type: String,
    enum: ['straight', 'gay', 'lesbian', 'bisexual', 'pansexual', 'queer', 'non-binary', 'other'],
    required: true
  },
  interestedIn: [{ type: String, enum: ['men', 'women', 'everyone', 'non-binary'] }],
  lookingFor: { type: String, enum: ['long-term', 'casual', 'friends', 'unsure'], default: 'long-term' },
  bio: { type: String, maxlength: 500, default: '' },
  interests: [{ type: String }],
  photos: [{
    url: { type: String, required: true },
    publicId: String,
    isMain: { type: Boolean, default: false },
    order: Number
  }],
  profileComplete: { type: Boolean, default: false },

  // ── Location ────────────────────────────────────────────
  location: {
    type: { type: String, enum: ['Point'], default: 'Point' },
    coordinates: { type: [Number], default: [0, 0] }, // [lng, lat]
    city: String,
    country: String,
    lastUpdated: Date
  },

  // ── Settings / Filters ──────────────────────────────────
  settings: {
    discoveryEnabled: { type: Boolean, default: true },
    showAge: { type: Boolean, default: true },
    showDistance: { type: Boolean, default: true },
    showOnlineStatus: { type: Boolean, default: true },
    incognitoMode: { type: Boolean, default: false },
    maxDistance: { type: Number, default: 50, min: 1, max: 500 },
    ageRangeMin: { type: Number, default: 18 },
    ageRangeMax: { type: Number, default: 40 },
    globalMode: { type: Boolean, default: false },
    notifications: {
      matches: { type: Boolean, default: true },
      messages: { type: Boolean, default: true },
      likes: { type: Boolean, default: true },
      communities: { type: Boolean, default: true },
      marketing: { type: Boolean, default: false }
    },
    pushToken: String,
    language: { type: String, default: 'en' }
  },

  // ── Premium ─────────────────────────────────────────────
  premium: {
    isActive: { type: Boolean, default: false },
    plan: { type: String, enum: ['free', 'gold', 'platinum'], default: 'free' },
    expiresAt: Date,
    stripeCustomerId: String,
    stripeSubscriptionId: String
  },

  // ── Activity ────────────────────────────────────────────
  lastActive: { type: Date, default: Date.now },
  isOnline: { type: Boolean, default: false },
  likesGivenToday: { type: Number, default: 0 },
  likesResetAt: { type: Date, default: Date.now },
  boostsRemaining: { type: Number, default: 0 },
  superLikesRemaining: { type: Number, default: 1 },
  superLikesResetAt: { type: Date, default: Date.now },

  // ── Safety ──────────────────────────────────────────────
  blockedUsers: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
  reportCount: { type: Number, default: 0 },
  isBanned: { type: Boolean, default: false },
  banReason: String,
  isDeleted: { type: Boolean, default: false },
  deletedAt: Date,

  // ── Stats ───────────────────────────────────────────────
  stats: {
    totalMatches: { type: Number, default: 0 },
    totalLikes: { type: Number, default: 0 },
    profileViews: { type: Number, default: 0 }
  }
}, {
  timestamps: true,
  toJSON: { virtuals: true },
  toObject: { virtuals: true }
});

// ── Indexes ────────────────────────────────────────────────────────────────────
UserSchema.index({ location: '2dsphere' });
UserSchema.index({ age: 1, gender: 1, orientation: 1 });
UserSchema.index({ isDeleted: 1, isBanned: 1, 'settings.discoveryEnabled': 1 });

// ── Password Hashing ───────────────────────────────────────────────────────────
UserSchema.pre('save', async function(next) {
  if (!this.isModified('passwordHash')) return next();
  const salt = await bcrypt.genSalt(12);
  this.passwordHash = await bcrypt.hash(this.passwordHash, salt);
  next();
});

// ── Methods ────────────────────────────────────────────────────────────────────
UserSchema.methods.matchPassword = async function(password) {
  return bcrypt.compare(password, this.passwordHash);
};

UserSchema.methods.getSignedToken = function() {
  return jwt.sign({ id: this._id }, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRE || '30d'
  });
};

UserSchema.methods.canLike = function() {
  const now = new Date();
  if (this.premium.isActive) return true;
  // Reset daily likes
  if (now - this.likesResetAt > 24 * 60 * 60 * 1000) {
    this.likesGivenToday = 0;
    this.likesResetAt = now;
  }
  return this.likesGivenToday < 100; // Free limit: 100/day
};

UserSchema.methods.toPublicProfile = function() {
  return {
    _id: this._id,
    name: this.name,
    age: this.age,
    gender: this.gender,
    orientation: this.orientation,
    lookingFor: this.lookingFor,
    bio: this.bio,
    interests: this.interests,
    photos: this.photos,
    location: this.settings.showDistance ? this.location : undefined,
    isOnline: this.settings.showOnlineStatus ? this.isOnline : undefined,
    lastActive: this.lastActive,
    stats: { totalMatches: this.stats.totalMatches }
  };
};

module.exports = mongoose.model('User', UserSchema);
