import { useState } from "react";
import {
  View, Text, ScrollView, Pressable, TextInput,
  KeyboardAvoidingView, Platform,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { useRouter } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Colors } from "@constants/theme";
import { useAuthStore } from "@/store/authStore";

const AVATARS = ["😊","😎","🥰","😍","🤩","🥳","🌈","✨","💫","🦋","🌸","🦄","🐯","🦁","🐼"];
const INTERESTS_LIST = [
  "☕ Coffee","🎵 Music","✈️ Travel","📸 Photography","🍜 Foodie",
  "🌿 Plants","💪 Fitness","📚 Books","🎨 Art","🎮 Gaming",
  "🧘 Yoga","💃 Dancing","🏏 Cricket","🌊 Surfing","🎬 Movies",
];

export default function EditProfileScreen() {
  const router   = useRouter();
  const insets   = useSafeAreaInsets();
  const profile  = useAuthStore((s) => s.profile);
  const update   = useAuthStore((s) => s.updateProfile);

  const [name, setName]         = useState(profile.name || "");
  const [bio, setBio]           = useState("");
  const [photoEmoji, setPhoto]  = useState(profile.photoEmoji || "😊");
  const [interests, setInterests] = useState<string[]>(profile.interests ?? []);
  const [saving, setSaving]     = useState(false);

  const toggle = (item: string) =>
    setInterests((prev) =>
      prev.includes(item) ? prev.filter((x) => x !== item) : [...prev, item]
    );

  const handleSave = async () => {
    setSaving(true);
    await new Promise((r) => setTimeout(r, 600));
    update({ name: name.trim(), photoEmoji, interests });
    setSaving(false);
    router.back();
  };

  return (
    <KeyboardAvoidingView
      style={{ flex: 1, backgroundColor: Colors.background }}
      behavior={Platform.OS === "ios" ? "padding" : "height"}
    >
      {/* Header */}
      <View
        style={{
          paddingTop: insets.top,
          backgroundColor: Colors.surface,
          borderBottomWidth: 1,
          borderBottomColor: Colors.border,
        }}
      >
        <View
          style={{
            height: 56,
            flexDirection: "row",
            alignItems: "center",
            justifyContent: "space-between",
            paddingHorizontal: 16,
          }}
        >
          <Pressable
            onPress={() => router.back()}
            style={({ pressed }) => ({ opacity: pressed ? 0.6 : 1 })}
          >
            <Text style={{ fontSize: 22, color: Colors.text }}>←</Text>
          </Pressable>
          <Text style={{ fontSize: 16, fontWeight: "800", color: Colors.text }}>Edit Profile</Text>
          <Pressable
            onPress={handleSave}
            disabled={saving}
            style={({ pressed }) => ({ opacity: pressed ? 0.7 : saving ? 0.5 : 1 })}
          >
            <LinearGradient
              colors={[Colors.primary, Colors.accent]}
              start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
              style={{ paddingHorizontal: 18, paddingVertical: 8, borderRadius: 14 }}
            >
              <Text style={{ color: "#fff", fontWeight: "800", fontSize: 14 }}>
                {saving ? "Saving…" : "Save"}
              </Text>
            </LinearGradient>
          </Pressable>
        </View>
      </View>

      <ScrollView
        contentContainerStyle={{ padding: 20, gap: 24, paddingBottom: 48 }}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
      >
        {/* Avatar picker */}
        <View style={{ alignItems: "center", gap: 12 }}>
          <LinearGradient
            colors={[Colors.primary, Colors.accent]}
            start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
            style={{
              width: 100, height: 100, borderRadius: 50,
              alignItems: "center", justifyContent: "center",
              shadowColor: Colors.primary, shadowOffset: { width: 0, height: 6 },
              shadowOpacity: 0.35, shadowRadius: 14, elevation: 8,
            }}
          >
            <Text style={{ fontSize: 56 }}>{photoEmoji}</Text>
          </LinearGradient>
          <Text style={{ fontSize: 13, color: Colors.textMuted }}>Tap an avatar below to change</Text>
        </View>

        <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 10, justifyContent: "center" }}>
          {AVATARS.map((e) => (
            <Pressable
              key={e}
              onPress={() => setPhoto(e)}
              style={({ pressed }) => ({
                opacity: pressed ? 0.7 : 1,
                transform: [{ scale: photoEmoji === e ? 1.15 : 1 }],
              })}
            >
              {photoEmoji === e ? (
                <LinearGradient
                  colors={[Colors.primary, Colors.accent]}
                  start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
                  style={{ width: 52, height: 52, borderRadius: 26, alignItems: "center", justifyContent: "center" }}
                >
                  <Text style={{ fontSize: 28 }}>{e}</Text>
                </LinearGradient>
              ) : (
                <View style={{ width: 52, height: 52, borderRadius: 26, backgroundColor: Colors.card, borderWidth: 1.5, borderColor: Colors.border, alignItems: "center", justifyContent: "center" }}>
                  <Text style={{ fontSize: 28 }}>{e}</Text>
                </View>
              )}
            </Pressable>
          ))}
        </View>

        {/* Name */}
        <View style={{ gap: 8 }}>
          <Text style={{ fontSize: 13, fontWeight: "700", color: Colors.textSecondary, letterSpacing: 0.3 }}>DISPLAY NAME</Text>
          <TextInput
            value={name}
            onChangeText={setName}
            placeholder="Your name…"
            placeholderTextColor={Colors.textMuted}
            maxLength={30}
            style={{ backgroundColor: Colors.surface, borderRadius: 16, borderWidth: 1, borderColor: Colors.border, paddingHorizontal: 14, paddingVertical: 13, fontSize: 15, color: Colors.text }}
          />
        </View>

        {/* Bio */}
        <View style={{ gap: 8 }}>
          <Text style={{ fontSize: 13, fontWeight: "700", color: Colors.textSecondary, letterSpacing: 0.3 }}>BIO</Text>
          <TextInput
            value={bio}
            onChangeText={setBio}
            placeholder="Tell people a bit about yourself…"
            placeholderTextColor={Colors.textMuted}
            multiline
            numberOfLines={4}
            maxLength={200}
            style={{ backgroundColor: Colors.surface, borderRadius: 16, borderWidth: 1, borderColor: Colors.border, padding: 14, fontSize: 15, color: Colors.text, lineHeight: 22, minHeight: 100, textAlignVertical: "top" }}
          />
          <Text style={{ fontSize: 11, color: Colors.textMuted, textAlign: "right" }}>{bio.length}/200</Text>
        </View>

        {/* Interests */}
        <View style={{ gap: 10 }}>
          <Text style={{ fontSize: 13, fontWeight: "700", color: Colors.textSecondary, letterSpacing: 0.3 }}>INTERESTS</Text>
          <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8 }}>
            {INTERESTS_LIST.map((item) => {
              const sel = interests.includes(item);
              return (
                <Pressable key={item} onPress={() => toggle(item)}>
                  {sel ? (
                    <LinearGradient
                      colors={[Colors.primary, Colors.accent]}
                      start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
                      style={{ paddingHorizontal: 14, paddingVertical: 9, borderRadius: 20 }}
                    >
                      <Text style={{ color: "#fff", fontSize: 13, fontWeight: "700" }}>{item} ✓</Text>
                    </LinearGradient>
                  ) : (
                    <View style={{ paddingHorizontal: 14, paddingVertical: 9, borderRadius: 20, borderWidth: 1.5, borderColor: Colors.border, backgroundColor: Colors.card }}>
                      <Text style={{ color: Colors.textSecondary, fontSize: 13, fontWeight: "600" }}>{item}</Text>
                    </View>
                  )}
                </Pressable>
              );
            })}
          </View>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}
