const User = require('../models/User');
const crypto = require('crypto');
const jwt = require('jsonwebtoken');
const nodemailer = require('nodemailer');

// ── Helpers ────────────────────────────────────────────────────────────────────
const sendToken = (user, statusCode, res) => {
  const token = user.getSignedToken();
  res.status(statusCode).json({
    success: true,
    token,
    user: {
      _id: user._id,
      name: user.name,
      email: user.email,
      phone: user.phone,
      age: user.age,
      gender: user.gender,
      orientation: user.orientation,
      photos: user.photos,
      profileComplete: user.profileComplete,
      premium: user.premium,
      settings: user.settings
    }
  });
};

const sendEmail = async ({ to, subject, html }) => {
  const transporter = nodemailer.createTransporter({
    host: process.env.SMTP_HOST,
    port: process.env.SMTP_PORT,
    auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS }
  });
  await transporter.sendMail({ from: `${process.env.FROM_NAME} <${process.env.FROM_EMAIL}>`, to, subject, html });
};

// ── Register ───────────────────────────────────────────────────────────────────
exports.register = async (req, res, next) => {
  try {
    const { name, email, password, age, gender, orientation } = req.body;

    if (await User.findOne({ email: email.toLowerCase() })) {
      return res.status(400).json({ success: false, message: 'Email already registered.' });
    }

    const emailToken = crypto.randomBytes(32).toString('hex');
    const user = await User.create({
      name, email, age, gender, orientation,
      passwordHash: password,
      emailVerifyToken: crypto.createHash('sha256').update(emailToken).digest('hex')
    });

    // Send verification email
    const verifyUrl = `${process.env.CLIENT_URL}/verify-email/${emailToken}`;
    await sendEmail({
      to: email,
      subject: '✦ Verify your Spark account',
      html: `<h2>Welcome to Spark! 🔥</h2><p>Click <a href="${verifyUrl}">here</a> to verify your email.</p>`
    }).catch(console.error);

    sendToken(user, 201, res);
  } catch (err) {
    next(err);
  }
};

// ── Login ──────────────────────────────────────────────────────────────────────
exports.login = async (req, res, next) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) return res.status(400).json({ success: false, message: 'Email and password required.' });

    const user = await User.findOne({ email: email.toLowerCase(), isDeleted: false }).select('+passwordHash');
    if (!user || !(await user.matchPassword(password))) {
      return res.status(401).json({ success: false, message: 'Invalid credentials.' });
    }
    if (user.isBanned) {
      return res.status(403).json({ success: false, message: 'Account suspended. Contact support.' });
    }

    user.lastActive = new Date();
    user.isOnline = true;
    await user.save();

    sendToken(user, 200, res);
  } catch (err) {
    next(err);
  }
};

// ── Logout ─────────────────────────────────────────────────────────────────────
exports.logout = async (req, res, next) => {
  try {
    await User.findByIdAndUpdate(req.user._id, { isOnline: false, lastActive: new Date() });
    res.status(200).json({ success: true, message: 'Logged out successfully.' });
  } catch (err) {
    next(err);
  }
};

// ── Get Me ─────────────────────────────────────────────────────────────────────
exports.getMe = async (req, res, next) => {
  try {
    const user = await User.findById(req.user._id);
    res.status(200).json({ success: true, user });
  } catch (err) {
    next(err);
  }
};

// ── Verify Email ───────────────────────────────────────────────────────────────
exports.verifyEmail = async (req, res, next) => {
  try {
    const hashed = crypto.createHash('sha256').update(req.params.token).digest('hex');
    const user = await User.findOne({ emailVerifyToken: hashed });
    if (!user) return res.status(400).json({ success: false, message: 'Invalid or expired token.' });

    user.isEmailVerified = true;
    user.emailVerifyToken = undefined;
    await user.save();
    res.status(200).json({ success: true, message: 'Email verified.' });
  } catch (err) {
    next(err);
  }
};

// ── Forgot Password ────────────────────────────────────────────────────────────
exports.forgotPassword = async (req, res, next) => {
  try {
    const user = await User.findOne({ email: req.body.email });
    if (!user) return res.status(200).json({ success: true, message: 'If that email exists, we sent a reset link.' });

    const resetToken = crypto.randomBytes(32).toString('hex');
    user.passwordResetToken = crypto.createHash('sha256').update(resetToken).digest('hex');
    user.passwordResetExpires = Date.now() + 10 * 60 * 1000;
    await user.save();

    const resetUrl = `${process.env.CLIENT_URL}/reset-password/${resetToken}`;
    await sendEmail({
      to: user.email,
      subject: 'Reset your Spark password',
      html: `<p>Reset your password <a href="${resetUrl}">here</a>. Expires in 10 minutes.</p>`
    });

    res.status(200).json({ success: true, message: 'Password reset email sent.' });
  } catch (err) {
    next(err);
  }
};

// ── Reset Password ─────────────────────────────────────────────────────────────
exports.resetPassword = async (req, res, next) => {
  try {
    const hashed = crypto.createHash('sha256').update(req.params.token).digest('hex');
    const user = await User.findOne({ passwordResetToken: hashed, passwordResetExpires: { $gt: Date.now() } });
    if (!user) return res.status(400).json({ success: false, message: 'Token is invalid or has expired.' });

    user.passwordHash = req.body.password;
    user.passwordResetToken = undefined;
    user.passwordResetExpires = undefined;
    await user.save();
    sendToken(user, 200, res);
  } catch (err) {
    next(err);
  }
};

// ── Delete Account ─────────────────────────────────────────────────────────────
exports.deleteAccount = async (req, res, next) => {
  try {
    const { password, reason } = req.body;
    const user = await User.findById(req.user._id).select('+passwordHash');

    if (user.authProvider === 'email' && !(await user.matchPassword(password))) {
      return res.status(401).json({ success: false, message: 'Incorrect password.' });
    }

    // Soft delete — keeps data for 30 days (legal compliance)
    user.isDeleted = true;
    user.deletedAt = new Date();
    user.email = `deleted_${user._id}@deleted.spark`;
    user.phone = undefined;
    user.name = 'Deleted User';
    user.bio = '';
    user.photos = [];
    user.settings.discoveryEnabled = false;
    await user.save();

    // Send confirmation email
    await sendEmail({
      to: req.user.email,
      subject: 'Your Spark account has been deleted',
      html: `<p>Your account has been deleted. We're sorry to see you go 💔</p><p>Your data will be permanently removed within 30 days.</p>`
    }).catch(() => {});

    res.status(200).json({ success: true, message: 'Account deleted successfully.' });
  } catch (err) {
    next(err);
  }
};

// ── Change Password ────────────────────────────────────────────────────────────
exports.changePassword = async (req, res, next) => {
  try {
    const user = await User.findById(req.user._id).select('+passwordHash');
    if (!(await user.matchPassword(req.body.currentPassword))) {
      return res.status(401).json({ success: false, message: 'Current password is incorrect.' });
    }
    user.passwordHash = req.body.newPassword;
    await user.save();
    res.status(200).json({ success: true, message: 'Password updated.' });
  } catch (err) {
    next(err);
  }
};
