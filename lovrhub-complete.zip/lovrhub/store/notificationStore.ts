import { create } from "zustand";
import type { Notification, NotificationGroup, NotificationType } from "@/types/notification";
import { MOCK_NOTIFICATIONS } from "@/data/mockNotifications";
import { Colors } from "@constants/theme";

export interface NotifPreferences {
  follows: boolean;
  messages: boolean;
  matches: boolean;
  likes: boolean;
  comments: boolean;
  communityPosts: boolean;
  joinRequests: boolean;
  profileViews: boolean;
  systemUpdates: boolean;
  pushEnabled: boolean;
  emailDigest: boolean;
  quietHoursEnabled: boolean;
  quietHoursStart: string;   // "22:00"
  quietHoursEnd: string;     // "08:00"
}

interface NotificationState {
  notifications: Notification[];
  preferences: NotifPreferences;
  activeGroup: NotificationGroup | "all";
  panelVisible: boolean;

  // Counts
  unreadCount: () => number;
  unreadByGroup: (group: NotificationGroup | "all") => number;

  // Actions
  markRead: (id: string) => void;
  markAllRead: () => void;
  markGroupRead: (group: NotificationGroup | "all") => void;
  deleteNotif: (id: string) => void;
  clearAll: () => void;
  setActiveGroup: (group: NotificationGroup | "all") => void;
  setPanelVisible: (visible: boolean) => void;
  updatePreference: (key: keyof NotifPreferences, value: boolean | string) => void;

  // Simulate new notification arriving
  pushNotification: (notif: Omit<Notification, "id" | "read" | "createdAt">) => void;
}

const DEFAULT_PREFS: NotifPreferences = {
  follows: true,
  messages: true,
  matches: true,
  likes: true,
  comments: true,
  communityPosts: true,
  joinRequests: true,
  profileViews: true,
  systemUpdates: true,
  pushEnabled: true,
  emailDigest: false,
  quietHoursEnabled: false,
  quietHoursStart: "22:00",
  quietHoursEnd: "08:00",
};

export const useNotificationStore = create<NotificationState>((set, get) => ({
  notifications: MOCK_NOTIFICATIONS,
  preferences: DEFAULT_PREFS,
  activeGroup: "all",
  panelVisible: false,

  unreadCount: () => get().notifications.filter((n) => !n.read).length,

  unreadByGroup: (group) => {
    const notifs = get().notifications;
    if (group === "all") return notifs.filter((n) => !n.read).length;
    return notifs.filter((n) => n.group === group && !n.read).length;
  },

  markRead: (id) =>
    set((s) => ({
      notifications: s.notifications.map((n) =>
        n.id === id ? { ...n, read: true } : n
      ),
    })),

  markAllRead: () =>
    set((s) => ({
      notifications: s.notifications.map((n) => ({ ...n, read: true })),
    })),

  markGroupRead: (group) =>
    set((s) => ({
      notifications: s.notifications.map((n) =>
        group === "all" || n.group === group ? { ...n, read: true } : n
      ),
    })),

  deleteNotif: (id) =>
    set((s) => ({
      notifications: s.notifications.filter((n) => n.id !== id),
    })),

  clearAll: () => set({ notifications: [] }),

  setActiveGroup: (group) => set({ activeGroup: group }),

  setPanelVisible: (visible) => set({ panelVisible: visible }),

  updatePreference: (key, value) =>
    set((s) => ({
      preferences: { ...s.preferences, [key]: value },
    })),

  pushNotification: (data) =>
    set((s) => ({
      notifications: [
        {
          ...data,
          id: `n_${Date.now()}`,
          read: false,
          createdAt: new Date().toISOString(),
        },
        ...s.notifications,
      ],
    })),
}));
