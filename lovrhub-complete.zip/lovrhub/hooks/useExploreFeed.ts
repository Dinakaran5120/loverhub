import { useMemo } from "react";
import { useExploreStore } from "@/store/exploreStore";
import type { ExplorePost } from "@/types/explore";

/** Returns time-ago string from ISO timestamp */
export function useTimeAgo(iso: string): string {
  return useMemo(() => {
    const diff  = Date.now() - new Date(iso).getTime();
    const mins  = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days  = Math.floor(diff / 86400000);
    if (mins < 1)   return "just now";
    if (mins < 60)  return `${mins}m`;
    if (hours < 24) return `${hours}h`;
    return `${days}d`;
  }, [iso]);
}

/** Formats large numbers — 1200 → 1.2k */
export function fmtCount(n: number): string {
  if (n >= 1000000) return `${(n / 1000000).toFixed(1)}m`;
  if (n >= 1000)    return `${(n / 1000).toFixed(1)}k`;
  return String(n);
}

/** Returns the total vibe count across all reaction types */
export function totalVibes(post: ExplorePost): number {
  return post.vibes.reduce((sum, v) => sum + v.count, 0);
}

/** Tab-filtered, memoised feed */
export function useExploreFeed(): ExplorePost[] {
  const posts     = useExploreStore((s) => s.posts);
  const activeTab = useExploreStore((s) => s.activeTab);

  return useMemo(() => {
    switch (activeTab) {
      case "trending":
        return [...posts]
          .filter((p) => p.isTrending)
          .sort((a, b) => totalVibes(b) - totalVibes(a));

      case "vibes":
        return [...posts]
          .filter((p) => p.type === "mood" || p.type === "thought")
          .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

      case "reels":
        return posts.filter((p) => p.type === "video");

      case "forYou":
      default:
        return [...posts].sort(
          (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
        );
    }
  }, [posts, activeTab]);
}
