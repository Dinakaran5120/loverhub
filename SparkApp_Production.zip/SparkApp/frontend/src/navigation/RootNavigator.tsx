import React, { useEffect } from 'react';
import { View, ActivityIndicator, StyleSheet } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Text } from 'react-native';
import { Colors, Radius } from '../utils/theme';
import { useAuthStore } from '../store/authStore';
import { PrideBar } from '../components/SharedComponents';

// Screens
import { LoginScreen, RegisterScreen, ForgotPasswordScreen } from '../screens/AuthScreens';
import DiscoverScreen from '../screens/DiscoverScreen';
import MatchesScreen from '../screens/MatchesScreen';
import ExploreScreen from '../screens/ExploreScreen';
import CommunitiesScreen from '../screens/CommunitiesScreen';
import ProfileScreen from '../screens/ProfileScreen';
import PrivacyPolicyScreen from '../screens/PrivacyPolicyScreen';
import TermsOfServiceScreen from '../screens/TermsOfServiceScreen';
import HelpCenterScreen from '../screens/HelpCenterScreen';

const Stack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();

// ── Tab Icon ──────────────────────────────────────────────────────────────────
const TabIcon = ({ emoji, label, focused, badge }: { emoji: string; label: string; focused: boolean; badge?: number }) => (
  <View style={tabStyles.item}>
    <View style={[tabStyles.iconWrap, focused && tabStyles.iconActive]}>
      <Text style={[tabStyles.emoji, focused && tabStyles.emojiActive]}>{emoji}</Text>
      {!!badge && (
        <View style={tabStyles.badge}><Text style={tabStyles.badgeText}>{badge > 9 ? '9+' : badge}</Text></View>
      )}
    </View>
    <Text style={[tabStyles.label, focused && tabStyles.labelActive]}>{label}</Text>
  </View>
);

// ── Main Tab Navigator ────────────────────────────────────────────────────────
function MainTabs() {
  return (
    <Tab.Navigator
      screenOptions={{ headerShown: false, tabBarStyle: tabStyles.bar, tabBarShowLabel: false }}
    >
      <Tab.Screen name="Discover" component={DiscoverScreen}
        options={{ tabBarIcon: ({ focused }) => <TabIcon emoji="🔥" label="Discover" focused={focused} /> }} />
      <Tab.Screen name="Matches" component={MatchesScreen}
        options={{ tabBarIcon: ({ focused }) => <TabIcon emoji="💬" label="Matches" focused={focused} /> }} />
      <Tab.Screen name="Explore" component={ExploreScreen}
        options={{ tabBarIcon: ({ focused }) => <TabIcon emoji="✦" label="Explore" focused={focused} /> }} />
      <Tab.Screen name="Communities" component={CommunitiesScreen}
        options={{ tabBarIcon: ({ focused }) => <TabIcon emoji="👥" label="Community" focused={focused} /> }} />
      <Tab.Screen name="Profile" component={ProfileScreen}
        options={{ tabBarIcon: ({ focused }) => <TabIcon emoji="👤" label="Profile" focused={focused} /> }} />
    </Tab.Navigator>
  );
}

// ── Loading Screen ────────────────────────────────────────────────────────────
function LoadingScreen() {
  return (
    <View style={styles.loading}>
      <Text style={styles.loadingLogo}>✦ spark</Text>
      <ActivityIndicator color={Colors.accent} size="large" style={{ marginTop: 32 }} />
    </View>
  );
}

// ── Root Navigator ────────────────────────────────────────────────────────────
export default function RootNavigator() {
  const { token, isInitialized, initialize } = useAuthStore();

  useEffect(() => { initialize(); }, []);

  if (!isInitialized) return <LoadingScreen />;

  return (
    <NavigationContainer
      theme={{
        dark: true,
        colors: {
          primary: Colors.accent,
          background: Colors.bg,
          card: Colors.bg2,
          text: Colors.text,
          border: Colors.border,
          notification: Colors.pink,
        },
      }}
    >
      <Stack.Navigator screenOptions={{ headerShown: false, animation: 'slide_from_right' }}>
        {!token ? (
          // Auth stack
          <>
            <Stack.Screen name="Login" component={LoginScreen} />
            <Stack.Screen name="Register" component={RegisterScreen} />
            <Stack.Screen name="ForgotPassword" component={ForgotPasswordScreen} />
            <Stack.Screen name="PrivacyPolicy" component={PrivacyPolicyScreen} />
            <Stack.Screen name="TermsOfService" component={TermsOfServiceScreen} />
          </>
        ) : (
          // Main app stack
          <>
            <Stack.Screen name="Main" component={MainTabs} />
            <Stack.Screen name="PrivacyPolicy" component={PrivacyPolicyScreen} options={{ animation: 'slide_from_bottom' }} />
            <Stack.Screen name="TermsOfService" component={TermsOfServiceScreen} options={{ animation: 'slide_from_bottom' }} />
            <Stack.Screen name="HelpCenter" component={HelpCenterScreen} options={{ animation: 'slide_from_bottom' }} />
          </>
        )}
      </Stack.Navigator>
    </NavigationContainer>
  );
}

const tabStyles = StyleSheet.create({
  bar: { backgroundColor: Colors.bg2, borderTopWidth: 1, borderTopColor: Colors.border, height: 72, paddingBottom: 12, paddingTop: 6 },
  item: { alignItems: 'center', gap: 3 },
  iconWrap: { width: 44, height: 38, borderRadius: Radius.md, alignItems: 'center', justifyContent: 'center', backgroundColor: Colors.bg3, position: 'relative' },
  iconActive: { backgroundColor: Colors.accent },
  emoji: { fontSize: 18, opacity: 0.6 },
  emojiActive: { opacity: 1 },
  label: { fontSize: 10, fontWeight: '700', color: Colors.text2 },
  labelActive: { color: Colors.accent },
  badge: { position: 'absolute', top: -4, right: -4, backgroundColor: Colors.pink, borderRadius: 10, minWidth: 18, height: 18, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 4, borderWidth: 2, borderColor: Colors.bg2 },
  badgeText: { fontSize: 10, fontWeight: '800', color: '#fff' },
});

const styles = StyleSheet.create({
  loading: { flex: 1, backgroundColor: Colors.bg, alignItems: 'center', justifyContent: 'center' },
  loadingLogo: { fontSize: 42, fontWeight: '900', color: Colors.pink },
});
