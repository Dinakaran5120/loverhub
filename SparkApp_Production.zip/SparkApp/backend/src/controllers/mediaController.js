const cloudinary = require('cloudinary').v2;
const multer = require('multer');
const path = require('path');

cloudinary.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET
});

// ── Multer memory storage ──────────────────────────────────────────────────────
const storage = multer.memoryStorage();
const fileFilter = (req, file, cb) => {
  const allowed = /jpeg|jpg|png|gif|mp4|mov|webm/;
  const ext = path.extname(file.originalname).toLowerCase();
  const mime = file.mimetype;
  if (allowed.test(ext) && (mime.startsWith('image/') || mime.startsWith('video/'))) {
    cb(null, true);
  } else {
    cb(new Error('Only images and videos are allowed.'), false);
  }
};

exports.upload = multer({
  storage,
  fileFilter,
  limits: { fileSize: 100 * 1024 * 1024 } // 100MB
});

// ── Upload to Cloudinary helper ────────────────────────────────────────────────
const uploadToCloudinary = (buffer, options) => {
  return new Promise((resolve, reject) => {
    const stream = cloudinary.uploader.upload_stream(options, (err, result) => {
      if (err) reject(err);
      else resolve(result);
    });
    stream.end(buffer);
  });
};

// ── Upload Profile Photo ───────────────────────────────────────────────────────
exports.uploadProfilePhoto = async (req, res, next) => {
  try {
    if (!req.file) return res.status(400).json({ success: false, message: 'No file uploaded.' });

    const result = await uploadToCloudinary(req.file.buffer, {
      folder: `spark/profiles/${req.user._id}`,
      transformation: [
        { width: 800, height: 1000, crop: 'fill', gravity: 'face' },
        { quality: 'auto', fetch_format: 'auto' }
      ],
      resource_type: 'image'
    });

    const User = require('../models/User');
    const user = await User.findById(req.user._id);

    user.photos.push({
      url: result.secure_url,
      publicId: result.public_id,
      isMain: user.photos.length === 0,
      order: user.photos.length
    });
    await user.save();

    res.status(200).json({
      success: true,
      photo: { url: result.secure_url, publicId: result.public_id }
    });
  } catch (err) {
    next(err);
  }
};

// ── Delete Profile Photo ───────────────────────────────────────────────────────
exports.deleteProfilePhoto = async (req, res, next) => {
  try {
    const User = require('../models/User');
    const user = await User.findById(req.user._id);
    const photo = user.photos.id(req.params.photoId);
    if (!photo) return res.status(404).json({ success: false, message: 'Photo not found.' });

    await cloudinary.uploader.destroy(photo.publicId);
    user.photos.pull(req.params.photoId);
    await user.save();

    res.status(200).json({ success: true, message: 'Photo deleted.' });
  } catch (err) {
    next(err);
  }
};

// ── Upload Post Media (Image / Video / Reel) ──────────────────────────────────
exports.uploadPostMedia = async (req, res, next) => {
  try {
    if (!req.file) return res.status(400).json({ success: false, message: 'No file uploaded.' });

    const isVideo = req.file.mimetype.startsWith('video/');
    const folder = isVideo ? `spark/reels/${req.user._id}` : `spark/posts/${req.user._id}`;

    const options = isVideo
      ? {
          folder,
          resource_type: 'video',
          transformation: [
            { width: 720, height: 1280, crop: 'limit' },
            { quality: 'auto' }
          ],
          eager: [{ format: 'jpg', transformation: [{ width: 400, height: 400, crop: 'fill' }] }]
        }
      : {
          folder,
          transformation: [
            { width: 1080, height: 1080, crop: 'limit' },
            { quality: 'auto', fetch_format: 'auto' }
          ],
          resource_type: 'image'
        };

    const result = await uploadToCloudinary(req.file.buffer, options);

    res.status(200).json({
      success: true,
      url: result.secure_url,
      publicId: result.public_id,
      type: isVideo ? 'video' : 'image',
      thumbnailUrl: isVideo && result.eager?.[0]?.secure_url ? result.eager[0].secure_url : null,
      duration: result.duration || null
    });
  } catch (err) {
    next(err);
  }
};

// ── Upload Community Cover ─────────────────────────────────────────────────────
exports.uploadCommunityImage = async (req, res, next) => {
  try {
    if (!req.file) return res.status(400).json({ success: false, message: 'No file uploaded.' });

    const result = await uploadToCloudinary(req.file.buffer, {
      folder: 'spark/communities',
      transformation: [{ width: 1200, height: 400, crop: 'fill' }, { quality: 'auto' }],
      resource_type: 'image'
    });

    res.status(200).json({ success: true, url: result.secure_url, publicId: result.public_id });
  } catch (err) {
    next(err);
  }
};

// ── Upload Chat Media ──────────────────────────────────────────────────────────
exports.uploadChatMedia = async (req, res, next) => {
  try {
    if (!req.file) return res.status(400).json({ success: false, message: 'No file.' });
    const isVideo = req.file.mimetype.startsWith('video/');

    const result = await uploadToCloudinary(req.file.buffer, {
      folder: `spark/chat/${req.user._id}`,
      resource_type: isVideo ? 'video' : 'image',
      transformation: isVideo ? [{ width: 720, crop: 'limit' }] : [{ width: 800, crop: 'limit' }, { quality: 'auto' }]
    });

    res.status(200).json({
      success: true,
      url: result.secure_url,
      publicId: result.public_id,
      type: isVideo ? 'video' : 'image'
    });
  } catch (err) {
    next(err);
  }
};
