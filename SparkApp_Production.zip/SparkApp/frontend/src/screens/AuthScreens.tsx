import React, { useState } from 'react';
import {
  View, Text, StyleSheet, TextInput, TouchableOpacity,
  ScrollView, KeyboardAvoidingView, Platform, Alert,
  Dimensions, ActivityIndicator,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import * as Haptics from 'expo-haptics';
import { Colors, Spacing, Radius } from '../utils/theme';
import { useAuthStore } from '../store/authStore';
import { PrideBar } from '../components/SharedComponents';

const { width: W } = Dimensions.get('window');

const ORIENTATIONS = ['Straight', 'Gay', 'Lesbian', 'Bisexual', 'Pansexual', 'Queer', 'Non-binary'];
const GENDERS = ['Woman', 'Man', 'Non-binary', 'Other'];
const INTERESTS_LIST = ['Music', 'Travel', 'Fitness', 'Books', 'Movies', 'Cooking', 'Art', 'Gaming', 'Hiking', 'Coffee', 'Dogs', 'Cats', 'Photography', 'Yoga', 'Dancing', 'Foodie', 'Beach', 'Mountains'];

// ── Input Component ───────────────────────────────────────────────────────────
const AuthInput = ({ label, ...props }: any) => (
  <View style={styles.inputGroup}>
    {label && <Text style={styles.inputLabel}>{label}</Text>}
    <TextInput style={styles.input} placeholderTextColor={Colors.text3} {...props} />
  </View>
);

// ── Option Chip ───────────────────────────────────────────────────────────────
const OptionChip = ({ label, selected, onPress }: any) => (
  <TouchableOpacity
    style={[styles.chip, selected && styles.chipActive]}
    onPress={() => { onPress(); Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); }}>
    <Text style={[styles.chipText, selected && styles.chipTextActive]}>{label}</Text>
  </TouchableOpacity>
);

// ── Login Screen ──────────────────────────────────────────────────────────────
export function LoginScreen({ navigation }: any) {
  const { login, isLoading, error, clearError } = useAuthStore();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPass, setShowPass] = useState(false);

  const handleLogin = async () => {
    if (!email.trim() || !password.trim()) {
      Alert.alert('Missing fields', 'Please enter your email and password.'); return;
    }
    try {
      await login(email.trim(), password);
    } catch {}
  };

  return (
    <SafeAreaView style={styles.container} edges={['top', 'bottom']}>
      <PrideBar />
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <ScrollView contentContainerStyle={styles.authContent} keyboardShouldPersistTaps="handled">
          <View style={styles.logoArea}>
            <Text style={styles.logoText}>✦ spark</Text>
            <Text style={styles.logoTagline}>Find your person 💜</Text>
          </View>

          {error && (
            <View style={styles.errorBanner}>
              <Text style={styles.errorText}>{error}</Text>
              <TouchableOpacity onPress={clearError}><Text style={{ color: Colors.pink, fontSize: 16 }}>✕</Text></TouchableOpacity>
            </View>
          )}

          <AuthInput label="Email" value={email} onChangeText={setEmail} placeholder="your@email.com" keyboardType="email-address" autoCapitalize="none" autoCorrect={false} />
          <View style={styles.inputGroup}>
            <Text style={styles.inputLabel}>Password</Text>
            <View style={styles.passwordRow}>
              <TextInput
                style={[styles.input, { flex: 1, marginBottom: 0 }]}
                value={password}
                onChangeText={setPassword}
                placeholder="••••••••"
                placeholderTextColor={Colors.text3}
                secureTextEntry={!showPass}
              />
              <TouchableOpacity style={styles.showPassBtn} onPress={() => setShowPass(!showPass)}>
                <Text style={{ fontSize: 18, color: Colors.text2 }}>{showPass ? '🙈' : '👁️'}</Text>
              </TouchableOpacity>
            </View>
          </View>

          <TouchableOpacity style={styles.forgotBtn} onPress={() => navigation.navigate('ForgotPassword')}>
            <Text style={styles.forgotText}>Forgot Password?</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.primaryBtn} onPress={handleLogin} disabled={isLoading} activeOpacity={0.85}>
            {isLoading ? <ActivityIndicator color="#000" /> : <Text style={styles.primaryBtnText}>Log In</Text>}
          </TouchableOpacity>

          <View style={styles.dividerRow}>
            <View style={styles.dividerLine} />
            <Text style={styles.dividerText}>or</Text>
            <View style={styles.dividerLine} />
          </View>

          <TouchableOpacity style={styles.socialBtn} onPress={() => Alert.alert('Coming Soon', 'Google Sign-In launching soon!')}>
            <Text style={{ fontSize: 20 }}>🌐</Text>
            <Text style={styles.socialBtnText}>Continue with Google</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.socialBtn} onPress={() => Alert.alert('Coming Soon', 'Apple Sign-In launching soon!')}>
            <Text style={{ fontSize: 20 }}>🍎</Text>
            <Text style={styles.socialBtnText}>Continue with Apple</Text>
          </TouchableOpacity>

          <View style={styles.switchRow}>
            <Text style={styles.switchText}>New to Spark? </Text>
            <TouchableOpacity onPress={() => navigation.navigate('Register')}>
              <Text style={styles.switchLink}>Create account</Text>
            </TouchableOpacity>
          </View>

          <View style={styles.legalRow}>
            <TouchableOpacity onPress={() => navigation.navigate('PrivacyPolicy')}>
              <Text style={styles.legalLink}>Privacy Policy</Text>
            </TouchableOpacity>
            <Text style={styles.legalDot}> · </Text>
            <TouchableOpacity onPress={() => navigation.navigate('TermsOfService')}>
              <Text style={styles.legalLink}>Terms of Service</Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

// ── Register Screen ───────────────────────────────────────────────────────────
export function RegisterScreen({ navigation }: any) {
  const { register, isLoading, error, clearError } = useAuthStore();
  const [step, setStep] = useState(1);
  const [form, setForm] = useState({
    name: '', email: '', password: '', confirmPassword: '',
    age: '', gender: '', orientation: '', interests: [] as string[],
  });

  const update = (key: string, val: any) => setForm(prev => ({ ...prev, [key]: val }));

  const toggleInterest = (i: string) => {
    const list = form.interests.includes(i)
      ? form.interests.filter(x => x !== i)
      : [...form.interests, i];
    update('interests', list);
  };

  const nextStep = () => {
    if (step === 1) {
      if (!form.name.trim()) { Alert.alert('Required', 'Please enter your name.'); return; }
      if (!form.email.trim()) { Alert.alert('Required', 'Please enter your email.'); return; }
      if (form.password.length < 8) { Alert.alert('Weak password', 'Password must be at least 8 characters.'); return; }
      if (form.password !== form.confirmPassword) { Alert.alert('Mismatch', 'Passwords do not match.'); return; }
    }
    if (step === 2) {
      if (!form.age || parseInt(form.age) < 18) { Alert.alert('Age required', 'You must be 18+ to use Spark.'); return; }
      if (!form.gender) { Alert.alert('Required', 'Please select your gender.'); return; }
      if (!form.orientation) { Alert.alert('Required', 'Please select your orientation.'); return; }
    }
    if (step < 3) setStep(step + 1);
    else handleRegister();
  };

  const handleRegister = async () => {
    try {
      await register({
        name: form.name.trim(),
        email: form.email.trim(),
        password: form.password,
        age: parseInt(form.age),
        gender: form.gender.toLowerCase(),
        orientation: form.orientation.toLowerCase(),
        interests: form.interests,
      });
    } catch {}
  };

  return (
    <SafeAreaView style={styles.container} edges={['top', 'bottom']}>
      <PrideBar />
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        {/* Progress bar */}
        <View style={styles.progressBar}>
          {[1, 2, 3].map(s => (
            <View key={s} style={[styles.progressSegment, step >= s && styles.progressSegmentActive]} />
          ))}
        </View>

        <ScrollView contentContainerStyle={styles.authContent} keyboardShouldPersistTaps="handled">
          {step === 1 && (
            <>
              <Text style={styles.stepTitle}>Create your account</Text>
              <Text style={styles.stepSub}>It's free and only takes a minute</Text>
              {error && <View style={styles.errorBanner}><Text style={styles.errorText}>{error}</Text></View>}
              <AuthInput label="Your Name" value={form.name} onChangeText={v => update('name', v)} placeholder="What should we call you?" autoCapitalize="words" />
              <AuthInput label="Email" value={form.email} onChangeText={v => update('email', v)} placeholder="your@email.com" keyboardType="email-address" autoCapitalize="none" />
              <AuthInput label="Password (8+ characters)" value={form.password} onChangeText={v => update('password', v)} placeholder="Create a strong password" secureTextEntry />
              <AuthInput label="Confirm Password" value={form.confirmPassword} onChangeText={v => update('confirmPassword', v)} placeholder="Repeat your password" secureTextEntry />
            </>
          )}

          {step === 2 && (
            <>
              <Text style={styles.stepTitle}>Tell us about yourself</Text>
              <Text style={styles.stepSub}>This helps us find the right matches for you</Text>
              <AuthInput label="Age" value={form.age} onChangeText={v => update('age', v)} placeholder="Must be 18+" keyboardType="numeric" />
              <Text style={styles.inputLabel}>I am</Text>
              <View style={styles.chipsWrap}>
                {GENDERS.map(g => <OptionChip key={g} label={g} selected={form.gender === g} onPress={() => update('gender', g)} />)}
              </View>
              <Text style={[styles.inputLabel, { marginTop: 16 }]}>I identify as</Text>
              <View style={styles.chipsWrap}>
                {ORIENTATIONS.map(o => <OptionChip key={o} label={o} selected={form.orientation === o} onPress={() => update('orientation', o)} />)}
              </View>
            </>
          )}

          {step === 3 && (
            <>
              <Text style={styles.stepTitle}>Your interests ✨</Text>
              <Text style={styles.stepSub}>Pick a few things you're into (you can always change later)</Text>
              <View style={styles.chipsWrap}>
                {INTERESTS_LIST.map(i => <OptionChip key={i} label={i} selected={form.interests.includes(i)} onPress={() => toggleInterest(i)} />)}
              </View>
            </>
          )}

          <TouchableOpacity style={styles.primaryBtn} onPress={nextStep} disabled={isLoading} activeOpacity={0.85}>
            {isLoading ? <ActivityIndicator color="#000" /> : (
              <Text style={styles.primaryBtnText}>{step < 3 ? 'Continue →' : '🔥 Create Account'}</Text>
            )}
          </TouchableOpacity>

          {step > 1 && (
            <TouchableOpacity style={styles.backBtnRow} onPress={() => setStep(step - 1)}>
              <Text style={styles.backBtnText}>← Back</Text>
            </TouchableOpacity>
          )}

          {step === 1 && (
            <View style={styles.switchRow}>
              <Text style={styles.switchText}>Already have an account? </Text>
              <TouchableOpacity onPress={() => navigation.navigate('Login')}>
                <Text style={styles.switchLink}>Log In</Text>
              </TouchableOpacity>
            </View>
          )}

          <View style={styles.legalRow}>
            <Text style={{ fontSize: 11, color: Colors.text3, textAlign: 'center' }}>
              By continuing you agree to our{' '}
            </Text>
            <TouchableOpacity onPress={() => navigation.navigate('TermsOfService')}>
              <Text style={styles.legalLink}>Terms</Text>
            </TouchableOpacity>
            <Text style={styles.legalDot}> & </Text>
            <TouchableOpacity onPress={() => navigation.navigate('PrivacyPolicy')}>
              <Text style={styles.legalLink}>Privacy Policy</Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

// ── Forgot Password ───────────────────────────────────────────────────────────
export function ForgotPasswordScreen({ navigation }: any) {
  const [email, setEmail] = useState('');
  const [sent, setSent] = useState(false);
  const [loading, setLoading] = useState(false);
  const { authAPI } = require('../services/api');

  const handleSubmit = async () => {
    if (!email.trim()) { Alert.alert('Required', 'Enter your email address.'); return; }
    setLoading(true);
    try {
      await authAPI.forgotPassword(email.trim());
      setSent(true);
    } catch {
      Alert.alert('Error', 'Something went wrong. Please try again.');
    } finally { setLoading(false); }
  };

  return (
    <SafeAreaView style={styles.container} edges={['top', 'bottom']}>
      <PrideBar />
      <View style={styles.authContent}>
        <TouchableOpacity style={styles.backBtnRow} onPress={() => navigation.goBack()}>
          <Text style={styles.backBtnText}>← Back</Text>
        </TouchableOpacity>
        <Text style={styles.stepTitle}>Reset Password</Text>
        {sent ? (
          <View style={{ alignItems: 'center', gap: 16, marginTop: 24 }}>
            <Text style={{ fontSize: 60 }}>📬</Text>
            <Text style={{ fontSize: 18, fontWeight: '800', color: Colors.text, textAlign: 'center' }}>Check your email</Text>
            <Text style={{ fontSize: 14, color: Colors.text2, textAlign: 'center', lineHeight: 22 }}>
              We sent a password reset link to {email}. It expires in 10 minutes.
            </Text>
            <TouchableOpacity style={styles.primaryBtn} onPress={() => navigation.navigate('Login')}>
              <Text style={styles.primaryBtnText}>Back to Login</Text>
            </TouchableOpacity>
          </View>
        ) : (
          <>
            <Text style={styles.stepSub}>Enter your email and we'll send you a reset link</Text>
            <AuthInput label="Email" value={email} onChangeText={setEmail} placeholder="your@email.com" keyboardType="email-address" autoCapitalize="none" />
            <TouchableOpacity style={styles.primaryBtn} onPress={handleSubmit} disabled={loading}>
              {loading ? <ActivityIndicator color="#000" /> : <Text style={styles.primaryBtnText}>Send Reset Link</Text>}
            </TouchableOpacity>
          </>
        )}
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.bg },
  authContent: { padding: Spacing.xl, paddingBottom: 40, flexGrow: 1 },
  logoArea: { alignItems: 'center', paddingVertical: 32 },
  logoText: { fontSize: 42, fontWeight: '900', color: Colors.pink, letterSpacing: -1 },
  logoTagline: { fontSize: 16, color: Colors.text2, marginTop: 6 },
  progressBar: { flexDirection: 'row', gap: 6, paddingHorizontal: 20, paddingVertical: 12 },
  progressSegment: { flex: 1, height: 4, borderRadius: 2, backgroundColor: Colors.bg3 },
  progressSegmentActive: { backgroundColor: Colors.accent },
  stepTitle: { fontSize: 26, fontWeight: '900', color: Colors.text, marginBottom: 6 },
  stepSub: { fontSize: 14, color: Colors.text2, marginBottom: 24, lineHeight: 22 },
  inputGroup: { marginBottom: 16 },
  inputLabel: { fontSize: 13, fontWeight: '700', color: Colors.text2, marginBottom: 6 },
  input: { backgroundColor: Colors.bg3, borderWidth: 1, borderColor: Colors.border, borderRadius: Radius.md, paddingHorizontal: 14, paddingVertical: 13, color: Colors.text, fontSize: 14 },
  passwordRow: { flexDirection: 'row', alignItems: 'center', backgroundColor: Colors.bg3, borderWidth: 1, borderColor: Colors.border, borderRadius: Radius.md, paddingRight: 12 },
  showPassBtn: { padding: 8 },
  forgotBtn: { alignSelf: 'flex-end', marginBottom: 16, marginTop: -8 },
  forgotText: { fontSize: 13, color: Colors.pink, fontWeight: '700' },
  primaryBtn: { backgroundColor: Colors.accent, paddingVertical: 15, borderRadius: Radius.lg, alignItems: 'center', justifyContent: 'center', marginBottom: 16 },
  primaryBtnText: { color: '#000', fontSize: 16, fontWeight: '900' },
  dividerRow: { flexDirection: 'row', alignItems: 'center', gap: 12, marginVertical: 8 },
  dividerLine: { flex: 1, height: 1, backgroundColor: Colors.border },
  dividerText: { fontSize: 13, color: Colors.text3, fontWeight: '600' },
  socialBtn: { flexDirection: 'row', alignItems: 'center', gap: 10, backgroundColor: Colors.bg3, borderWidth: 1, borderColor: Colors.border, borderRadius: Radius.lg, paddingVertical: 13, paddingHorizontal: 20, marginBottom: 10 },
  socialBtnText: { fontSize: 15, fontWeight: '700', color: Colors.text },
  switchRow: { flexDirection: 'row', justifyContent: 'center', marginTop: 16 },
  switchText: { fontSize: 14, color: Colors.text2 },
  switchLink: { fontSize: 14, color: Colors.pink, fontWeight: '800' },
  legalRow: { flexDirection: 'row', justifyContent: 'center', alignItems: 'center', marginTop: 16, flexWrap: 'wrap' },
  legalLink: { fontSize: 12, color: Colors.text2, textDecorationLine: 'underline' },
  legalDot: { fontSize: 12, color: Colors.text3 },
  errorBanner: { backgroundColor: 'rgba(255,75,110,0.15)', borderRadius: Radius.md, padding: 12, marginBottom: 16, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', borderWidth: 1, borderColor: Colors.pink },
  errorText: { fontSize: 13, color: Colors.pink, flex: 1 },
  chipsWrap: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  chip: { paddingHorizontal: 14, paddingVertical: 8, borderRadius: Radius.full, borderWidth: 1.5, borderColor: Colors.border, backgroundColor: 'transparent' },
  chipActive: { borderColor: Colors.accent, backgroundColor: 'rgba(232,255,71,0.1)' },
  chipText: { fontSize: 13, fontWeight: '700', color: Colors.text2 },
  chipTextActive: { color: Colors.accent },
  backBtnRow: { alignSelf: 'flex-start', marginBottom: 16 },
  backBtnText: { fontSize: 14, color: Colors.text2, fontWeight: '700' },
});
