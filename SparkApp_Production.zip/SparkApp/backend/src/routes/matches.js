const { matchRoutes, messageRoutes, postRoutes, communityRoutes, mediaRoutes, reportRoutes, notificationRoutes, premiumRoutes, profileRoutes } = require('./allRoutes');
module.exports = matchRoutes;
