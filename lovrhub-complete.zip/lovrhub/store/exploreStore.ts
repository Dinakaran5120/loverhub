import { create } from "zustand";
import type { ExplorePost, ExploreFeedTab, VibeType, PostAuthor } from "@/types/explore";
import { MOCK_EXPLORE_POSTS } from "@/data/mockExplorePosts";
import { Colors } from "@constants/theme";

interface ExploreState {
  posts: ExplorePost[];
  activeTab: ExploreFeedTab;
  showComments: string | null;   // post id whose comments sheet is open
  showCreatePost: boolean;

  // Actions
  setActiveTab: (tab: ExploreFeedTab) => void;
  reactVibe: (postId: string, vibe: VibeType) => void;
  likeComment: (postId: string, commentId: string) => void;
  addComment: (postId: string, text: string) => void;
  sharePost: (postId: string) => void;
  addPost: (post: Omit<ExplorePost, "id" | "vibes" | "comments" | "shares" | "createdAt">) => void;
  setShowComments: (postId: string | null) => void;
  setShowCreatePost: (show: boolean) => void;
}

const ME: PostAuthor = {
  id: "me",
  name: "You",
  avatarEmoji: "😊",
  gradient: [Colors.primary, Colors.accent],
  verified: false,
  isAnonymous: false,
};

export const useExploreStore = create<ExploreState>((set, get) => ({
  posts: MOCK_EXPLORE_POSTS,
  activeTab: "forYou",
  showComments: null,
  showCreatePost: false,

  setActiveTab: (tab) => set({ activeTab: tab }),

  reactVibe: (postId, vibe) =>
    set((state) => ({
      posts: state.posts.map((post) => {
        if (post.id !== postId) return post;
        const vibes = post.vibes.map((v) => {
          if (v.emoji !== vibe) {
            // If user is toggling off another reaction, remove it
            return v.reacted ? { ...v, count: v.count - 1, reacted: false } : v;
          }
          // Toggle the selected vibe
          return v.reacted
            ? { ...v, count: Math.max(0, v.count - 1), reacted: false }
            : { ...v, count: v.count + 1, reacted: true };
        });
        return { ...post, vibes };
      }),
    })),

  likeComment: (postId, commentId) =>
    set((state) => ({
      posts: state.posts.map((post) => {
        if (post.id !== postId) return post;
        return {
          ...post,
          comments: post.comments.map((c) =>
            c.id === commentId
              ? { ...c, liked: !c.liked, likes: c.liked ? c.likes - 1 : c.likes + 1 }
              : c
          ),
        };
      }),
    })),

  addComment: (postId, text) => {
    if (!text.trim()) return;
    const newComment = {
      id: `c_${Date.now()}`,
      author: ME,
      text: text.trim(),
      createdAt: new Date().toISOString(),
      likes: 0,
      liked: false,
    };
    set((state) => ({
      posts: state.posts.map((post) =>
        post.id === postId
          ? { ...post, comments: [...post.comments, newComment] }
          : post
      ),
    }));
  },

  sharePost: (postId) =>
    set((state) => ({
      posts: state.posts.map((post) =>
        post.id === postId ? { ...post, shares: post.shares + 1 } : post
      ),
    })),

  addPost: (postData) => {
    const newPost: ExplorePost = {
      ...postData,
      id: `p_${Date.now()}`,
      vibes: [
        { emoji: "❤️", count: 0, reacted: false },
        { emoji: "😂", count: 0, reacted: false },
        { emoji: "🔥", count: 0, reacted: false },
        { emoji: "😮", count: 0, reacted: false },
        { emoji: "💔", count: 0, reacted: false },
        { emoji: "✨", count: 0, reacted: false },
      ],
      comments: [],
      shares: 0,
      createdAt: new Date().toISOString(),
    };
    set((state) => ({ posts: [newPost, ...state.posts] }));
  },

  setShowComments: (postId) => set({ showComments: postId }),
  setShowCreatePost: (show) => set({ showCreatePost: show }),
}));
