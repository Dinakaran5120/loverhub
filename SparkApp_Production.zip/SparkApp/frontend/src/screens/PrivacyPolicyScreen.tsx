import React, { useState } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Colors, Spacing, Radius } from '../utils/theme';
import { PrideBar } from '../components/SharedComponents';

const SECTIONS = [
  {
    title: '1. Information We Collect',
    icon: '📋',
    content: `We collect information you provide directly to us when you create an account, including your name, email address, date of birth, gender identity, sexual orientation, photos, and any other information you choose to include in your profile.

We also collect information automatically when you use our Services:
• Location data (with your permission) to show you nearby matches
• Device information (model, OS, unique device identifiers)
• Usage data (features used, swipe activity, match interactions)
• Log data (IP address, browser type, pages visited)
• Camera and photo library access (only when you choose to upload content)`,
  },
  {
    title: '2. How We Use Your Information',
    icon: '🔍',
    content: `We use the information we collect to:
• Provide, maintain, and improve our Services
• Show you potential matches based on your preferences and location
• Enable real-time messaging with your matches
• Send you notifications about matches, messages, and app activity
• Personalize your experience and show relevant content
• Verify your identity and prevent fraud
• Comply with legal obligations
• Process payments for premium subscriptions

We never sell your personal data to third parties for advertising purposes.`,
  },
  {
    title: '3. Sharing of Information',
    icon: '🤝',
    content: `Your profile information is visible to other users as part of the normal functioning of the app. We share your information with:

• Other users: Your profile, photos, and any information you share on the platform
• Service providers: Cloud storage (Cloudinary), payment processing (Stripe), push notifications (Firebase), analytics providers — all bound by strict confidentiality agreements
• Legal authorities: When required by law, court order, or to protect rights and safety

We do not share your precise GPS coordinates with other users — only your approximate distance.`,
  },
  {
    title: '4. LGBTQ+ & Sensitive Data',
    icon: '🏳️‍🌈',
    content: `We understand that sexual orientation and gender identity are sensitive personal data. We treat this information with the highest level of protection.

• Your orientation and gender identity are only shared with potential matches you see in discovery
• You control exactly what appears on your profile
• We never use this data to target you with advertising
• Anonymous mood posting allows expression without revealing identity
• In regions where LGBTQ+ identities face legal risk, we recommend using additional privacy settings such as incognito mode

We are committed to being a safe space for everyone regardless of sexual orientation, gender identity, or relationship preference.`,
  },
  {
    title: '5. Data Retention & Deletion',
    icon: '🗑️',
    content: `You can delete your account at any time from Settings → Delete Account. Upon deletion:

• Your profile is immediately hidden from other users
• Your data is soft-deleted and retained for 30 days to allow recovery
• After 30 days, personal data is permanently purged from our servers
• Some data may be retained longer if required by law (e.g., payment records for 7 years)
• Anonymized, aggregated data may be retained indefinitely for analytics

To request immediate deletion of all data, email privacy@sparkdating.app`,
  },
  {
    title: '6. Security',
    icon: '🔒',
    content: `We implement industry-standard security measures to protect your information:

• All data transmitted between your device and our servers is encrypted using TLS 1.3
• Passwords are hashed using bcrypt with a cost factor of 12
• JWT tokens expire after 30 days and are stored in secure device storage
• Photos are stored on Cloudinary with access controls
• We conduct regular security audits and penetration testing
• We have a responsible disclosure program for security researchers

Despite these measures, no system is 100% secure. Please use a strong, unique password and enable notifications for suspicious activity.`,
  },
  {
    title: '7. Your Rights (GDPR / CCPA)',
    icon: '⚖️',
    content: `Depending on your location, you may have the following rights regarding your personal data:

• Right to Access: Request a copy of all data we hold about you
• Right to Rectification: Correct inaccurate personal data
• Right to Erasure: Request deletion of your personal data ("right to be forgotten")
• Right to Restriction: Limit how we process your data
• Right to Data Portability: Receive your data in a machine-readable format
• Right to Object: Object to processing based on legitimate interests
• Right to Withdraw Consent: Withdraw consent at any time

To exercise these rights, contact us at privacy@sparkdating.app. We will respond within 30 days.`,
  },
  {
    title: '8. Cookies & Tracking',
    icon: '🍪',
    content: `Our mobile app does not use browser cookies. We use the following tracking technologies:

• Analytics SDKs to understand app usage patterns (anonymized)
• Crash reporting tools to identify and fix bugs
• Attribution tools to understand how users find our app

You can opt out of analytics tracking in Settings → Privacy & Safety → Analytics.`,
  },
  {
    title: '9. Children\'s Privacy',
    icon: '👶',
    content: `Spark is strictly for users aged 18 and over. We do not knowingly collect personal information from anyone under 18.

If you believe a minor has created an account, please report it immediately through the in-app reporting feature or email safety@sparkdating.app. We will investigate and remove the account promptly.

Age verification is performed during registration and we reserve the right to require additional age verification at any time.`,
  },
  {
    title: '10. Contact Us',
    icon: '📬',
    content: `If you have questions about this Privacy Policy or our data practices:

• Email: privacy@sparkdating.app
• Data Protection Officer: dpo@sparkdating.app
• Safety Team: safety@sparkdating.app
• Address: Spark Dating Inc., [Your Address]

For GDPR inquiries, you also have the right to lodge a complaint with your local data protection authority.

This Privacy Policy was last updated: April 2026`,
  },
];

export default function PrivacyPolicyScreen({ navigation }: any) {
  const [expanded, setExpanded] = useState<number | null>(0);

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <PrideBar />
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
          <Text style={{ fontSize: 22, color: Colors.text }}>←</Text>
        </TouchableOpacity>
        <Text style={styles.title}>Privacy Policy</Text>
        <View style={{ width: 40 }} />
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ padding: 16 }}>
        <View style={styles.heroBanner}>
          <Text style={styles.heroEmoji}>🔒</Text>
          <Text style={styles.heroTitle}>Your Privacy Matters</Text>
          <Text style={styles.heroSub}>
            Spark is built on trust. We are transparent about what data we collect,
            why we collect it, and how you can control it.
          </Text>
        </View>

        <View style={styles.effectiveDate}>
          <Text style={styles.effectiveDateText}>Effective Date: April 1, 2026</Text>
          <Text style={styles.effectiveDateText}>Version: 1.0</Text>
        </View>

        {SECTIONS.map((section, index) => (
          <TouchableOpacity
            key={index}
            style={[styles.section, expanded === index && styles.sectionExpanded]}
            onPress={() => setExpanded(expanded === index ? null : index)}
            activeOpacity={0.85}
          >
            <View style={styles.sectionHeader}>
              <View style={styles.sectionHeaderLeft}>
                <Text style={styles.sectionIcon}>{section.icon}</Text>
                <Text style={styles.sectionTitle}>{section.title}</Text>
              </View>
              <Text style={[styles.chevron, expanded === index && styles.chevronOpen]}>›</Text>
            </View>
            {expanded === index && (
              <Text style={styles.sectionContent}>{section.content}</Text>
            )}
          </TouchableOpacity>
        ))}

        <View style={styles.footer}>
          <Text style={styles.footerText}>
            By using Spark, you agree to this Privacy Policy. We reserve the right to update
            this policy and will notify you of significant changes via email or in-app notification.
          </Text>
          <TouchableOpacity
            style={styles.contactBtn}
            onPress={() => navigation.navigate('HelpCenter')}
          >
            <Text style={styles.contactBtnText}>📩 Contact Privacy Team</Text>
          </TouchableOpacity>
        </View>

        <View style={{ height: 32 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.bg },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: Spacing.xl, paddingVertical: Spacing.md },
  backBtn: { width: 40, height: 40, alignItems: 'center', justifyContent: 'center' },
  title: { fontSize: 18, fontWeight: '900', color: Colors.text },
  heroBanner: { backgroundColor: Colors.bg3, borderRadius: Radius.xl, padding: 20, alignItems: 'center', marginBottom: 16, borderWidth: 1, borderColor: Colors.border },
  heroEmoji: { fontSize: 44, marginBottom: 10 },
  heroTitle: { fontSize: 20, fontWeight: '900', color: Colors.text, marginBottom: 8, textAlign: 'center' },
  heroSub: { fontSize: 13, color: Colors.text2, textAlign: 'center', lineHeight: 20 },
  effectiveDate: { flexDirection: 'row', justifyContent: 'space-between', paddingHorizontal: 4, marginBottom: 16 },
  effectiveDateText: { fontSize: 12, color: Colors.text3, fontWeight: '600' },
  section: { backgroundColor: Colors.bg2, borderRadius: Radius.xl, marginBottom: 10, overflow: 'hidden', borderWidth: 1, borderColor: Colors.border },
  sectionExpanded: { borderColor: Colors.accent },
  sectionHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 16 },
  sectionHeaderLeft: { flexDirection: 'row', alignItems: 'center', gap: 10, flex: 1 },
  sectionIcon: { fontSize: 20 },
  sectionTitle: { fontSize: 14, fontWeight: '800', color: Colors.text, flex: 1 },
  chevron: { fontSize: 22, color: Colors.text3, transform: [{ rotate: '0deg' }] },
  chevronOpen: { transform: [{ rotate: '90deg' }], color: Colors.accent },
  sectionContent: { fontSize: 13, color: Colors.text2, lineHeight: 22, padding: 16, paddingTop: 0 },
  footer: { backgroundColor: Colors.bg3, borderRadius: Radius.xl, padding: 20, marginTop: 8, gap: 16, borderWidth: 1, borderColor: Colors.border },
  footerText: { fontSize: 12, color: Colors.text2, lineHeight: 20, textAlign: 'center' },
  contactBtn: { backgroundColor: Colors.bg4, borderRadius: Radius.lg, paddingVertical: 12, alignItems: 'center', borderWidth: 1, borderColor: Colors.border },
  contactBtnText: { fontSize: 14, fontWeight: '700', color: Colors.text },
});
