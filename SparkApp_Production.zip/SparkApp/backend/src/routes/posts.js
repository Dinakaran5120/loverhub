const { postRoutes } = require('./allRoutes'); module.exports = postRoutes;
