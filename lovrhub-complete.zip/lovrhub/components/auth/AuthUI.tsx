import { useState } from "react";
import {
  View, Text, TextInput, Pressable,
  TextInputProps, ActivityIndicator, ViewStyle,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { Colors } from "@constants/theme";

// ─── Progress Bar ─────────────────────────────────────────────────────────────
export function AuthProgressBar({ current, total }: { current: number; total: number }) {
  const pct = Math.min((current / total) * 100, 100);
  return (
    <View style={{ paddingHorizontal: 24, paddingTop: 12, paddingBottom: 4 }}>
      <View style={{ height: 4, borderRadius: 2, backgroundColor: Colors.border, overflow: "hidden" }}>
        <LinearGradient
          colors={[Colors.primary, Colors.accent]}
          start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
          style={{ width: `${pct}%`, height: "100%", borderRadius: 2 }}
        />
      </View>
      <Text style={{ fontSize: 11, color: Colors.textMuted, marginTop: 4, textAlign: "right", fontWeight: "600" }}>
        {current}/{total}
      </Text>
    </View>
  );
}

// ─── Back Button ──────────────────────────────────────────────────────────────
export function BackButton({ onPress }: { onPress: () => void }) {
  return (
    <Pressable
      onPress={onPress}
      hitSlop={12}
      style={({ pressed }) => ({
        opacity: pressed ? 0.6 : 1,
        width: 40, height: 40, borderRadius: 14,
        backgroundColor: Colors.card,
        borderWidth: 1, borderColor: Colors.border,
        alignItems: "center", justifyContent: "center",
        marginLeft: 20, marginTop: 8,
      })}
    >
      <Text style={{ fontSize: 18, color: Colors.text }}>←</Text>
    </Pressable>
  );
}

// ─── Auth Input ───────────────────────────────────────────────────────────────
interface AuthInputProps extends TextInputProps {
  label?: string;
  prefix?: string;
  error?: string;
  hint?: string;
}

export function AuthInput({ label, prefix, error, hint, style, ...props }: AuthInputProps) {
  const [focused, setFocused] = useState(false);
  return (
    <View style={{ marginBottom: 4 }}>
      {label && (
        <Text style={{ fontSize: 13, fontWeight: "700", color: Colors.textSecondary, marginBottom: 8, letterSpacing: 0.3 }}>
          {label}
        </Text>
      )}
      <View
        style={{
          flexDirection: "row", alignItems: "center",
          backgroundColor: Colors.surface, borderRadius: 16,
          borderWidth: focused ? 1.5 : 1,
          borderColor: error ? Colors.primary : focused ? Colors.accent : Colors.border,
          paddingHorizontal: 16, paddingVertical: 14, gap: 8,
        }}
      >
        {prefix && (
          <Text style={{ fontSize: 15, color: Colors.textSecondary, fontWeight: "600" }}>{prefix}</Text>
        )}
        <TextInput
          placeholderTextColor={Colors.textMuted}
          onFocus={() => setFocused(true)}
          onBlur={() => setFocused(false)}
          style={[{ flex: 1, fontSize: 16, color: Colors.text, padding: 0 }, style]}
          {...props}
        />
      </View>
      {error ? (
        <Text style={{ fontSize: 12, color: Colors.primary, marginTop: 6, fontWeight: "600" }}>{error}</Text>
      ) : hint ? (
        <Text style={{ fontSize: 12, color: Colors.textMuted, marginTop: 6 }}>{hint}</Text>
      ) : null}
    </View>
  );
}

// ─── Primary Button ───────────────────────────────────────────────────────────
interface PrimaryBtnProps {
  label: string;
  onPress: () => void;
  loading?: boolean;
  disabled?: boolean;
  style?: ViewStyle;
  icon?: string;
}

export function PrimaryButton({ label, onPress, loading, disabled, style, icon }: PrimaryBtnProps) {
  return (
    <Pressable
      onPress={onPress}
      disabled={disabled || loading}
      style={({ pressed }) => ({
        opacity: disabled ? 0.5 : pressed ? 0.88 : 1,
        transform: [{ scale: pressed ? 0.97 : 1 }],
        ...style,
      })}
    >
      <LinearGradient
        colors={[Colors.primary, Colors.accent]}
        start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
        style={{
          borderRadius: 18, paddingVertical: 18,
          flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8,
          shadowColor: Colors.primary, shadowOffset: { width: 0, height: 6 },
          shadowOpacity: 0.35, shadowRadius: 14, elevation: 6,
        }}
      >
        {loading ? (
          <ActivityIndicator color="#fff" size="small" />
        ) : (
          <>
            <Text style={{ color: "#fff", fontSize: 16, fontWeight: "800", letterSpacing: 0.3 }}>{label}</Text>
            {icon && <Text style={{ fontSize: 18 }}>{icon}</Text>}
          </>
        )}
      </LinearGradient>
    </Pressable>
  );
}

// ─── Ghost Button ─────────────────────────────────────────────────────────────
interface GhostBtnProps {
  label: string;
  onPress: () => void;
  icon?: string;
  style?: ViewStyle;
}

export function GhostButton({ label, onPress, icon, style }: GhostBtnProps) {
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => ({
        borderRadius: 18, paddingVertical: 17,
        flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8,
        borderWidth: 1.5, borderColor: Colors.border, backgroundColor: Colors.surface,
        opacity: pressed ? 0.7 : 1,
        ...style,
      })}
    >
      {icon && <Text style={{ fontSize: 20 }}>{icon}</Text>}
      <Text style={{ color: Colors.text, fontSize: 15, fontWeight: "700" }}>{label}</Text>
    </Pressable>
  );
}

// ─── Select Chip ──────────────────────────────────────────────────────────────
interface ChipProps {
  label: string;
  selected: boolean;
  onPress: () => void;
  emoji?: string;
  gradientColors?: [string, string];
}

export function SelectChip({ label, selected, onPress, emoji, gradientColors }: ChipProps) {
  const grad = gradientColors ?? ([Colors.primary, Colors.accent] as [string, string]);
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => ({ opacity: pressed ? 0.75 : 1 })}
    >
      {selected ? (
        <LinearGradient
          colors={grad}
          start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
          style={{ paddingHorizontal: 16, paddingVertical: 10, borderRadius: 20, flexDirection: "row", alignItems: "center", gap: 6 }}
        >
          {emoji && <Text style={{ fontSize: 15 }}>{emoji}</Text>}
          <Text style={{ color: "#fff", fontSize: 14, fontWeight: "700" }}>{label}</Text>
          <Text style={{ color: "rgba(255,255,255,0.8)", fontSize: 13 }}>✓</Text>
        </LinearGradient>
      ) : (
        <View
          style={{
            paddingHorizontal: 16, paddingVertical: 10, borderRadius: 20,
            flexDirection: "row", alignItems: "center", gap: 6,
            borderWidth: 1.5, borderColor: Colors.border, backgroundColor: Colors.card,
          }}
        >
          {emoji && <Text style={{ fontSize: 15 }}>{emoji}</Text>}
          <Text style={{ color: Colors.textSecondary, fontSize: 14, fontWeight: "600" }}>{label}</Text>
        </View>
      )}
    </Pressable>
  );
}

// ─── Step Header ──────────────────────────────────────────────────────────────
export function StepHeader({ emoji, title, subtitle }: { emoji: string; title: string; subtitle: string }) {
  return (
    <View style={{ paddingHorizontal: 24, paddingTop: 8, paddingBottom: 24 }}>
      <Text style={{ fontSize: 40, marginBottom: 12 }}>{emoji}</Text>
      <Text style={{ fontSize: 28, fontWeight: "800", color: Colors.text, letterSpacing: -0.5, marginBottom: 8 }}>
        {title}
      </Text>
      <Text style={{ fontSize: 15, color: Colors.textSecondary, lineHeight: 22 }}>{subtitle}</Text>
    </View>
  );
}
