import { create } from 'zustand';
import * as SecureStore from 'expo-secure-store';
import { authAPI, userAPI } from '../services/api';

interface User {
  _id: string;
  name: string;
  email?: string;
  phone?: string;
  age: number;
  gender: string;
  orientation: string;
  lookingFor?: string;
  bio?: string;
  interests?: string[];
  photos?: Array<{ url: string; publicId: string; isMain: boolean }>;
  profileComplete: boolean;
  premium: { isActive: boolean; plan: string };
  settings: any;
  isOnline?: boolean;
}

interface AuthState {
  token: string | null;
  user: User | null;
  isLoading: boolean;
  isInitialized: boolean;
  error: string | null;
  login: (email: string, password: string) => Promise<void>;
  register: (data: any) => Promise<void>;
  logout: () => Promise<void>;
  deleteAccount: (password: string, reason: string) => Promise<void>;
  updateProfile: (data: any) => Promise<void>;
  updateSettings: (settings: any) => Promise<void>;
  initialize: () => Promise<void>;
  clearError: () => void;
}

export const useAuthStore = create<AuthState>((set, get) => ({
  token: null,
  user: null,
  isLoading: false,
  isInitialized: false,
  error: null,

  initialize: async () => {
    try {
      const token = await SecureStore.getItemAsync('spark_token');
      if (token) {
        const res = await authAPI.getMe();
        set({ token, user: res.data.user, isInitialized: true });
      } else {
        set({ isInitialized: true });
      }
    } catch {
      await SecureStore.deleteItemAsync('spark_token');
      set({ token: null, user: null, isInitialized: true });
    }
  },

  login: async (email, password) => {
    set({ isLoading: true, error: null });
    try {
      const res = await authAPI.login(email, password);
      const { token, user } = res.data;
      await SecureStore.setItemAsync('spark_token', token);
      set({ token, user, isLoading: false });
    } catch (err: any) {
      set({ error: err.response?.data?.message || 'Login failed.', isLoading: false });
      throw err;
    }
  },

  register: async (data) => {
    set({ isLoading: true, error: null });
    try {
      const res = await authAPI.register(data);
      const { token, user } = res.data;
      await SecureStore.setItemAsync('spark_token', token);
      set({ token, user, isLoading: false });
    } catch (err: any) {
      set({ error: err.response?.data?.message || 'Registration failed.', isLoading: false });
      throw err;
    }
  },

  logout: async () => {
    try { await authAPI.logout(); } catch {}
    await SecureStore.deleteItemAsync('spark_token');
    set({ token: null, user: null });
  },

  deleteAccount: async (password, reason) => {
    set({ isLoading: true, error: null });
    try {
      await authAPI.deleteAccount(password, reason);
      await SecureStore.deleteItemAsync('spark_token');
      set({ token: null, user: null, isLoading: false });
    } catch (err: any) {
      set({ error: err.response?.data?.message || 'Failed to delete account.', isLoading: false });
      throw err;
    }
  },

  updateProfile: async (data) => {
    set({ isLoading: true });
    try {
      const res = await userAPI.updateProfile(data);
      set({ user: res.data.user, isLoading: false });
    } catch (err: any) {
      set({ error: err.response?.data?.message, isLoading: false });
      throw err;
    }
  },

  updateSettings: async (settings) => {
    try {
      await userAPI.updateSettings(settings);
      set((state) => ({ user: state.user ? { ...state.user, settings: { ...state.user.settings, ...settings } } : null }));
    } catch (err: any) {
      throw err;
    }
  },

  clearError: () => set({ error: null }),
}));
