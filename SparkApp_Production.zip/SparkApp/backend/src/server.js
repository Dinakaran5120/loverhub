const express = require('express');
const http = require('http');
const socketIO = require('socket.io');
const mongoose = require('mongoose');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const compression = require('compression');
const rateLimit = require('express-rate-limit');
const mongoSanitize = require('express-mongo-sanitize');
const hpp = require('hpp');
require('dotenv').config();

const app = express();
const server = http.createServer(app);
const io = socketIO(server, {
  cors: { origin: process.env.CLIENT_URL || '*', methods: ['GET', 'POST'] }
});

// ── Security Middleware ────────────────────────────────────────────────────────
app.use(helmet());
app.use(mongoSanitize());
app.use(hpp());
app.use(cors({ origin: process.env.CLIENT_URL || '*', credentials: true }));
app.use(compression());
app.use(morgan('dev'));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// ── Rate Limiting ──────────────────────────────────────────────────────────────
const limiter = rateLimit({
  windowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS) || 15 * 60 * 1000,
  max: parseInt(process.env.RATE_LIMIT_MAX) || 100,
  message: { success: false, message: 'Too many requests, please try again later.' }
});
const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 20 });
app.use('/api/', limiter);
app.use('/api/auth', authLimiter);

// ── Routes ─────────────────────────────────────────────────────────────────────
app.use('/api/auth',        require('./routes/auth'));
app.use('/api/users',       require('./routes/users'));
app.use('/api/profiles',    require('./routes/profiles'));
app.use('/api/swipes',      require('./routes/swipes'));
app.use('/api/matches',     require('./routes/matches'));
app.use('/api/messages',    require('./routes/messages'));
app.use('/api/posts',       require('./routes/posts'));
app.use('/api/communities', require('./routes/communities'));
app.use('/api/media',       require('./routes/media'));
app.use('/api/premium',     require('./routes/premium'));
app.use('/api/reports',     require('./routes/reports'));
app.use('/api/notifications', require('./routes/notifications'));

// ── Health Check ───────────────────────────────────────────────────────────────
app.get('/health', (req, res) => res.json({ status: 'OK', timestamp: new Date() }));

// ── Socket.io Real-time ────────────────────────────────────────────────────────
const onlineUsers = new Map();

io.on('connection', (socket) => {
  console.log('User connected:', socket.id);

  socket.on('user:online', (userId) => {
    onlineUsers.set(userId, socket.id);
    socket.userId = userId;
    io.emit('user:status', { userId, status: 'online' });
  });

  socket.on('message:send', async (data) => {
    const { matchId, recipientId, message } = data;
    const recipientSocket = onlineUsers.get(recipientId);
    if (recipientSocket) {
      io.to(recipientSocket).emit('message:receive', { matchId, message });
    }
    io.to(recipientSocket || socket.id).emit('message:delivered', { messageId: message._id });
  });

  socket.on('typing:start', (data) => {
    const recipientSocket = onlineUsers.get(data.recipientId);
    if (recipientSocket) io.to(recipientSocket).emit('typing:start', { userId: socket.userId });
  });

  socket.on('typing:stop', (data) => {
    const recipientSocket = onlineUsers.get(data.recipientId);
    if (recipientSocket) io.to(recipientSocket).emit('typing:stop', { userId: socket.userId });
  });

  socket.on('match:new', (data) => {
    const recipientSocket = onlineUsers.get(data.matchedUserId);
    if (recipientSocket) io.to(recipientSocket).emit('match:new', data);
  });

  socket.on('disconnect', () => {
    if (socket.userId) {
      onlineUsers.delete(socket.userId);
      io.emit('user:status', { userId: socket.userId, status: 'offline' });
    }
  });
});

// ── Error Handler ──────────────────────────────────────────────────────────────
app.use((err, req, res, next) => {
  console.error(err.stack);
  const status = err.statusCode || 500;
  res.status(status).json({
    success: false,
    message: err.message || 'Internal Server Error',
    ...(process.env.NODE_ENV === 'development' && { stack: err.stack })
  });
});

// ── Database + Server Start ────────────────────────────────────────────────────
mongoose.connect(process.env.MONGODB_URI)
  .then(() => {
    console.log('✅ MongoDB Connected');
    const PORT = process.env.PORT || 5000;
    server.listen(PORT, () => console.log(`🚀 Server running on port ${PORT}`));
  })
  .catch(err => { console.error('❌ MongoDB connection error:', err); process.exit(1); });

module.exports = { app, io };
