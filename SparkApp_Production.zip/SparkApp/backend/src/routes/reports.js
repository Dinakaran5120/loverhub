const { reportRoutes } = require('./allRoutes'); module.exports = reportRoutes;
