import React, { useState } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  TextInput, Modal, Switch, Alert, ActivityIndicator,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Image } from 'expo-image';
import * as ImagePicker from 'expo-image-picker';
import { Colors, Spacing, Radius } from '../utils/theme';
import { useAuthStore } from '../store/authStore';
import { OrientationBadge, Tag, PrimaryButton, SecondaryButton, PrideBar } from '../components/SharedComponents';
import { mediaAPI } from '../services/api';

const ORIENTATIONS = ['Straight', 'Gay', 'Lesbian', 'Bisexual', 'Pansexual', 'Queer', 'Non-binary'];
const GOALS = ['Long-term', 'Casual', 'Friends', 'Unsure'];
const ALL_TAGS = ['Harry Potter', 'Hot Yoga', 'Self Care', 'Photography', 'Coffee', 'Travel', 'Music', 'Books', 'Fitness', 'Cooking', 'Art', 'Hiking', 'Dogs', 'Gaming', 'Foodie', 'Dancing'];

// ── Settings Row ──────────────────────────────────────────────────────────────
const SettingsRow = ({ icon, label, subtitle, onPress, right, destructive }: any) => (
  <TouchableOpacity style={styles.settingsRow} onPress={onPress} activeOpacity={onPress ? 0.7 : 1}>
    <View style={styles.settingsLeft}>
      <View style={[styles.settingsIcon, destructive && { backgroundColor: 'rgba(255,75,110,0.15)' }]}>
        <Text style={{ fontSize: 18 }}>{icon}</Text>
      </View>
      <View style={{ flex: 1 }}>
        <Text style={[styles.settingsLabel, destructive && { color: Colors.pink }]}>{label}</Text>
        {subtitle && <Text style={styles.settingsSub}>{subtitle}</Text>}
      </View>
    </View>
    {right || <Text style={styles.chevron}>›</Text>}
  </TouchableOpacity>
);

// ── Delete Account Modal ──────────────────────────────────────────────────────
const DeleteAccountModal = ({ visible, onClose }: { visible: boolean; onClose: () => void }) => {
  const { deleteAccount, isLoading } = useAuthStore();
  const [password, setPassword] = useState('');
  const [reason, setReason] = useState('');
  const REASONS = ['Found someone', 'Taking a break', 'Privacy concerns', 'Too many notifications', 'App issues', 'Other'];

  const handleDelete = () => {
    Alert.alert(
      '⚠️ Delete Account',
      'This will permanently delete your account and all data within 30 days. This cannot be undone.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete Forever',
          style: 'destructive',
          onPress: async () => {
            try {
              await deleteAccount(password, reason);
            } catch (err: any) {
              Alert.alert('Error', err.response?.data?.message || 'Failed to delete account.');
            }
          }
        }
      ]
    );
  };

  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
      <View style={styles.modalOverlay}>
        <View style={styles.modalSheet}>
          <View style={styles.modalHandle} />
          <Text style={[styles.modalTitle, { color: Colors.pink }]}>Delete Account 💔</Text>
          <Text style={styles.modalSub}>We're sorry to see you go. Your data will be permanently removed within 30 days.</Text>

          <Text style={styles.formLabel}>Reason for leaving</Text>
          <View style={styles.chipsWrap}>
            {REASONS.map(r => (
              <TouchableOpacity key={r}
                style={[styles.chip, reason === r && styles.chipActive]}
                onPress={() => setReason(r)}>
                <Text style={[styles.chipText, reason === r && styles.chipTextActive]}>{r}</Text>
              </TouchableOpacity>
            ))}
          </View>

          <Text style={[styles.formLabel, { marginTop: 16 }]}>Confirm password</Text>
          <TextInput
            style={styles.formInput}
            value={password}
            onChangeText={setPassword}
            placeholder="Enter your password"
            placeholderTextColor={Colors.text3}
            secureTextEntry
          />

          <TouchableOpacity
            style={[styles.deleteBtn, (!password.trim() || isLoading) && { opacity: 0.5 }]}
            onPress={handleDelete}
            disabled={!password.trim() || isLoading}>
            {isLoading ? <ActivityIndicator color="#fff" /> : <Text style={styles.deleteBtnText}>Delete My Account</Text>}
          </TouchableOpacity>
          <View style={{ height: 8 }} />
          <SecondaryButton label="Cancel — Keep My Account" onPress={onClose} />
          <View style={{ height: 24 }} />
        </View>
      </View>
    </Modal>
  );
};

// ── Main Screen ───────────────────────────────────────────────────────────────
export default function ProfileScreen({ navigation }: any) {
  const { user, logout, updateProfile, updateSettings } = useAuthStore();
  const [deleteVisible, setDeleteVisible] = useState(false);
  const [editVisible, setEditVisible] = useState(false);
  const [uploadingPhoto, setUploadingPhoto] = useState(false);
  const [form, setForm] = useState({
    name: user?.name || '',
    bio: user?.bio || '',
    orientation: user?.orientation || 'Straight',
    lookingFor: user?.lookingFor || 'Long-term',
    interests: user?.interests || [],
  });

  const mainPhoto = user?.photos?.find(p => p.isMain) || user?.photos?.[0];

  const pickAndUploadPhoto = async () => {
    const perm = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!perm.granted) { Alert.alert('Permission needed', 'Allow photo access.'); return; }
    const res = await ImagePicker.launchImageLibraryAsync({ allowsEditing: true, aspect: [3, 4], quality: 0.85 });
    if (!res.canceled && res.assets[0]) {
      setUploadingPhoto(true);
      try {
        await mediaAPI.uploadProfilePhoto(res.assets[0].uri);
        Alert.alert('✅ Photo uploaded!');
      } catch { Alert.alert('Upload failed', 'Please try again.'); }
      finally { setUploadingPhoto(false); }
    }
  };

  const handleLogout = () => {
    Alert.alert('Log Out', 'Are you sure you want to log out?', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Log Out', style: 'destructive', onPress: logout }
    ]);
  };

  const saveProfile = async () => {
    try {
      await updateProfile({ name: form.name, bio: form.bio, orientation: form.orientation.toLowerCase(), lookingFor: form.lookingFor.toLowerCase(), interests: form.interests });
      setEditVisible(false);
      Alert.alert('✅ Profile updated!');
    } catch { Alert.alert('Error', 'Could not save changes.'); }
  };

  const capitalize = (s: string) => s ? s.charAt(0).toUpperCase() + s.slice(1) : '';

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <PrideBar />
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Hero */}
        <View style={styles.hero}>
          <View style={styles.heroBg}>
            {mainPhoto
              ? <Image source={{ uri: mainPhoto.url }} style={StyleSheet.absoluteFill} contentFit="cover" />
              : <Text style={{ fontSize: 90, opacity: 0.3 }}>🌸</Text>}
          </View>
          <TouchableOpacity style={styles.editBtn} onPress={() => setEditVisible(true)}>
            <Text style={styles.editBtnText}>✏️ Edit</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.avatarRing} onPress={pickAndUploadPhoto}>
            {uploadingPhoto
              ? <ActivityIndicator color={Colors.accent} />
              : mainPhoto
                ? <Image source={{ uri: mainPhoto.url }} style={styles.avatarImg} contentFit="cover" />
                : <Text style={{ fontSize: 36 }}>🌸</Text>}
            <View style={styles.cameraIcon}><Text style={{ fontSize: 14 }}>📷</Text></View>
          </TouchableOpacity>
        </View>

        <View style={styles.infoSection}>
          <Text style={styles.displayName}>{user?.name}, {user?.age}</Text>
          <Text style={styles.handle}>Mumbai, India • Active now 🟢</Text>
          <View style={styles.chipRow}>
            <OrientationBadge orientation={capitalize(user?.orientation || 'Straight') as any} />
            <View style={styles.infoChip}><Text style={styles.infoChipText}>🎯 {capitalize(user?.lookingFor || 'Long-term')}</Text></View>
            {user?.premium?.isActive && <View style={styles.goldBadge}><Text style={styles.goldBadgeText}>💎 Gold</Text></View>}
          </View>
          <Text style={styles.bioText}>{user?.bio || 'Add a bio to attract more matches! ✨'}</Text>

          {/* Stats */}
          <View style={styles.statsRow}>
            <View style={styles.statCard}><Text style={styles.statNum}>{user?.stats?.totalMatches || 0}</Text><Text style={styles.statLabel}>Matches</Text></View>
            <View style={styles.statCard}><Text style={styles.statNum}>{user?.stats?.totalLikes || 0}</Text><Text style={styles.statLabel}>Likes</Text></View>
            <View style={styles.statCard}><Text style={styles.statNum}>{user?.interests?.length || 0}</Text><Text style={styles.statLabel}>Interests</Text></View>
          </View>

          {/* Tags */}
          {(user?.interests?.length || 0) > 0 && (
            <>
              <Text style={styles.sectionTitle}>Interests</Text>
              <View style={styles.tagsRow}>
                {(user?.interests || []).map((t: string) => <Tag key={t} label={t} />)}
              </View>
            </>
          )}
        </View>

        {/* Settings */}
        <View style={styles.settingsSection}>
          <Text style={styles.settingsCat}>ACCOUNT</Text>
          <SettingsRow icon="🎛️" label="Discovery Filters" subtitle="Age, distance, preferences" onPress={() => {}} />
          <SettingsRow icon="📍" label="Location" subtitle="Mumbai, India" onPress={() => {}} />
          <SettingsRow icon="📸" label="Manage Photos" subtitle={`${user?.photos?.length || 0} photos`} onPress={pickAndUploadPhoto} />
          <SettingsRow icon="🔑" label="Change Password" onPress={() => {}} />
          <SettingsRow icon="📧" label="Change Email" subtitle={user?.email || ''} onPress={() => {}} />
          <SettingsRow icon="📱" label="Notifications"
            right={<Switch value={user?.settings?.notifications?.matches !== false} onValueChange={v => updateSettings({ notifications: { matches: v } })} trackColor={{ false: Colors.bg4, true: Colors.accent }} thumbColor="#fff" />}
          />
          <SettingsRow icon="👁️" label="Incognito Mode"
            right={<Switch value={user?.settings?.incognitoMode || false} onValueChange={v => updateSettings({ incognitoMode: v })} trackColor={{ false: Colors.bg4, true: Colors.accent }} thumbColor="#fff" />}
          />
          <SettingsRow icon="🌍" label="Show Online Status"
            right={<Switch value={user?.settings?.showOnlineStatus !== false} onValueChange={v => updateSettings({ showOnlineStatus: v })} trackColor={{ false: Colors.bg4, true: Colors.accent }} thumbColor="#fff" />}
          />

          <Text style={[styles.settingsCat, { marginTop: 20 }]}>PREMIUM & SUPPORT</Text>
          <SettingsRow icon="💎" label="Spark Premium" subtitle="Unlimited likes, see who liked you"
            onPress={() => Alert.alert('💎 Spark Premium', 'Upgrade to Gold for unlimited likes!')}
            right={<View style={styles.upgradeBadge}><Text style={styles.upgradeBadgeText}>Upgrade</Text></View>} />
          <SettingsRow icon="❓" label="Help Center" onPress={() => navigation.navigate('HelpCenter')} />
          <SettingsRow icon="🔒" label="Privacy Policy" onPress={() => navigation.navigate('PrivacyPolicy')} />
          <SettingsRow icon="📜" label="Terms of Service" onPress={() => navigation.navigate('TermsOfService')} />
          <SettingsRow icon="🛡️" label="Safety" subtitle="Block list, report settings" onPress={() => {}} />

          <Text style={[styles.settingsCat, { marginTop: 20 }]}>DANGER ZONE</Text>
          <SettingsRow icon="🚪" label="Log Out" destructive onPress={handleLogout} />
          <SettingsRow icon="🗑️" label="Delete Account" subtitle="Permanently remove all data" destructive onPress={() => setDeleteVisible(true)} />
        </View>

        <View style={{ alignItems: 'center', paddingVertical: 24 }}>
          <Text style={{ fontSize: 24 }}>✦</Text>
          <Text style={styles.appVersion}>Spark v1.0.0 • Made with 💜 for everyone</Text>
        </View>
        <View style={{ height: 20 }} />
      </ScrollView>

      {/* Edit Profile Modal */}
      <Modal visible={editVisible} transparent animationType="slide" onRequestClose={() => setEditVisible(false)}>
        <View style={styles.modalOverlay}>
          <View style={styles.modalSheet}>
            <View style={styles.modalHandle} />
            <Text style={styles.modalTitle}>Edit Profile</Text>
            <ScrollView showsVerticalScrollIndicator={false}>
              <Text style={styles.formLabel}>Display Name</Text>
              <TextInput style={styles.formInput} value={form.name} onChangeText={v => setForm(p => ({ ...p, name: v }))} placeholderTextColor={Colors.text3} />
              <Text style={styles.formLabel}>Orientation</Text>
              <View style={styles.chipsWrap}>
                {ORIENTATIONS.map(o => (
                  <TouchableOpacity key={o} style={[styles.chip, form.orientation.toLowerCase() === o.toLowerCase() && styles.chipActive]} onPress={() => setForm(p => ({ ...p, orientation: o }))}>
                    <Text style={[styles.chipText, form.orientation.toLowerCase() === o.toLowerCase() && styles.chipTextActive]}>{o}</Text>
                  </TouchableOpacity>
                ))}
              </View>
              <Text style={[styles.formLabel, { marginTop: 14 }]}>Looking For</Text>
              <View style={styles.chipsWrap}>
                {GOALS.map(g => (
                  <TouchableOpacity key={g} style={[styles.chip, form.lookingFor.toLowerCase() === g.toLowerCase() && styles.chipActive]} onPress={() => setForm(p => ({ ...p, lookingFor: g }))}>
                    <Text style={[styles.chipText, form.lookingFor.toLowerCase() === g.toLowerCase() && styles.chipTextActive]}>{g}</Text>
                  </TouchableOpacity>
                ))}
              </View>
              <Text style={[styles.formLabel, { marginTop: 14 }]}>Bio</Text>
              <TextInput style={[styles.formInput, { height: 90 }]} value={form.bio} onChangeText={v => setForm(p => ({ ...p, bio: v }))} multiline textAlignVertical="top" placeholder="Tell people about yourself..." placeholderTextColor={Colors.text3} />
              <Text style={[styles.formLabel, { marginTop: 14 }]}>Interests</Text>
              <View style={styles.chipsWrap}>
                {ALL_TAGS.map(t => (
                  <TouchableOpacity key={t} style={[styles.chip, form.interests.includes(t) && styles.chipActive]} onPress={() => {
                    const updated = form.interests.includes(t) ? form.interests.filter(x => x !== t) : [...form.interests, t];
                    setForm(p => ({ ...p, interests: updated }));
                  }}>
                    <Text style={[styles.chipText, form.interests.includes(t) && styles.chipTextActive]}>{t}</Text>
                  </TouchableOpacity>
                ))}
              </View>
              <View style={{ height: 20 }} />
              <PrimaryButton label="Save Changes" onPress={saveProfile} />
              <View style={{ height: 8 }} />
              <SecondaryButton label="Cancel" onPress={() => setEditVisible(false)} />
              <View style={{ height: 32 }} />
            </ScrollView>
          </View>
        </View>
      </Modal>

      <DeleteAccountModal visible={deleteVisible} onClose={() => setDeleteVisible(false)} />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.bg },
  hero: { position: 'relative', height: 220, overflow: 'visible' },
  heroBg: { width: '100%', height: '100%', backgroundColor: Colors.bg3, alignItems: 'center', justifyContent: 'center', overflow: 'hidden' },
  editBtn: { position: 'absolute', top: 16, right: 16, backgroundColor: 'rgba(0,0,0,0.55)', borderRadius: Radius.md, paddingHorizontal: 14, paddingVertical: 7, borderWidth: 1, borderColor: Colors.border },
  editBtnText: { fontSize: 13, fontWeight: '700', color: Colors.text },
  avatarRing: { position: 'absolute', bottom: -34, left: 20, width: 88, height: 88, borderRadius: 44, borderWidth: 3, borderColor: Colors.accent, backgroundColor: Colors.bg3, alignItems: 'center', justifyContent: 'center', overflow: 'hidden' },
  avatarImg: { width: 88, height: 88, borderRadius: 44 },
  cameraIcon: { position: 'absolute', bottom: 4, right: 4, backgroundColor: Colors.accent, borderRadius: 10, width: 22, height: 22, alignItems: 'center', justifyContent: 'center' },
  infoSection: { paddingHorizontal: Spacing.xl, paddingTop: 46, paddingBottom: 16 },
  displayName: { fontSize: 24, fontWeight: '900', color: Colors.text },
  handle: { fontSize: 13, color: Colors.text2, marginBottom: 10 },
  chipRow: { flexDirection: 'row', alignItems: 'center', gap: 8, flexWrap: 'wrap', marginBottom: 12 },
  infoChip: { paddingHorizontal: 12, paddingVertical: 5, borderRadius: Radius.full, backgroundColor: Colors.bg3 },
  infoChipText: { fontSize: 12, fontWeight: '700', color: Colors.text2 },
  goldBadge: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: Radius.full, backgroundColor: 'rgba(251,191,36,0.2)' },
  goldBadgeText: { fontSize: 12, fontWeight: '800', color: '#fbbf24' },
  bioText: { fontSize: 14, color: Colors.text2, lineHeight: 22, marginBottom: 20 },
  statsRow: { flexDirection: 'row', gap: 10, marginBottom: 20 },
  statCard: { flex: 1, backgroundColor: Colors.bg3, borderRadius: Radius.lg, padding: 14, alignItems: 'center' },
  statNum: { fontSize: 20, fontWeight: '900', color: Colors.accent },
  statLabel: { fontSize: 11, color: Colors.text2, fontWeight: '600', marginTop: 2 },
  sectionTitle: { fontSize: 14, fontWeight: '800', color: Colors.text, marginBottom: 12 },
  tagsRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  settingsSection: { paddingHorizontal: Spacing.xl, paddingTop: 8 },
  settingsCat: { fontSize: 11, fontWeight: '700', color: Colors.text3, letterSpacing: 0.5, marginBottom: 8, marginTop: 4 },
  settingsRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingVertical: 13, borderBottomWidth: 1, borderBottomColor: Colors.border },
  settingsLeft: { flexDirection: 'row', alignItems: 'center', gap: 12, flex: 1 },
  settingsIcon: { width: 38, height: 38, borderRadius: Radius.md, backgroundColor: Colors.bg3, alignItems: 'center', justifyContent: 'center' },
  settingsLabel: { fontSize: 15, fontWeight: '700', color: Colors.text },
  settingsSub: { fontSize: 12, color: Colors.text2, marginTop: 1 },
  chevron: { fontSize: 20, color: Colors.text3 },
  upgradeBadge: { backgroundColor: Colors.accent, paddingHorizontal: 12, paddingVertical: 4, borderRadius: Radius.full },
  upgradeBadgeText: { color: '#000', fontSize: 12, fontWeight: '800' },
  appVersion: { fontSize: 12, color: Colors.text3, marginTop: 6 },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.8)', justifyContent: 'flex-end' },
  modalSheet: { backgroundColor: Colors.bg2, borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 20, maxHeight: '92%' },
  modalHandle: { width: 40, height: 4, borderRadius: 2, backgroundColor: Colors.border, alignSelf: 'center', marginBottom: 16 },
  modalTitle: { fontSize: 18, fontWeight: '900', color: Colors.text, textAlign: 'center', marginBottom: 8 },
  modalSub: { fontSize: 13, color: Colors.text2, textAlign: 'center', marginBottom: 20, lineHeight: 20 },
  formLabel: { fontSize: 13, fontWeight: '700', color: Colors.text2, marginBottom: 8 },
  formInput: { backgroundColor: Colors.bg3, borderWidth: 1, borderColor: Colors.border, borderRadius: Radius.md, paddingHorizontal: 14, paddingVertical: 11, color: Colors.text, fontSize: 14, marginBottom: 4 },
  chipsWrap: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 4 },
  chip: { paddingHorizontal: 14, paddingVertical: 8, borderRadius: Radius.full, borderWidth: 1.5, borderColor: Colors.border },
  chipActive: { borderColor: Colors.accent, backgroundColor: 'rgba(232,255,71,0.1)' },
  chipText: { fontSize: 13, fontWeight: '700', color: Colors.text2 },
  chipTextActive: { color: Colors.accent },
  deleteBtn: { backgroundColor: Colors.pink, paddingVertical: 14, borderRadius: Radius.lg, alignItems: 'center', marginTop: 8 },
  deleteBtnText: { color: '#fff', fontSize: 15, fontWeight: '900' },
});
