import { Colors } from "@constants/theme";
import type { ExplorePost } from "@/types/explore";

const makeVibes = (
  heartN = 0, laughN = 0, fireN = 0, wowN = 0, sadN = 0, sparkN = 0
): ExplorePost["vibes"] => [
  { emoji: "❤️", count: heartN, reacted: false },
  { emoji: "😂", count: laughN, reacted: false },
  { emoji: "🔥", count: fireN,  reacted: false },
  { emoji: "😮", count: wowN,   reacted: false },
  { emoji: "💔", count: sadN,   reacted: false },
  { emoji: "✨", count: sparkN, reacted: false },
];

export const MOCK_EXPLORE_POSTS: ExplorePost[] = [
  // ── Mood post ──────────────────────────────────────────────────────────
  {
    id: "m1",
    type: "mood",
    author: {
      id: "u1", name: "Anon", avatarEmoji: "🌙",
      gradient: [Colors.violet, Colors.sky],
      verified: false, isAnonymous: true,
    },
    caption: "Why does 3am hit different when you're overthinking everything about someone you shouldn't be thinking about",
    tags: ["#LateNightThoughts", "#Feelings"],
    mood: "Vulnerable",
    moodColor: Colors.violet,
    moodGradient: [Colors.violet, Colors.rose],
    vibes: makeVibes(1842, 0, 0, 0, 512, 384),
    comments: [
      { id: "c1", author: { id: "u9", name: "Riya", avatarEmoji: "💫", gradient: [Colors.rose, Colors.violet], verified: true, isAnonymous: false }, text: "I felt this in my soul 😭", createdAt: new Date(Date.now() - 12*60000).toISOString(), likes: 47, liked: false },
      { id: "c2", author: { id: "u10", name: "Anon", avatarEmoji: "🌑", gradient: [Colors.muted, "#555"], verified: false, isAnonymous: true }, text: "You just described my whole week", createdAt: new Date(Date.now() - 8*60000).toISOString(), likes: 23, liked: false },
    ],
    shares: 294,
    createdAt: new Date(Date.now() - 2*3600000).toISOString(),
    isPublic: true,
    isTrending: true,
  },

  // ── Image post ─────────────────────────────────────────────────────────
  {
    id: "i1",
    type: "image",
    author: {
      id: "u2", name: "Priya",  avatarEmoji: "🥰",
      gradient: [Colors.violet, Colors.sky],
      verified: true, isAnonymous: false,
    },
    caption: "Saturday golden hour hits different from Bandstand 🌅 If you know, you know",
    mediaEmoji: "🌅",
    mediaGradient: [Colors.gold, Colors.accent],
    tags: ["#Mumbai", "#GoldenHour", "#Bandstand"],
    vibes: makeVibes(523, 0, 187, 0, 0, 341),
    comments: [
      { id: "c3", author: { id: "u3", name: "Arjun", avatarEmoji: "😊", gradient: [Colors.secondary, Colors.rose], verified: true, isAnonymous: false }, text: "This spot is unreal 😍", createdAt: new Date(Date.now() - 35*60000).toISOString(), likes: 12, liked: true },
    ],
    shares: 89,
    createdAt: new Date(Date.now() - 4*3600000).toISOString(),
    location: "Bandstand, Mumbai",
    isPublic: true,
    isTrending: false,
  },

  // ── Thought post ───────────────────────────────────────────────────────
  {
    id: "t1",
    type: "thought",
    author: {
      id: "u3", name: "Arjun", avatarEmoji: "😊",
      gradient: [Colors.secondary, Colors.rose],
      verified: true, isAnonymous: false,
    },
    caption: "Hot take: dating apps would work better if you led with your Spotify wrapped instead of photos. Your music taste says more about you than your gym selfies.",
    tags: ["#HotTake", "#DatingAdvice", "#Spotify"],
    vibes: makeVibes(892, 445, 234, 128, 0, 0),
    comments: [
      { id: "c4", author: { id: "u4", name: "Zara", avatarEmoji: "🌈", gradient: [Colors.accent, Colors.gold], verified: false, isAnonymous: false }, text: "HARD AGREE. Show me your top artists first lol", createdAt: new Date(Date.now() - 22*60000).toISOString(), likes: 88, liked: false },
      { id: "c5", author: { id: "u5", name: "Karan", avatarEmoji: "🏏", gradient: [Colors.sky, Colors.mint], verified: true, isAnonymous: false }, text: "As someone who unironically listens to Arijit Singh 24/7, I'm scared of this idea 😅", createdAt: new Date(Date.now() - 18*60000).toISOString(), likes: 134, liked: true },
    ],
    shares: 512,
    createdAt: new Date(Date.now() - 6*3600000).toISOString(),
    isPublic: true,
    isTrending: true,
  },

  // ── Video (reel) post ──────────────────────────────────────────────────
  {
    id: "v1",
    type: "video",
    author: {
      id: "u4", name: "Zara", avatarEmoji: "🌈",
      gradient: [Colors.accent, Colors.gold],
      verified: false, isAnonymous: false,
    },
    caption: "POV: you finally matched with someone who has good taste 🌈✨ #queer #pride",
    mediaEmoji: "🌈",
    mediaGradient: [Colors.violet, Colors.rose],
    videoDuration: "0:18",
    tags: ["#QueerJoy", "#Pride", "#LGBTQ"],
    vibes: makeVibes(2341, 0, 892, 0, 0, 1203),
    comments: [
      { id: "c6", author: { id: "u6", name: "Nisha", avatarEmoji: "🌺", gradient: [Colors.rose, Colors.primary], verified: true, isAnonymous: false }, text: "The vibes in this video omg 🌈🌈", createdAt: new Date(Date.now() - 5*60000).toISOString(), likes: 201, liked: false },
    ],
    shares: 1847,
    createdAt: new Date(Date.now() - 8*3600000).toISOString(),
    isPublic: true,
    isTrending: true,
  },

  // ── Anonymous mood ─────────────────────────────────────────────────────
  {
    id: "m2",
    type: "mood",
    author: {
      id: "u_anon2", name: "Anon", avatarEmoji: "🌧️",
      gradient: [Colors.sky, Colors.violet],
      verified: false, isAnonymous: true,
    },
    caption: "Matched with 47 people this month. Talked to 3. Met 0. Is it me or is it them? Genuinely asking.",
    tags: ["#DatingApps", "#Mumbai", "#RealTalk"],
    mood: "Questioning",
    moodColor: Colors.sky,
    moodGradient: [Colors.sky, Colors.violet],
    vibes: makeVibes(3201, 892, 0, 445, 234, 0),
    comments: [
      { id: "c7", author: { id: "u7", name: "Rohan", avatarEmoji: "🎸", gradient: [Colors.gold, Colors.accent], verified: true, isAnonymous: false }, text: "It's both. But mostly the apps. Designed to keep you swiping not connecting 🤷", createdAt: new Date(Date.now() - 45*60000).toISOString(), likes: 567, liked: false },
      { id: "c8", author: { id: "u_anon3", name: "Anon", avatarEmoji: "☁️", gradient: [Colors.muted, "#aaa"], verified: false, isAnonymous: true }, text: "47 is me btw I was scared to text first 💀", createdAt: new Date(Date.now() - 30*60000).toISOString(), likes: 892, liked: true },
    ],
    shares: 2103,
    createdAt: new Date(Date.now() - 10*3600000).toISOString(),
    isPublic: true,
    isTrending: true,
  },

  // ── Image post 2 ───────────────────────────────────────────────────────
  {
    id: "i2",
    type: "image",
    author: {
      id: "u5", name: "Karan", avatarEmoji: "🏏",
      gradient: [Colors.sky, Colors.mint],
      verified: true, isAnonymous: false,
    },
    caption: "Brought my dog to Bandra Worli Sea Link walk because I have no one else to do it with. He judged me the whole time. 10/10 would recommend.",
    mediaEmoji: "🐶",
    mediaGradient: [Colors.sky, Colors.mint],
    tags: ["#DogDad", "#Bandra", "#MumbaiDiaries"],
    vibes: makeVibes(1203, 678, 234, 0, 0, 445),
    comments: [
      { id: "c9", author: { id: "u8", name: "Ananya", avatarEmoji: "🦋", gradient: [Colors.secondary, Colors.sky], verified: false, isAnonymous: false }, text: "What breed?? I need to meet this judgemental king 😭", createdAt: new Date(Date.now() - 1*3600000).toISOString(), likes: 134, liked: false },
    ],
    shares: 203,
    createdAt: new Date(Date.now() - 14*3600000).toISOString(),
    location: "Bandra-Worli Sea Link",
    isPublic: true,
    isTrending: false,
  },

  // ── Thought post 2 ─────────────────────────────────────────────────────
  {
    id: "t2",
    type: "thought",
    author: {
      id: "u_anon4", name: "Anon", avatarEmoji: "🔮",
      gradient: [Colors.primary, Colors.violet],
      verified: false, isAnonymous: true,
    },
    caption: "The person who reads till the end of a long message before replying instead of replying mid-sentence is a green flag. Fight me.",
    tags: ["#GreenFlags", "#Texting", "#RelationshipAdvice"],
    vibes: makeVibes(5621, 1203, 892, 0, 0, 2341),
    comments: [
      { id: "c10", author: { id: "u2", name: "Priya", avatarEmoji: "🥰", gradient: [Colors.violet, Colors.sky], verified: true, isAnonymous: false }, text: "Not a debate, this is just a fact", createdAt: new Date(Date.now() - 2*3600000).toISOString(), likes: 892, liked: true },
    ],
    shares: 3892,
    createdAt: new Date(Date.now() - 18*3600000).toISOString(),
    isPublic: true,
    isTrending: true,
  },

  // ── Video post 2 ───────────────────────────────────────────────────────
  {
    id: "v2",
    type: "video",
    author: {
      id: "u6", name: "Nisha", avatarEmoji: "🌺",
      gradient: [Colors.rose, Colors.primary],
      verified: true, isAnonymous: false,
    },
    caption: "Morning yoga in Versova + chai = the only love language I understand right now ☕🧘",
    mediaEmoji: "🧘",
    mediaGradient: [Colors.mint, Colors.sky],
    videoDuration: "0:32",
    tags: ["#YogaLife", "#Versova", "#MorningRoutine"],
    vibes: makeVibes(892, 0, 445, 234, 0, 678),
    comments: [],
    shares: 156,
    createdAt: new Date(Date.now() - 20*3600000).toISOString(),
    location: "Versova Beach",
    isPublic: true,
    isTrending: false,
  },

  // ── Mood post 3 ────────────────────────────────────────────────────────
  {
    id: "m3",
    type: "mood",
    author: {
      id: "u_anon5", name: "Anon", avatarEmoji: "🌸",
      gradient: [Colors.secondary, Colors.rose],
      verified: false, isAnonymous: true,
    },
    caption: "Soft launching my healing era. No more chasing people who treat effort like a burden. My love is not a problem to solve.",
    tags: ["#HealingEra", "#SelfLove", "#Growth"],
    mood: "Healing",
    moodColor: Colors.rose,
    moodGradient: [Colors.secondary, Colors.rose],
    vibes: makeVibes(8923, 0, 0, 0, 0, 4512),
    comments: [
      { id: "c11", author: { id: "u1", name: "Anon", avatarEmoji: "🌙", gradient: [Colors.violet, Colors.sky], verified: false, isAnonymous: true }, text: "Screenshotting this for every 3am crisis 🌸", createdAt: new Date(Date.now() - 6*3600000).toISOString(), likes: 1203, liked: false },
    ],
    shares: 6721,
    createdAt: new Date(Date.now() - 24*3600000).toISOString(),
    isPublic: true,
    isTrending: true,
  },
];

// Reels-only subset (videos only)
export const MOCK_REELS = MOCK_EXPLORE_POSTS.filter((p) => p.type === "video");
