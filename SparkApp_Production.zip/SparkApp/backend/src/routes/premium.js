const { premiumRoutes } = require('./allRoutes'); module.exports = premiumRoutes;
