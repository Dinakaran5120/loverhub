import { useState } from "react";
import { View, Text, ScrollView, Pressable, TextInput, Dimensions } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { Colors } from "@constants/theme";
import { useConnectionsStore } from "@/store/connectionsStore";
import { useSortedConversations, useTotalUnreadMessages, msgTimeAgo, lastSeenText } from "@/hooks/useConnections";
import { ChatScreen } from "@components/connections/ChatScreen";
import { CallScreen } from "@components/connections/CallScreen";
import { CreateGroupModal } from "@components/connections/CreateGroupModal";
import type { Conversation } from "@/types/connections";

const { width: W } = Dimensions.get("window");

// ── Matches row ───────────────────────────────────────────────────────────────
const MATCHES = [
  { id: "u1", name: "Arjun",  avatarEmoji: "😊", gradient: [Colors.secondary, Colors.rose]  as [string,string], isNew: true  },
  { id: "u2", name: "Priya",  avatarEmoji: "🥰", gradient: [Colors.violet, Colors.sky]      as [string,string], isNew: true  },
  { id: "u3", name: "Dev",    avatarEmoji: "😎", gradient: [Colors.primary, Colors.accent]  as [string,string], isNew: false },
  { id: "u4", name: "Zara",   avatarEmoji: "🌈", gradient: [Colors.accent, Colors.gold]     as [string,string], isNew: true  },
  { id: "u5", name: "Riya",   avatarEmoji: "💫", gradient: [Colors.rose, Colors.violet]     as [string,string], isNew: false },
  { id: "u6", name: "Karan",  avatarEmoji: "🏏", gradient: [Colors.sky, Colors.mint]        as [string,string], isNew: false },
];

function MatchesRow({ onOpenChat }: { onOpenChat: (convId: string) => void }) {
  const conversations = useConnectionsStore((s) => s.conversations);

  return (
    <View style={{ paddingBottom: 4 }}>
      <Text style={{ fontSize: 12, fontWeight: "800", color: Colors.textMuted, letterSpacing: 0.6, paddingHorizontal: 16, paddingVertical: 10 }}>
        NEW MATCHES
      </Text>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ paddingHorizontal: 16, gap: 14 }}>
        {MATCHES.map((m) => {
          const conv = conversations.find((c) => c.type === "direct" && c.participants[0]?.id === m.id);
          return (
            <Pressable
              key={m.id}
              onPress={() => conv && onOpenChat(conv.id)}
              style={({ pressed }) => ({ alignItems: "center", gap: 5, opacity: pressed ? 0.7 : 1 })}
            >
              <View style={{ position: "relative" }}>
                <LinearGradient
                  colors={m.isNew ? m.gradient : [Colors.border, Colors.card]}
                  start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
                  style={{ width: 62, height: 62, borderRadius: 31, padding: 2.5 }}
                >
                  <View style={{ flex: 1, borderRadius: 29, backgroundColor: Colors.surface, alignItems: "center", justifyContent: "center", borderWidth: 2, borderColor: Colors.surface }}>
                    <Text style={{ fontSize: 28 }}>{m.avatarEmoji}</Text>
                  </View>
                </LinearGradient>
                {m.isNew && (
                  <View style={{ position: "absolute", bottom: 0, right: 0, width: 16, height: 16, borderRadius: 8, backgroundColor: Colors.primary, borderWidth: 2, borderColor: Colors.surface, alignItems: "center", justifyContent: "center" }}>
                    <Text style={{ color: "#fff", fontSize: 8, fontWeight: "800" }}>!</Text>
                  </View>
                )}
              </View>
              <Text style={{ fontSize: 11, color: Colors.textSecondary, fontWeight: m.isNew ? "700" : "500" }} numberOfLines={1}>
                {m.name}
              </Text>
            </Pressable>
          );
        })}
      </ScrollView>
    </View>
  );
}

// ── Conversation row ──────────────────────────────────────────────────────────
function ConvRow({ conv, onPress }: { conv: Conversation; onPress: () => void }) {
  const isGroup    = conv.type === "group";
  const p          = conv.participants[0];
  const name       = isGroup ? (conv.groupName ?? "Group") : p?.name ?? "";
  const emoji      = isGroup ? (conv.groupEmoji ?? "👥") : p?.avatarEmoji ?? "👤";
  const grad       = (isGroup ? conv.groupGradient : p?.gradient) ?? [Colors.primary, Colors.accent] as [string,string];
  const isOnline   = !isGroup && p?.online;
  const isMine     = conv.lastSenderId === "me";
  const timeStr    = msgTimeAgo(conv.lastMessageTime);
  const hasUnread  = conv.unreadCount > 0;

  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => ({
        flexDirection: "row", alignItems: "center",
        paddingHorizontal: 16, paddingVertical: 12, gap: 12,
        backgroundColor: pressed ? Colors.card : "transparent",
      })}
    >
      {/* Avatar */}
      <View style={{ position: "relative", flexShrink: 0 }}>
        <LinearGradient
          colors={grad}
          start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
          style={{ width: 54, height: 54, borderRadius: 27, alignItems: "center", justifyContent: "center" }}
        >
          <Text style={{ fontSize: 26 }}>{emoji}</Text>
        </LinearGradient>
        {isOnline && (
          <View style={{ position: "absolute", bottom: 1, right: 1, width: 14, height: 14, borderRadius: 7, backgroundColor: "#22c55e", borderWidth: 2, borderColor: Colors.background }} />
        )}
        {conv.isPinned && (
          <View style={{ position: "absolute", top: -2, right: -2, width: 16, height: 16, borderRadius: 8, backgroundColor: Colors.gold, alignItems: "center", justifyContent: "center" }}>
            <Text style={{ fontSize: 9 }}>📌</Text>
          </View>
        )}
        {isGroup && (
          <View style={{ position: "absolute", bottom: -2, right: -2, width: 18, height: 18, borderRadius: 9, backgroundColor: Colors.violet, borderWidth: 2, borderColor: Colors.surface, alignItems: "center", justifyContent: "center" }}>
            <Text style={{ color: "#fff", fontSize: 8, fontWeight: "800" }}>G</Text>
          </View>
        )}
      </View>

      {/* Content */}
      <View style={{ flex: 1, gap: 3 }}>
        <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between" }}>
          <Text style={{ fontSize: 15, fontWeight: hasUnread ? "800" : "600", color: Colors.text }} numberOfLines={1}>
            {name}
          </Text>
          <Text style={{ fontSize: 12, color: hasUnread ? Colors.primary : Colors.textMuted, fontWeight: hasUnread ? "700" : "400" }}>
            {timeStr}
          </Text>
        </View>
        <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 6 }}>
          <Text
            style={{ fontSize: 13, color: conv.isTyping ? Colors.primary : hasUnread ? Colors.text : Colors.textMuted, fontWeight: hasUnread ? "600" : "400", flex: 1, fontStyle: conv.isTyping ? "italic" : "normal" }}
            numberOfLines={1}
          >
            {conv.isTyping ? "typing…" : isMine ? `You: ${conv.lastMessage}` : conv.lastMessage}
          </Text>
          {hasUnread && (
            <LinearGradient
              colors={[Colors.primary, Colors.accent]}
              start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
              style={{ minWidth: 22, height: 22, borderRadius: 11, alignItems: "center", justifyContent: "center", paddingHorizontal: 5 }}
            >
              <Text style={{ color: "#fff", fontSize: 11, fontWeight: "800" }}>{conv.unreadCount}</Text>
            </LinearGradient>
          )}
          {conv.isMuted && <Text style={{ fontSize: 13 }}>🔕</Text>}
        </View>
      </View>
    </Pressable>
  );
}

// ── Main connections screen ────────────────────────────────────────────────────
export default function ConnectionsScreen() {
  const activeConvId   = useConnectionsStore((s) => s.activeConversationId);
  const call           = useConnectionsStore((s) => s.call);
  const setActive      = useConnectionsStore((s) => s.setActiveConversation);

  const [activeTab, setActiveTab]   = useState<"messages" | "matches">("messages");
  const [search, setSearch]         = useState("");
  const [showCreate, setShowCreate] = useState(false);

  const sorted       = useSortedConversations(search);
  const totalUnread  = useTotalUnreadMessages();

  const directConvs = sorted.filter((c) => c.type === "direct");
  const groupConvs  = sorted.filter((c) => c.type === "group");

  // If chat is open, show it
  if (activeConvId) return <ChatScreen />;
  // If call is active without a conversation
  if (call) return <CallScreen />;

  return (
    <View style={{ flex: 1, backgroundColor: Colors.background }}>
      {/* Tab switcher */}
      <View style={{ flexDirection: "row", paddingHorizontal: 16, paddingTop: 12, paddingBottom: 8, gap: 10 }}>
        {(["messages", "matches"] as const).map((tab) => {
          const isActive = activeTab === tab;
          const label    = tab === "messages"
            ? `Messages${totalUnread > 0 ? ` (${totalUnread})` : ""}`
            : "Matches 🔥";
          return (
            <Pressable key={tab} onPress={() => setActiveTab(tab)} style={{ flex: 1 }}>
              {isActive ? (
                <LinearGradient colors={[Colors.primary, Colors.accent]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} style={{ paddingVertical: 10, borderRadius: 16, alignItems: "center" }}>
                  <Text style={{ color: "#fff", fontWeight: "800", fontSize: 14 }}>{label}</Text>
                </LinearGradient>
              ) : (
                <View style={{ paddingVertical: 10, borderRadius: 16, alignItems: "center", backgroundColor: Colors.card, borderWidth: 1, borderColor: Colors.border }}>
                  <Text style={{ color: Colors.textMuted, fontWeight: "600", fontSize: 14 }}>{label}</Text>
                </View>
              )}
            </Pressable>
          );
        })}
      </View>

      {activeTab === "matches" ? (
        <MatchesRow onOpenChat={(id) => setActive(id)} />
      ) : (
        <ScrollView showsVerticalScrollIndicator={false}>
          {/* Search + new group */}
          <View style={{ flexDirection: "row", paddingHorizontal: 16, paddingBottom: 8, gap: 8 }}>
            <View style={{ flex: 1, flexDirection: "row", alignItems: "center", backgroundColor: Colors.card, borderRadius: 14, paddingHorizontal: 12, paddingVertical: 9, borderWidth: 1, borderColor: Colors.border, gap: 8 }}>
              <Text style={{ fontSize: 15, opacity: 0.5 }}>🔍</Text>
              <TextInput value={search} onChangeText={setSearch} placeholder="Search messages…" placeholderTextColor={Colors.textMuted} style={{ flex: 1, fontSize: 14, color: Colors.text, padding: 0 }} />
            </View>
            <Pressable
              onPress={() => setShowCreate(true)}
              style={({ pressed }) => ({ opacity: pressed ? 0.8 : 1 })}
            >
              <LinearGradient colors={[Colors.violet, Colors.sky]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={{ width: 42, height: 42, borderRadius: 14, alignItems: "center", justifyContent: "center" }}>
                <Text style={{ color: "#fff", fontSize: 20, lineHeight: 24 }}>+</Text>
              </LinearGradient>
            </Pressable>
          </View>

          {/* Direct messages */}
          {directConvs.length > 0 && (
            <View>
              <Text style={{ fontSize: 12, fontWeight: "800", color: Colors.textMuted, letterSpacing: 0.6, paddingHorizontal: 16, paddingTop: 8, paddingBottom: 4 }}>
                DIRECT MESSAGES
              </Text>
              <View style={{ backgroundColor: Colors.surface, borderTopWidth: 1, borderBottomWidth: 1, borderColor: Colors.border }}>
                {directConvs.map((conv, i) => (
                  <View key={conv.id}>
                    <ConvRow conv={conv} onPress={() => setActive(conv.id)} />
                    {i < directConvs.length - 1 && (
                      <View style={{ height: 1, backgroundColor: Colors.border, marginLeft: 82 }} />
                    )}
                  </View>
                ))}
              </View>
            </View>
          )}

          {/* Group chats */}
          {groupConvs.length > 0 && (
            <View style={{ marginTop: 12 }}>
              <Text style={{ fontSize: 12, fontWeight: "800", color: Colors.textMuted, letterSpacing: 0.6, paddingHorizontal: 16, paddingTop: 4, paddingBottom: 4 }}>
                GROUP CHATS
              </Text>
              <View style={{ backgroundColor: Colors.surface, borderTopWidth: 1, borderBottomWidth: 1, borderColor: Colors.border }}>
                {groupConvs.map((conv, i) => (
                  <View key={conv.id}>
                    <ConvRow conv={conv} onPress={() => setActive(conv.id)} />
                    {i < groupConvs.length - 1 && (
                      <View style={{ height: 1, backgroundColor: Colors.border, marginLeft: 82 }} />
                    )}
                  </View>
                ))}
              </View>
            </View>
          )}

          {sorted.length === 0 && (
            <View style={{ alignItems: "center", paddingVertical: 56, gap: 12 }}>
              <Text style={{ fontSize: 36 }}>💬</Text>
              <Text style={{ fontSize: 16, fontWeight: "700", color: Colors.text }}>No conversations yet</Text>
              <Text style={{ fontSize: 13, color: Colors.textMuted, textAlign: "center" }}>
                Match with someone to start chatting!
              </Text>
            </View>
          )}

          <View style={{ height: 32 }} />
        </ScrollView>
      )}

      <CreateGroupModal visible={showCreate} onClose={() => setShowCreate(false)} />
    </View>
  );
}
