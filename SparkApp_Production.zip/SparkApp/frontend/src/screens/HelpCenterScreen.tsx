import React, { useState, useMemo } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  TextInput, Linking, Alert,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Colors, Spacing, Radius } from '../utils/theme';
import { PrideBar } from '../components/SharedComponents';

const CATEGORIES = [
  { id: 'account', label: 'Account', icon: '👤' },
  { id: 'matching', label: 'Matching', icon: '💕' },
  { id: 'safety', label: 'Safety', icon: '🛡️' },
  { id: 'premium', label: 'Premium', icon: '💎' },
  { id: 'technical', label: 'Technical', icon: '⚙️' },
  { id: 'privacy', label: 'Privacy', icon: '🔒' },
];

const FAQS = [
  // Account
  { cat: 'account', q: 'How do I create an account?', a: 'Download Spark, tap "Get Started", enter your email and a strong password, fill in your age, gender, and orientation, then add at least one photo. Your profile is live once complete!' },
  { cat: 'account', q: 'How do I delete my account?', a: 'Go to Profile → Settings → scroll to bottom → tap "Delete Account". Enter your password to confirm. Your profile is hidden immediately and all data is permanently deleted within 30 days. This action cannot be undone.' },
  { cat: 'account', q: 'How do I log out?', a: 'Go to Profile → Settings → scroll to the bottom → tap "Log Out". You\'ll be signed out on this device. Your profile remains active and visible to other users.' },
  { cat: 'account', q: 'Can I change my email address?', a: 'Yes! Go to Profile → Settings → Account → Change Email. Enter your new email and current password. We\'ll send a verification link to your new email.' },
  { cat: 'account', q: 'How do I reset my password?', a: 'On the login screen, tap "Forgot Password?" and enter your email. We\'ll send a reset link that expires in 10 minutes. Check your spam folder if you don\'t see it.' },
  { cat: 'account', q: 'How do I verify my profile?', a: 'Verified profiles get a blue checkmark. To verify, go to Profile → Verify Me → take a selfie matching a pose. Verification usually completes within a few minutes.' },
  { cat: 'account', q: 'Can I pause my account without deleting it?', a: 'Yes! Go to Profile → Settings → Discovery Settings → toggle off "Show me in Discovery". Your profile will be hidden from all users but your data and matches are preserved.' },

  // Matching
  { cat: 'matching', q: 'How does location-based matching work?', a: 'Spark uses your device GPS to find people within your chosen distance radius. We never share your exact coordinates — other users only see your approximate distance (e.g., "3 km away"). Enable location in Settings for this to work.' },
  { cat: 'matching', q: 'What is a Super Like?', a: 'A Super Like lets someone know you\'re especially interested before they swipe on you. Free users get 1 Super Like per day. Spark Gold members get 5/day. Swipe up on any card to Super Like!' },
  { cat: 'matching', q: 'Why am I not getting matches?', a: 'Try: adding more photos (profiles with 3+ photos get 2x matches), writing a bio, expanding your age/distance filters, or enabling Global Mode in settings to see people worldwide.' },
  { cat: 'matching', q: 'How many likes can I send per day?', a: 'Free users can send 100 likes per day. Likes reset at midnight local time. Spark Gold gives unlimited likes. Super Likes are separate (1/day free, 5/day Gold).' },
  { cat: 'matching', q: 'Can I undo an accidental swipe?', a: 'Yes! Tap the yellow rewind button below the card stack to undo your last swipe. Free users get 1 undo per day. Spark Gold gives unlimited rewinds.' },
  { cat: 'matching', q: 'What is Global Mode?', a: 'Global Mode shows you profiles from around the world, not just your local area. Enable it in Profile → Settings → Discovery → Global Mode. Great for travelers or finding international connections!' },
  { cat: 'matching', q: 'How do I unmatch someone?', a: 'Open the chat with that person → tap their name at the top → tap Unmatch. They won\'t be notified but the match and messages will disappear for both of you.' },

  // Safety
  { cat: 'safety', q: 'How do I report someone?', a: 'On their profile, tap the three dots (⋯) → Report. Choose a reason and add details. Reports are reviewed by our safety team within 24 hours. You can also block them at the same time.' },
  { cat: 'safety', q: 'How do I block someone?', a: 'Open their profile → tap ⋯ → Block. They will no longer see your profile and you won\'t see theirs. They are NOT notified they\'ve been blocked.' },
  { cat: 'safety', q: 'What is Incognito Mode?', a: 'Incognito Mode makes your profile invisible to everyone except people you\'ve already liked. This is a Spark Gold feature. Enable it in Profile → Settings → Incognito Mode.' },
  { cat: 'safety', q: 'Tips for safe first meetings', a: '• Always meet in a public place for the first time\n• Tell a friend where you\'re going and who you\'re meeting\n• Arrange your own transport — don\'t accept rides early on\n• Keep personal information private until you trust them\n• Trust your instincts — leave if something feels off\n• Use Spark\'s in-app messaging rather than sharing your phone number early' },
  { cat: 'safety', q: 'Someone is asking me for money — what do I do?', a: 'This is a scam. Never send money to someone you\'ve met on a dating app. Report the profile immediately using the ⋯ menu. Legitimate connections on Spark will never ask for financial help.' },
  { cat: 'safety', q: 'How do I report underage users?', a: 'Tap ⋯ on their profile → Report → select "Underage" as the reason. Our safety team investigates all such reports within hours. Thank you for helping keep Spark safe.' },

  // Premium
  { cat: 'premium', q: 'What is Spark Gold?', a: 'Spark Gold unlocks: Unlimited Likes, 5 Super Likes/day, Unlimited Rewinds, See Who Liked You, Incognito Mode, Global Mode, and a Gold badge. Starting from ₹599/month.' },
  { cat: 'premium', q: 'How do I cancel my subscription?', a: 'iOS: Settings app → Apple ID → Subscriptions → Spark → Cancel\nAndroid: Play Store → Profile → Payments & subscriptions → Subscriptions → Spark → Cancel\n\nYou keep Premium benefits until your current billing period ends.' },
  { cat: 'premium', q: 'Can I get a refund?', a: 'Refunds are handled by the App Store (iOS) or Google Play (Android). We recommend contacting them directly. We\'re unable to process refunds ourselves, but please contact support@sparkdating.app if you have billing concerns.' },
  { cat: 'premium', q: 'What is Spark Platinum?', a: 'Spark Platinum includes everything in Gold plus: Priority Likes (your profile shown first), Message before matching, Read receipts, advanced profile analytics, and exclusive Platinum badge.' },

  // Technical
  { cat: 'technical', q: 'The app is crashing — what do I do?', a: '1. Force close the app and reopen it\n2. Check for app updates in the App Store / Play Store\n3. Restart your device\n4. Uninstall and reinstall the app (your account is cloud-saved)\n5. Contact support with your device model and OS version if the issue persists' },
  { cat: 'technical', q: 'My photos won\'t upload', a: 'Ensure you\'ve granted photo library permissions in your device settings. Photos must be under 20MB. Try a different photo or check your internet connection. JPG and PNG formats are supported.' },
  { cat: 'technical', q: 'Notifications aren\'t working', a: 'Check that notifications are enabled for Spark in your device Settings → Notifications → Spark. Also check Profile → Settings → Notifications in the app. Make sure Battery Saver mode isn\'t blocking background activity.' },
  { cat: 'technical', q: 'My location isn\'t being detected', a: 'Ensure Location permissions are set to "While Using App" or "Always" for Spark in your device settings. On iOS: Settings → Spark → Location. On Android: Settings → Apps → Spark → Permissions → Location.' },

  // Privacy
  { cat: 'privacy', q: 'Who can see my profile?', a: 'Your profile is visible to users who match your discovery filters and whom your profile matches in their filters. If you\'ve blocked someone or they\'ve blocked you, neither can see the other. Incognito mode (Gold) restricts visibility further.' },
  { cat: 'privacy', q: 'How do I download my data?', a: 'Email privacy@sparkdating.app with the subject "Data Export Request". Under GDPR/CCPA, we\'ll provide a copy of all your personal data within 30 days.' },
  { cat: 'privacy', q: 'Is my orientation data kept private?', a: 'Your gender identity and sexual orientation are sensitive data. We only share what you choose to display on your profile. We never sell this data. You can hide your orientation badge in Profile → Edit Profile.' },
];

export default function HelpCenterScreen({ navigation }: any) {
  const [search, setSearch] = useState('');
  const [activeCategory, setActiveCategory] = useState('all');
  const [expandedFaq, setExpandedFaq] = useState<number | null>(null);

  const filtered = useMemo(() => {
    return FAQS.filter(faq => {
      const matchCat = activeCategory === 'all' || faq.cat === activeCategory;
      const matchSearch = !search.trim() ||
        faq.q.toLowerCase().includes(search.toLowerCase()) ||
        faq.a.toLowerCase().includes(search.toLowerCase());
      return matchCat && matchSearch;
    });
  }, [search, activeCategory]);

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <PrideBar />
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
          <Text style={{ fontSize: 22, color: Colors.text }}>←</Text>
        </TouchableOpacity>
        <Text style={styles.title}>Help Center</Text>
        <View style={{ width: 40 }} />
      </View>

      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Hero */}
        <View style={styles.hero}>
          <Text style={styles.heroEmoji}>💬</Text>
          <Text style={styles.heroTitle}>How can we help?</Text>
          <View style={styles.searchBar}>
            <Text style={{ fontSize: 16, color: Colors.text3 }}>🔍</Text>
            <TextInput
              style={styles.searchInput}
              value={search}
              onChangeText={setSearch}
              placeholder="Search for answers..."
              placeholderTextColor={Colors.text3}
            />
            {!!search && (
              <TouchableOpacity onPress={() => setSearch('')}>
                <Text style={{ fontSize: 16, color: Colors.text3 }}>✕</Text>
              </TouchableOpacity>
            )}
          </View>
        </View>

        {/* Categories */}
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.catsScroll}>
          <View style={{ flexDirection: 'row', gap: 8, paddingHorizontal: 16, paddingBottom: 8 }}>
            <TouchableOpacity
              style={[styles.catChip, activeCategory === 'all' && styles.catChipActive]}
              onPress={() => setActiveCategory('all')}>
              <Text style={[styles.catChipText, activeCategory === 'all' && styles.catChipTextActive]}>All Topics</Text>
            </TouchableOpacity>
            {CATEGORIES.map(cat => (
              <TouchableOpacity key={cat.id}
                style={[styles.catChip, activeCategory === cat.id && styles.catChipActive]}
                onPress={() => setActiveCategory(cat.id)}>
                <Text style={{ fontSize: 14, marginRight: 4 }}>{cat.icon}</Text>
                <Text style={[styles.catChipText, activeCategory === cat.id && styles.catChipTextActive]}>{cat.label}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </ScrollView>

        {/* FAQ count */}
        <Text style={styles.resultCount}>{filtered.length} article{filtered.length !== 1 ? 's' : ''} found</Text>

        {/* FAQs */}
        <View style={{ paddingHorizontal: 16 }}>
          {filtered.length === 0 ? (
            <View style={styles.noResults}>
              <Text style={{ fontSize: 48 }}>🤔</Text>
              <Text style={styles.noResultsText}>No results found</Text>
              <Text style={styles.noResultsSub}>Try a different search term or browse all categories</Text>
            </View>
          ) : (
            filtered.map((faq, i) => (
              <TouchableOpacity
                key={i}
                style={[styles.faq, expandedFaq === i && styles.faqExpanded]}
                onPress={() => setExpandedFaq(expandedFaq === i ? null : i)}
                activeOpacity={0.85}>
                <View style={styles.faqHeader}>
                  <Text style={styles.faqQ}>{faq.q}</Text>
                  <Text style={[styles.faqChevron, expandedFaq === i && styles.faqChevronOpen]}>›</Text>
                </View>
                {expandedFaq === i && (
                  <Text style={styles.faqA}>{faq.a}</Text>
                )}
              </TouchableOpacity>
            ))
          )}
        </View>

        {/* Still need help? */}
        <View style={styles.contactSection}>
          <Text style={styles.contactTitle}>Still need help?</Text>
          <Text style={styles.contactSub}>Our support team typically responds within 24 hours</Text>
          <View style={styles.contactOptions}>
            <TouchableOpacity
              style={styles.contactCard}
              onPress={() => Linking.openURL('mailto:support@sparkdating.app')}>
              <Text style={{ fontSize: 28, marginBottom: 8 }}>✉️</Text>
              <Text style={styles.contactCardTitle}>Email Us</Text>
              <Text style={styles.contactCardSub}>support@sparkdating.app</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={styles.contactCard}
              onPress={() => Alert.alert('Safety Team', 'Contact: safety@sparkdating.app')}>
              <Text style={{ fontSize: 28, marginBottom: 8 }}>🛡️</Text>
              <Text style={styles.contactCardTitle}>Safety Team</Text>
              <Text style={styles.contactCardSub}>Urgent safety issues</Text>
            </TouchableOpacity>
          </View>
          <TouchableOpacity
            style={styles.privacyBtn}
            onPress={() => navigation.navigate('PrivacyPolicy')}>
            <Text style={styles.privacyBtnText}>🔒 View Privacy Policy</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.privacyBtn, { marginTop: 8 }]}
            onPress={() => navigation.navigate('TermsOfService')}>
            <Text style={styles.privacyBtnText}>📜 View Terms of Service</Text>
          </TouchableOpacity>
        </View>

        <View style={{ height: 32 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.bg },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: Spacing.xl, paddingVertical: Spacing.md },
  backBtn: { width: 40, height: 40, alignItems: 'center', justifyContent: 'center' },
  title: { fontSize: 18, fontWeight: '900', color: Colors.text },
  hero: { backgroundColor: Colors.bg3, margin: 16, borderRadius: Radius.xl, padding: 20, alignItems: 'center', borderWidth: 1, borderColor: Colors.border },
  heroEmoji: { fontSize: 40, marginBottom: 8 },
  heroTitle: { fontSize: 20, fontWeight: '900', color: Colors.text, marginBottom: 14 },
  searchBar: { flexDirection: 'row', alignItems: 'center', gap: 10, backgroundColor: Colors.bg, borderRadius: Radius.lg, paddingHorizontal: 14, paddingVertical: 10, width: '100%', borderWidth: 1, borderColor: Colors.border },
  searchInput: { flex: 1, color: Colors.text, fontSize: 14 },
  catsScroll: { flexGrow: 0, marginBottom: 4 },
  catChip: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 14, paddingVertical: 8, borderRadius: Radius.full, backgroundColor: Colors.bg3 },
  catChipActive: { backgroundColor: Colors.accent },
  catChipText: { fontSize: 13, fontWeight: '700', color: Colors.text2 },
  catChipTextActive: { color: '#000' },
  resultCount: { fontSize: 12, color: Colors.text3, fontWeight: '600', paddingHorizontal: 20, marginBottom: 10 },
  faq: { backgroundColor: Colors.bg2, borderRadius: Radius.xl, marginBottom: 10, borderWidth: 1, borderColor: Colors.border, overflow: 'hidden' },
  faqExpanded: { borderColor: Colors.accent },
  faqHeader: { flexDirection: 'row', alignItems: 'flex-start', justifyContent: 'space-between', padding: 16, gap: 12 },
  faqQ: { fontSize: 14, fontWeight: '800', color: Colors.text, flex: 1, lineHeight: 20 },
  faqChevron: { fontSize: 22, color: Colors.text3, marginTop: -2 },
  faqChevronOpen: { transform: [{ rotate: '90deg' }], color: Colors.accent },
  faqA: { fontSize: 13, color: Colors.text2, lineHeight: 22, padding: 16, paddingTop: 0 },
  noResults: { alignItems: 'center', paddingVertical: 48 },
  noResultsText: { fontSize: 18, fontWeight: '800', color: Colors.text, marginTop: 12 },
  noResultsSub: { fontSize: 14, color: Colors.text2, marginTop: 6, textAlign: 'center' },
  contactSection: { margin: 16, backgroundColor: Colors.bg3, borderRadius: Radius.xl, padding: 20, borderWidth: 1, borderColor: Colors.border },
  contactTitle: { fontSize: 18, fontWeight: '900', color: Colors.text, textAlign: 'center', marginBottom: 6 },
  contactSub: { fontSize: 13, color: Colors.text2, textAlign: 'center', marginBottom: 16 },
  contactOptions: { flexDirection: 'row', gap: 12, marginBottom: 14 },
  contactCard: { flex: 1, backgroundColor: Colors.bg4, borderRadius: Radius.lg, padding: 14, alignItems: 'center', borderWidth: 1, borderColor: Colors.border },
  contactCardTitle: { fontSize: 14, fontWeight: '800', color: Colors.text, marginBottom: 4 },
  contactCardSub: { fontSize: 11, color: Colors.text2, textAlign: 'center' },
  privacyBtn: { backgroundColor: Colors.bg4, borderRadius: Radius.lg, paddingVertical: 12, alignItems: 'center', borderWidth: 1, borderColor: Colors.border },
  privacyBtnText: { fontSize: 14, fontWeight: '700', color: Colors.text },
});
