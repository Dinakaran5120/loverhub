import { useState } from "react";
import { View, Text, Pressable } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { LinearGradient } from "expo-linear-gradient";
import { usePathname, useRouter } from "expo-router";
import { Colors } from "@constants/theme";
import { NotificationBell, NotificationCenter } from "@components/notifications/NotificationCenter";

const SCREEN_TITLES: Record<string, string> = {
  "/":            "discover",
  "/explore":     "explore",
  "/post":        "new post",
  "/connections": "messages",
  "/profile":     "profile",
};

const FILTERS = ["All", "Dating", "Friends", "Hookups", "LGBTQ+"];



function DiscoverFilterBar() {
  const [active, setActive] = useState("All");

  return (
    <View
      style={{
        flexDirection: "row",
        paddingHorizontal: 14,
        paddingBottom: 10,
        paddingTop: 4,
        gap: 8,
        flexWrap: "wrap",
      }}
    >
      {FILTERS.map((f) => {
        const isActive = active === f;
        return (
          <Pressable
            key={f}
            onPress={() => setActive(f)}
            style={({ pressed }) => ({ opacity: pressed ? 0.75 : 1 })}
          >
            {isActive ? (
              <LinearGradient
                colors={
                  f === "LGBTQ+"
                    ? [Colors.violet, Colors.rose]
                    : [Colors.primary, Colors.accent]
                }
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 1 }}
                style={{ paddingHorizontal: 14, paddingVertical: 6, borderRadius: 20 }}
              >
                <Text style={{ color: "#fff", fontSize: 12, fontWeight: "700", letterSpacing: 0.2 }}>
                  {f}
                </Text>
              </LinearGradient>
            ) : (
              <View
                style={{
                  paddingHorizontal: 14,
                  paddingVertical: 6,
                  borderRadius: 20,
                  backgroundColor: Colors.card,
                  borderWidth: 1,
                  borderColor: Colors.border,
                }}
              >
                <Text style={{ color: Colors.textSecondary, fontSize: 12, fontWeight: "600", letterSpacing: 0.2 }}>
                  {f}
                </Text>
              </View>
            )}
          </Pressable>
        );
      })}
    </View>
  );
}

export default function TopNavBar() {
  const insets = useSafeAreaInsets();
  const pathname = usePathname();
  const router = useRouter();
  const screenTitle = SCREEN_TITLES[pathname] ?? "lovrhub";
  const isHome = pathname === "/";

  return (
    <View
      style={{
        paddingTop: insets.top,
        backgroundColor: Colors.surface,
        borderBottomWidth: 1,
        borderBottomColor: Colors.border,
      }}
    >
      <View
        style={{
          height: 56,
          flexDirection: "row",
          alignItems: "center",
          paddingHorizontal: 16,
          justifyContent: "space-between",
        }}
      >
        {/* Left */}
        <View style={{ width: 80, alignItems: "flex-start" }}>
          {isHome ? (
            <LinearGradient
              colors={[Colors.primary, Colors.accent]}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
              style={{
                width: 30,
                height: 30,
                borderRadius: 9,
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <Text style={{ fontSize: 16 }}>🔥</Text>
            </LinearGradient>
          ) : (
            <Pressable
              hitSlop={10}
              onPress={() => router.back()}
              style={({ pressed }) => ({ opacity: pressed ? 0.6 : 1 })}
            >
              <Text style={{ fontSize: 22, color: Colors.text }}>←</Text>
            </Pressable>
          )}
        </View>

        {/* Center */}
        <View style={{ flex: 1, alignItems: "center" }}>
          {isHome ? (
            <View style={{ flexDirection: "row", alignItems: "center" }}>
              <Text
                style={{
                  fontSize: 22,
                  fontWeight: "800",
                  letterSpacing: -0.5,
                  color: Colors.text,
                }}
              >
                lovr
              </Text>
              <LinearGradient
                colors={[Colors.primary, Colors.accent]}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 0 }}
                style={{ borderRadius: 4, paddingHorizontal: 3, paddingVertical: 1 }}
              >
                <Text style={{ fontSize: 22, fontWeight: "800", letterSpacing: -0.5, color: "#fff" }}>
                  hub
                </Text>
              </LinearGradient>
            </View>
          ) : (
            <Text
              style={{
                fontSize: 16,
                fontWeight: "700",
                letterSpacing: 0.5,
                textTransform: "uppercase",
                color: Colors.text,
              }}
            >
              {screenTitle}
            </Text>
          )}
        </View>

        {/* Right */}
        <View
          style={{
            width: 80,
            flexDirection: "row",
            alignItems: "center",
            justifyContent: "flex-end",
            gap: 8,
          }}
        >
          {isHome && (
            <Pressable
              hitSlop={8}
              style={({ pressed }) => ({
                opacity: pressed ? 0.6 : 1,
                width: 36,
                height: 36,
                borderRadius: 18,
                backgroundColor: Colors.card,
                alignItems: "center",
                justifyContent: "center",
              })}
            >
              <Text style={{ fontSize: 16 }}>⚙</Text>
            </Pressable>
          )}

          {pathname === "/connections" && (
            <Pressable
              hitSlop={8}
              style={({ pressed }) => ({
                opacity: pressed ? 0.6 : 1,
                width: 36,
                height: 36,
                borderRadius: 18,
                backgroundColor: Colors.card,
                alignItems: "center",
                justifyContent: "center",
              })}
            >
              <Text style={{ fontSize: 18 }}>✏️</Text>
            </Pressable>
          )}

          <NotificationBell />
        </View>
      </View>

      {isHome && <DiscoverFilterBar />}
      <NotificationCenter />
    </View>
  );
}
