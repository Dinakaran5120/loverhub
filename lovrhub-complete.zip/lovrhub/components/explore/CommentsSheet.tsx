import { useState, useRef, useEffect } from "react";
import {
  View, Text, Modal, Pressable, ScrollView,
  TextInput, KeyboardAvoidingView, Platform, Animated,
  Dimensions,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Colors } from "@constants/theme";
import { useExploreStore } from "@/store/exploreStore";
import { useTimeAgo } from "@/hooks/useExploreFeed";
import type { PostComment, ExplorePost } from "@/types/explore";

const { height: H } = Dimensions.get("window");
const SHEET_H = H * 0.82;

function CommentRow({ comment, postId }: { comment: PostComment; postId: string }) {
  const likeComment = useExploreStore((s) => s.likeComment);
  const ago = useTimeAgo(comment.createdAt);

  return (
    <View
      style={{
        flexDirection: "row",
        paddingVertical: 12,
        paddingHorizontal: 20,
        gap: 12,
        borderBottomWidth: 1,
        borderBottomColor: Colors.border,
      }}
    >
      {/* Avatar */}
      <LinearGradient
        colors={comment.author.gradient}
        start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
        style={{ width: 36, height: 36, borderRadius: 18, alignItems: "center", justifyContent: "center", flexShrink: 0 }}
      >
        <Text style={{ fontSize: 18 }}>
          {comment.author.isAnonymous ? "👤" : comment.author.avatarEmoji}
        </Text>
      </LinearGradient>

      <View style={{ flex: 1, gap: 3 }}>
        <View style={{ flexDirection: "row", alignItems: "center", gap: 6 }}>
          <Text style={{ fontSize: 13, fontWeight: "700", color: Colors.text }}>
            {comment.author.isAnonymous ? "Anonymous" : comment.author.name}
          </Text>
          {comment.author.verified && (
            <View style={{ width: 14, height: 14, borderRadius: 7, backgroundColor: "#3b82f6", alignItems: "center", justifyContent: "center" }}>
              <Text style={{ color: "#fff", fontSize: 8, fontWeight: "800" }}>✓</Text>
            </View>
          )}
          <Text style={{ fontSize: 11, color: Colors.textMuted }}>{ago}</Text>
        </View>
        <Text style={{ fontSize: 14, color: Colors.text, lineHeight: 20 }}>{comment.text}</Text>
        <Pressable
          onPress={() => likeComment(postId, comment.id)}
          style={{ flexDirection: "row", alignItems: "center", gap: 4, marginTop: 2 }}
        >
          <Text style={{ fontSize: 13 }}>{comment.liked ? "❤️" : "🤍"}</Text>
          {comment.likes > 0 && (
            <Text style={{ fontSize: 11, color: Colors.textMuted, fontWeight: "600" }}>
              {comment.likes}
            </Text>
          )}
        </Pressable>
      </View>
    </View>
  );
}

export function CommentsSheet({ post }: { post: ExplorePost | null }) {
  const insets          = useSafeAreaInsets();
  const addComment      = useExploreStore((s) => s.addComment);
  const setShowComments = useExploreStore((s) => s.setShowComments);
  const slideAnim       = useRef(new Animated.Value(SHEET_H)).current;
  const [text, setText] = useState("");

  const visible = post !== null;

  useEffect(() => {
    Animated.spring(slideAnim, {
      toValue: visible ? 0 : SHEET_H,
      useNativeDriver: true,
      stiffness: 300,
      damping: 30,
    }).start();
  }, [visible]);

  const handleSend = () => {
    if (!post || !text.trim()) return;
    addComment(post.id, text);
    setText("");
  };

  return (
    <Modal visible={visible} transparent animationType="none" onRequestClose={() => setShowComments(null)}>
      <Pressable
        style={{ flex: 1, backgroundColor: "rgba(0,0,0,0.5)" }}
        onPress={() => setShowComments(null)}
      />
      <Animated.View
        style={{
          position: "absolute", bottom: 0, left: 0, right: 0,
          height: SHEET_H,
          backgroundColor: Colors.surface,
          borderTopLeftRadius: 28, borderTopRightRadius: 28,
          transform: [{ translateY: slideAnim }],
        }}
      >
        {/* Handle */}
        <View style={{ alignItems: "center", paddingTop: 12 }}>
          <View style={{ width: 40, height: 4, borderRadius: 2, backgroundColor: Colors.border }} />
        </View>

        {/* Header */}
        <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 20, paddingVertical: 14, borderBottomWidth: 1, borderBottomColor: Colors.border }}>
          <Text style={{ fontSize: 16, fontWeight: "800", color: Colors.text }}>
            Comments {post && post.comments.length > 0 ? `(${post.comments.length})` : ""}
          </Text>
          <Pressable
            onPress={() => setShowComments(null)}
            style={({ pressed }) => ({ opacity: pressed ? 0.6 : 1, width: 30, height: 30, borderRadius: 15, backgroundColor: Colors.card, alignItems: "center", justifyContent: "center" })}
          >
            <Text style={{ fontSize: 15, color: Colors.text }}>✕</Text>
          </Pressable>
        </View>

        {/* Comments list */}
        <ScrollView style={{ flex: 1 }} showsVerticalScrollIndicator={false}>
          {post && post.comments.length === 0 && (
            <View style={{ alignItems: "center", paddingVertical: 48, gap: 10 }}>
              <Text style={{ fontSize: 36 }}>💬</Text>
              <Text style={{ fontSize: 15, color: Colors.textMuted }}>No comments yet</Text>
              <Text style={{ fontSize: 13, color: Colors.textMuted }}>Be the first to say something</Text>
            </View>
          )}
          {post?.comments.map((c) => (
            <CommentRow key={c.id} comment={c} postId={post.id} />
          ))}
          <View style={{ height: 100 }} />
        </ScrollView>

        {/* Input */}
        <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : "height"}>
          <View
            style={{
              flexDirection: "row", alignItems: "center", gap: 10,
              paddingHorizontal: 16, paddingVertical: 12,
              paddingBottom: insets.bottom + 12,
              borderTopWidth: 1, borderTopColor: Colors.border,
              backgroundColor: Colors.surface,
            }}
          >
            <LinearGradient
              colors={[Colors.primary, Colors.accent]}
              start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
              style={{ width: 34, height: 34, borderRadius: 17, alignItems: "center", justifyContent: "center" }}
            >
              <Text style={{ fontSize: 16 }}>😊</Text>
            </LinearGradient>
            <View
              style={{
                flex: 1, flexDirection: "row", alignItems: "center",
                backgroundColor: Colors.card, borderRadius: 22,
                paddingHorizontal: 14, paddingVertical: 8,
                borderWidth: 1, borderColor: Colors.border, gap: 8,
              }}
            >
              <TextInput
                value={text}
                onChangeText={setText}
                placeholder="Add a comment…"
                placeholderTextColor={Colors.textMuted}
                style={{ flex: 1, fontSize: 14, color: Colors.text, padding: 0 }}
                multiline
                maxLength={300}
              />
            </View>
            <Pressable
              onPress={handleSend}
              disabled={!text.trim()}
              style={({ pressed }) => ({
                opacity: text.trim() ? (pressed ? 0.7 : 1) : 0.35,
                transform: [{ scale: pressed && text.trim() ? 0.93 : 1 }],
              })}
            >
              <LinearGradient
                colors={[Colors.primary, Colors.accent]}
                start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
                style={{ width: 38, height: 38, borderRadius: 19, alignItems: "center", justifyContent: "center" }}
              >
                <Text style={{ fontSize: 16 }}>↑</Text>
              </LinearGradient>
            </Pressable>
          </View>
        </KeyboardAvoidingView>
      </Animated.View>
    </Modal>
  );
}
