import { useState } from "react";
import { View, Text, KeyboardAvoidingView, Platform, ScrollView, Pressable } from "react-native";
import { useRouter } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Colors } from "@constants/theme";
import { useAuthStore } from "@/store/authStore";
import { AuthInput, PrimaryButton, BackButton, StepHeader } from "@components/auth/AuthUI";

const COUNTRY_CODES = [
  { flag: "🇮🇳", code: "+91", name: "India"   },
  { flag: "🇺🇸", code: "+1",  name: "USA"     },
  { flag: "🇬🇧", code: "+44", name: "UK"      },
  { flag: "🇦🇺", code: "+61", name: "AUS"     },
  { flag: "🇨🇦", code: "+1",  name: "Canada"  },
];

function GoogleIcon() {
  return (
    <View style={{ width: 22, height: 22, borderRadius: 11, backgroundColor: "#fff", borderWidth: 1, borderColor: "#E0E0E0", alignItems: "center", justifyContent: "center" }}>
      <Text style={{ fontSize: 13, fontWeight: "800", color: "#4285F4" }}>G</Text>
    </View>
  );
}

export default function PhoneScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const updateProfile = useAuthStore((s) => s.updateProfile);

  const [phone, setPhone]           = useState("");
  const [selectedCC, setSelectedCC] = useState(COUNTRY_CODES[0]);
  const [showPicker, setShowPicker] = useState(false);
  const [error, setError]           = useState("");
  const [loading, setLoading]       = useState(false);

  const handleContinue = async () => {
    if (phone.length < 10) { setError("Enter a valid 10-digit mobile number"); return; }
    setError("");
    setLoading(true);
    await new Promise((r) => setTimeout(r, 900));
    setLoading(false);
    updateProfile({ phone: `${selectedCC.code}${phone}` });
    router.push("/auth/otp");
  };

  return (
    <KeyboardAvoidingView
      style={{ flex: 1, backgroundColor: Colors.background }}
      behavior={Platform.OS === "ios" ? "padding" : "height"}
    >
      <View style={{ paddingTop: insets.top }}>
        <BackButton onPress={() => router.back()} />
      </View>

      <ScrollView
        contentContainerStyle={{ flexGrow: 1, paddingBottom: insets.bottom + 32 }}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        <StepHeader emoji="📱" title={"What's your\nnumber?"} subtitle="We'll send a one-time code to verify it's you." />

        <View style={{ paddingHorizontal: 24, gap: 16 }}>
          {/* Country picker */}
          <View>
            <Text style={{ fontSize: 13, fontWeight: "700", color: Colors.textSecondary, marginBottom: 8, letterSpacing: 0.3 }}>
              Country
            </Text>
            <Pressable
              onPress={() => setShowPicker(!showPicker)}
              style={({ pressed }) => ({
                flexDirection: "row", alignItems: "center", justifyContent: "space-between",
                backgroundColor: Colors.surface, borderRadius: 16,
                borderWidth: 1.5, borderColor: showPicker ? Colors.accent : Colors.border,
                paddingHorizontal: 16, paddingVertical: 14,
                opacity: pressed ? 0.8 : 1,
              })}
            >
              <View style={{ flexDirection: "row", alignItems: "center", gap: 10 }}>
                <Text style={{ fontSize: 22 }}>{selectedCC.flag}</Text>
                <Text style={{ fontSize: 15, color: Colors.text, fontWeight: "600" }}>{selectedCC.name}</Text>
                <Text style={{ fontSize: 15, color: Colors.textMuted }}>{selectedCC.code}</Text>
              </View>
              <Text style={{ fontSize: 12, color: Colors.textMuted }}>{showPicker ? "▲" : "▼"}</Text>
            </Pressable>

            {showPicker && (
              <View
                style={{
                  backgroundColor: Colors.surface, borderRadius: 16,
                  borderWidth: 1, borderColor: Colors.border, marginTop: 4,
                  overflow: "hidden", shadowColor: "#000",
                  shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.08,
                  shadowRadius: 12, elevation: 4,
                }}
              >
                {COUNTRY_CODES.map((cc) => (
                  <Pressable
                    key={cc.name}
                    onPress={() => { setSelectedCC(cc); setShowPicker(false); }}
                    style={({ pressed }) => ({
                      flexDirection: "row", alignItems: "center", gap: 12, padding: 14,
                      backgroundColor: selectedCC.name === cc.name ? Colors.card : pressed ? Colors.card : Colors.surface,
                      borderBottomWidth: 1, borderBottomColor: Colors.border,
                    })}
                  >
                    <Text style={{ fontSize: 22 }}>{cc.flag}</Text>
                    <Text style={{ fontSize: 15, color: Colors.text, fontWeight: "600", flex: 1 }}>{cc.name}</Text>
                    <Text style={{ fontSize: 14, color: Colors.textMuted }}>{cc.code}</Text>
                    {selectedCC.name === cc.name && (
                      <Text style={{ fontSize: 16, color: Colors.primary }}>✓</Text>
                    )}
                  </Pressable>
                ))}
              </View>
            )}
          </View>

          <AuthInput
            label="Mobile Number"
            prefix={selectedCC.code}
            placeholder="98765 43210"
            value={phone}
            onChangeText={(t) => { setPhone(t.replace(/\D/g, "").slice(0, 10)); if (error) setError(""); }}
            keyboardType="phone-pad"
            maxLength={10}
            error={error}
            hint="We'll send an OTP to this number"
          />

          <PrimaryButton label="Send OTP" onPress={handleContinue} loading={loading} disabled={phone.length < 10} icon="→" />

          <View style={{ flexDirection: "row", alignItems: "center", gap: 12 }}>
            <View style={{ flex: 1, height: 1, backgroundColor: Colors.border }} />
            <Text style={{ color: Colors.textMuted, fontSize: 13 }}>or</Text>
            <View style={{ flex: 1, height: 1, backgroundColor: Colors.border }} />
          </View>

          <Pressable
            style={({ pressed }) => ({
              borderRadius: 18, paddingVertical: 17,
              flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 10,
              borderWidth: 1.5, borderColor: Colors.border, backgroundColor: Colors.surface,
              opacity: pressed ? 0.7 : 1,
            })}
          >
            <GoogleIcon />
            <Text style={{ color: Colors.text, fontSize: 15, fontWeight: "700" }}>Sign up with Google</Text>
          </Pressable>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}
