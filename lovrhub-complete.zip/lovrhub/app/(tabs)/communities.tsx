import { useState } from "react";
import { View, Text, ScrollView, Pressable, TextInput } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { Colors } from "@constants/theme";
import { useCommunityStore } from "@/store/communityStore";
import { useMyCommunitites, useDiscoverCommunities, usePendingRequestCount } from "@/hooks/useCommunity";
import { CommunityCard } from "@components/communities/CommunityCard";
import { JoinRequestModal } from "@components/communities/JoinRequestModal";
import { CreateCommunityModal } from "@components/communities/CreateCommunityModal";
import { CommunityDetailScreen } from "@components/communities/CommunityDetailScreen";

type BrowseTab = "mine" | "discover";

const CATEGORIES = ["All", "Dating", "LGBTQ+", "Food & Social", "Professional", "Social", "Mental Health"];

function CategoryStrip({ onSelect }: { onSelect: (cat: string) => void }) {
  const [active, setActive] = useState("All");
  return (
    <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 8, paddingBottom: 14 }}>
      {CATEGORIES.map((cat) => {
        const isActive = active === cat;
        return (
          <Pressable key={cat} onPress={() => { setActive(cat); onSelect(cat === "All" ? "" : cat); }}>
            {isActive ? (
              <LinearGradient colors={[Colors.violet, Colors.sky]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} style={{ paddingHorizontal: 14, paddingVertical: 7, borderRadius: 18 }}>
                <Text style={{ color: "#fff", fontSize: 13, fontWeight: "700" }}>{cat}</Text>
              </LinearGradient>
            ) : (
              <View style={{ paddingHorizontal: 14, paddingVertical: 7, borderRadius: 18, backgroundColor: Colors.card, borderWidth: 1, borderColor: Colors.border }}>
                <Text style={{ color: Colors.textSecondary, fontSize: 13, fontWeight: "600" }}>{cat}</Text>
              </View>
            )}
          </Pressable>
        );
      })}
    </ScrollView>
  );
}

export default function CommunitiesScreen() {
  const activeCommunityId  = useCommunityStore((s) => s.activeCommunityId);
  const setActiveCommunity = useCommunityStore((s) => s.setActiveCommunity);
  const setShowCreate      = useCommunityStore((s) => s.setShowCreateModal);
  const pendingCount       = usePendingRequestCount();
  const myCommunities      = useMyCommunitites();

  const [tab, setTab]       = useState<BrowseTab>("mine");
  const [search, setSearch] = useState("");

  const discoverList = useDiscoverCommunities(search);

  if (activeCommunityId) return <CommunityDetailScreen />;

  return (
    <View style={{ flex: 1, backgroundColor: Colors.background }}>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 40 }}>
        {/* Header */}
        <View style={{ paddingHorizontal: 16, paddingTop: 16, paddingBottom: 12, backgroundColor: Colors.surface, borderBottomWidth: 1, borderBottomColor: Colors.border, gap: 12 }}>
          <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between" }}>
            <View>
              <Text style={{ fontSize: 22, fontWeight: "900", color: Colors.text, letterSpacing: -0.5 }}>Communities</Text>
              <Text style={{ fontSize: 13, color: Colors.textMuted, marginTop: 2 }}>Find your people</Text>
            </View>
            <Pressable onPress={() => setShowCreate(true)} style={({ pressed }) => ({ opacity: pressed ? 0.85 : 1, transform: [{ scale: pressed ? 0.96 : 1 }] })}>
              <LinearGradient colors={[Colors.primary, Colors.accent]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} style={{ flexDirection: "row", alignItems: "center", gap: 6, paddingHorizontal: 16, paddingVertical: 10, borderRadius: 16, shadowColor: Colors.primary, shadowOffset: { width: 0, height: 3 }, shadowOpacity: 0.3, shadowRadius: 8, elevation: 4 }}>
                <Text style={{ color: "#fff", fontSize: 16, lineHeight: 20 }}>+</Text>
                <Text style={{ color: "#fff", fontSize: 13, fontWeight: "800" }}>Create</Text>
              </LinearGradient>
            </Pressable>
          </View>

          {/* Search */}
          <View style={{ flexDirection: "row", alignItems: "center", backgroundColor: Colors.card, borderRadius: 14, paddingHorizontal: 12, paddingVertical: 9, borderWidth: 1, borderColor: Colors.border, gap: 8 }}>
            <Text style={{ fontSize: 15, opacity: 0.5 }}>🔍</Text>
            <TextInput value={search} onChangeText={setSearch} placeholder="Search communities…" placeholderTextColor={Colors.textMuted} style={{ flex: 1, fontSize: 14, color: Colors.text, padding: 0 }} />
          </View>

          {/* Tabs */}
          <View style={{ flexDirection: "row", gap: 8 }}>
            {(["mine", "discover"] as BrowseTab[]).map((t) => {
              const isActive = tab === t;
              const label = t === "mine" ? `My Communities${myCommunities.length > 0 ? ` (${myCommunities.length})` : ""}` : "Discover";
              return (
                <Pressable key={t} onPress={() => setTab(t)} style={{ flex: 1 }}>
                  {isActive ? (
                    <LinearGradient colors={[Colors.primary, Colors.accent]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} style={{ paddingVertical: 10, borderRadius: 14, alignItems: "center" }}>
                      <Text style={{ color: "#fff", fontWeight: "800", fontSize: 13 }}>{label}</Text>
                    </LinearGradient>
                  ) : (
                    <View style={{ paddingVertical: 10, borderRadius: 14, alignItems: "center", backgroundColor: Colors.card, borderWidth: 1, borderColor: Colors.border }}>
                      <Text style={{ color: Colors.textMuted, fontWeight: "600", fontSize: 13 }}>{label}</Text>
                    </View>
                  )}
                </Pressable>
              );
            })}
          </View>
        </View>

        <View style={{ padding: 16 }}>
          {/* Pending requests banner */}
          {pendingCount > 0 && tab === "mine" && (
            <Pressable
              onPress={() => {
                const c = useCommunityStore.getState().communities.find(
                  (c) => (c.myStatus === "owner" || c.myStatus === "admin") && c.pendingRequests.length > 0
                );
                if (c) setActiveCommunity(c.id);
              }}
              style={({ pressed }) => ({ opacity: pressed ? 0.9 : 1, marginBottom: 16 })}
            >
              <LinearGradient colors={[Colors.gold, Colors.accent]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", padding: 14, borderRadius: 16 }}>
                <View style={{ flexDirection: "row", alignItems: "center", gap: 10 }}>
                  <Text style={{ fontSize: 20 }}>🔔</Text>
                  <View>
                    <Text style={{ color: "#fff", fontSize: 14, fontWeight: "800" }}>{pendingCount} pending join {pendingCount === 1 ? "request" : "requests"}</Text>
                    <Text style={{ color: "rgba(255,255,255,0.8)", fontSize: 12 }}>Tap to review</Text>
                  </View>
                </View>
                <Text style={{ color: "#fff", fontSize: 18 }}>→</Text>
              </LinearGradient>
            </Pressable>
          )}

          {/* My communities */}
          {tab === "mine" && (
            myCommunities.length === 0 ? (
              <View style={{ alignItems: "center", paddingVertical: 56, gap: 14 }}>
                <View style={{ width: 80, height: 80, borderRadius: 40, backgroundColor: Colors.card, borderWidth: 2, borderColor: Colors.border, borderStyle: "dashed", alignItems: "center", justifyContent: "center" }}>
                  <Text style={{ fontSize: 36 }}>🏘️</Text>
                </View>
                <Text style={{ fontSize: 18, fontWeight: "800", color: Colors.text }}>No communities yet</Text>
                <Text style={{ fontSize: 14, color: Colors.textMuted, textAlign: "center", lineHeight: 21, paddingHorizontal: 24 }}>
                  Join a community or create your own.
                </Text>
                <View style={{ flexDirection: "row", gap: 10 }}>
                  <Pressable onPress={() => setTab("discover")} style={({ pressed }) => ({ paddingHorizontal: 20, paddingVertical: 12, borderRadius: 14, borderWidth: 1.5, borderColor: Colors.border, backgroundColor: Colors.card, opacity: pressed ? 0.7 : 1 })}>
                    <Text style={{ fontSize: 14, fontWeight: "700", color: Colors.textSecondary }}>Browse →</Text>
                  </Pressable>
                  <Pressable onPress={() => setShowCreate(true)} style={({ pressed }) => ({ opacity: pressed ? 0.85 : 1 })}>
                    <LinearGradient colors={[Colors.primary, Colors.accent]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} style={{ paddingHorizontal: 20, paddingVertical: 12, borderRadius: 14 }}>
                      <Text style={{ fontSize: 14, fontWeight: "800", color: "#fff" }}>Create +</Text>
                    </LinearGradient>
                  </Pressable>
                </View>
              </View>
            ) : (
              myCommunities.map((c) => <CommunityCard key={c.id} community={c} onPress={() => setActiveCommunity(c.id)} />)
            )
          )}

          {/* Discover */}
          {tab === "discover" && (
            <>
              <CategoryStrip onSelect={setSearch} />
              {discoverList.length === 0 ? (
                <View style={{ alignItems: "center", paddingVertical: 48, gap: 10 }}>
                  <Text style={{ fontSize: 36 }}>🔍</Text>
                  <Text style={{ fontSize: 15, fontWeight: "700", color: Colors.text }}>No communities found</Text>
                  <Pressable onPress={() => setSearch("")}><Text style={{ fontSize: 14, color: Colors.primary, fontWeight: "700" }}>Clear search</Text></Pressable>
                </View>
              ) : (
                discoverList.map((c) => <CommunityCard key={c.id} community={c} onPress={() => setActiveCommunity(c.id)} />)
              )}
            </>
          )}
        </View>
      </ScrollView>

      <JoinRequestModal />
      <CreateCommunityModal />
    </View>
  );
}
