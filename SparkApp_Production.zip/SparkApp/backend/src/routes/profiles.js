const { profileRoutes } = require('./allRoutes'); module.exports = profileRoutes;
