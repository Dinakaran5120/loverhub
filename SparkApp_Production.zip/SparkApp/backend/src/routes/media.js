const { mediaRoutes } = require('./allRoutes'); module.exports = mediaRoutes;
