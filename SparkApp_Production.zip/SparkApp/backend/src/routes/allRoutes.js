const express = require('express');
const protect = require('../middleware/auth');
const { Match, Message, Post, Community, Report, Notification } = require('../models/Models');
const { getMatches, unmatch } = require('../controllers/swipeController');

// ── MATCHES ────────────────────────────────────────────────────────────────────
const matchRouter = express.Router();
matchRouter.get('/', protect, getMatches);
matchRouter.delete('/:matchId', protect, unmatch);

// ── MESSAGES ───────────────────────────────────────────────────────────────────
const msgRouter = express.Router();

msgRouter.get('/:matchId', protect, async (req, res, next) => {
  try {
    const match = await Match.findOne({ _id: req.params.matchId, users: req.user._id });
    if (!match) return res.status(404).json({ success: false, message: 'Match not found.' });

    const messages = await Message.find({ match: req.params.matchId, isDeleted: false })
      .sort({ createdAt: 1 }).limit(100)
      .populate('sender', 'name photos');

    await Message.updateMany(
      { match: req.params.matchId, sender: { $ne: req.user._id }, readBy: { $ne: req.user._id } },
      { $addToSet: { readBy: req.user._id } }
    );
    res.status(200).json({ success: true, messages });
  } catch (err) { next(err); }
});

msgRouter.post('/:matchId', protect, async (req, res, next) => {
  try {
    const match = await Match.findOne({ _id: req.params.matchId, users: req.user._id, isActive: true });
    if (!match) return res.status(404).json({ success: false, message: 'Match not found.' });

    const message = await Message.create({
      match: req.params.matchId,
      sender: req.user._id,
      text: req.body.text,
      mediaUrl: req.body.mediaUrl,
      mediaType: req.body.mediaType
    });

    match.lastMessage = message._id;
    match.lastMessageAt = new Date();
    await match.save();

    const populated = await Message.findById(message._id).populate('sender', 'name photos');
    res.status(201).json({ success: true, message: populated });
  } catch (err) { next(err); }
});

msgRouter.delete('/:matchId/:messageId', protect, async (req, res, next) => {
  try {
    const msg = await Message.findOne({ _id: req.params.messageId, sender: req.user._id });
    if (!msg) return res.status(404).json({ success: false, message: 'Message not found.' });
    msg.isDeleted = true;
    msg.text = 'This message was deleted.';
    await msg.save();
    res.status(200).json({ success: true });
  } catch (err) { next(err); }
});

// ── POSTS ──────────────────────────────────────────────────────────────────────
const postRouter = express.Router();

postRouter.get('/', protect, async (req, res, next) => {
  try {
    const { tab = 'feed', communityId, page = 1 } = req.query;
    const limit = 20;
    const skip = (page - 1) * limit;

    let query = { isDeleted: false };
    if (tab === 'reels') query.type = { $in: ['video', 'reel'] };
    if (communityId) query.community = communityId;
    else query.isPublic = true;

    const posts = await Post.find(query)
      .sort({ createdAt: -1 }).skip(skip).limit(limit)
      .populate('author', 'name age photos orientation');

    const formatted = posts.map(p => ({
      ...p.toObject(),
      likeCount: p.likes.length,
      commentCount: p.comments.length,
      liked: p.likes.includes(req.user._id),
      author: p.isAnonymous ? { name: 'Anonymous' } : p.author
    }));

    res.status(200).json({ success: true, posts: formatted });
  } catch (err) { next(err); }
});

postRouter.post('/', protect, async (req, res, next) => {
  try {
    const { type, content, mediaUrl, mediaPublicId, thumbnailUrl, mood, isAnonymous, communityId, tags } = req.body;
    const post = await Post.create({
      author: req.user._id,
      type, content, mediaUrl, mediaPublicId, thumbnailUrl, mood,
      isAnonymous: !!isAnonymous,
      community: communityId || null,
      isPublic: true,
      tags: tags || []
    });
    const populated = await Post.findById(post._id).populate('author', 'name age photos orientation');
    res.status(201).json({ success: true, post: populated });
  } catch (err) { next(err); }
});

postRouter.put('/:id/like', protect, async (req, res, next) => {
  try {
    const post = await Post.findById(req.params.id);
    if (!post) return res.status(404).json({ success: false });
    const liked = post.likes.includes(req.user._id);
    if (liked) post.likes.pull(req.user._id);
    else post.likes.push(req.user._id);
    await post.save();
    res.status(200).json({ success: true, liked: !liked, likeCount: post.likes.length });
  } catch (err) { next(err); }
});

postRouter.post('/:id/comment', protect, async (req, res, next) => {
  try {
    const post = await Post.findById(req.params.id);
    if (!post) return res.status(404).json({ success: false });
    post.comments.push({ user: req.user._id, text: req.body.text, isAnonymous: req.body.isAnonymous });
    await post.save();
    res.status(201).json({ success: true, comment: post.comments[post.comments.length - 1] });
  } catch (err) { next(err); }
});

postRouter.delete('/:id', protect, async (req, res, next) => {
  try {
    const post = await Post.findOne({ _id: req.params.id, author: req.user._id });
    if (!post) return res.status(404).json({ success: false });
    post.isDeleted = true;
    await post.save();
    res.status(200).json({ success: true });
  } catch (err) { next(err); }
});

// ── COMMUNITIES ────────────────────────────────────────────────────────────────
const commRouter = express.Router();

commRouter.get('/', protect, async (req, res, next) => {
  try {
    const { search, category, page = 1 } = req.query;
    const query = { isDeleted: false };
    if (search) query.name = { $regex: search, $options: 'i' };
    if (category && category !== 'all') query.category = category;

    const communities = await Community.find(query)
      .sort({ memberCount: -1 })
      .skip((page - 1) * 20).limit(20)
      .populate('owner', 'name photos');

    const formatted = communities.map(c => ({
      ...c.toObject(),
      memberStatus: c.members.includes(req.user._id) ? 'joined'
        : c.pendingRequests.some(r => String(r.user) === String(req.user._id)) ? 'requested'
        : 'none'
    }));

    res.status(200).json({ success: true, communities: formatted });
  } catch (err) { next(err); }
});

commRouter.post('/', protect, async (req, res, next) => {
  try {
    const { name, description, emoji, category, isPublic, rules } = req.body;
    const slug = name.toLowerCase().replace(/[^a-z0-9]/g, '-') + '-' + Date.now();

    const community = await Community.create({
      name, description, emoji: emoji || '✨', category, isPublic,
      slug, owner: req.user._id, members: [req.user._id], memberCount: 1, rules: rules || []
    });

    res.status(201).json({ success: true, community });
  } catch (err) { next(err); }
});

commRouter.post('/:id/join', protect, async (req, res, next) => {
  try {
    const community = await Community.findById(req.params.id);
    if (!community) return res.status(404).json({ success: false });
    if (community.members.includes(req.user._id)) {
      return res.status(400).json({ success: false, message: 'Already a member.' });
    }

    if (community.isPublic) {
      community.members.push(req.user._id);
      community.memberCount += 1;
      await community.save();
      return res.status(200).json({ success: true, status: 'joined' });
    } else {
      const already = community.pendingRequests.some(r => String(r.user) === String(req.user._id));
      if (!already) {
        community.pendingRequests.push({ user: req.user._id, message: req.body.message });
        await community.save();
      }
      return res.status(200).json({ success: true, status: 'requested' });
    }
  } catch (err) { next(err); }
});

commRouter.put('/:id/approve/:userId', protect, async (req, res, next) => {
  try {
    const community = await Community.findOne({ _id: req.params.id, owner: req.user._id });
    if (!community) return res.status(403).json({ success: false, message: 'Not authorized.' });

    community.pendingRequests = community.pendingRequests.filter(r => String(r.user) !== req.params.userId);
    community.members.push(req.params.userId);
    community.memberCount += 1;
    await community.save();
    res.status(200).json({ success: true });
  } catch (err) { next(err); }
});

commRouter.delete('/:id/leave', protect, async (req, res, next) => {
  try {
    const community = await Community.findById(req.params.id);
    if (!community) return res.status(404).json({ success: false });
    community.members.pull(req.user._id);
    community.memberCount = Math.max(0, community.memberCount - 1);
    await community.save();
    res.status(200).json({ success: true });
  } catch (err) { next(err); }
});

// ── MEDIA ──────────────────────────────────────────────────────────────────────
const mediaRouter = express.Router();
const mediaCtrl = require('../controllers/mediaController');

mediaRouter.post('/profile-photo', protect, mediaCtrl.upload.single('photo'), mediaCtrl.uploadProfilePhoto);
mediaRouter.delete('/profile-photo/:photoId', protect, mediaCtrl.deleteProfilePhoto);
mediaRouter.post('/post-media', protect, mediaCtrl.upload.single('media'), mediaCtrl.uploadPostMedia);
mediaRouter.post('/community-image', protect, mediaCtrl.upload.single('image'), mediaCtrl.uploadCommunityImage);
mediaRouter.post('/chat-media', protect, mediaCtrl.upload.single('media'), mediaCtrl.uploadChatMedia);

// ── REPORTS ────────────────────────────────────────────────────────────────────
const reportRouter = express.Router();

reportRouter.post('/', protect, async (req, res, next) => {
  try {
    const { reportedUserId, reportedPostId, reason, description } = req.body;
    await Report.create({
      reporter: req.user._id,
      reportedUser: reportedUserId,
      reportedPost: reportedPostId,
      reason, description
    });
    if (reportedUserId) {
      const { default: User } = require('../models/User');
      await User.findByIdAndUpdate(reportedUserId, { $inc: { reportCount: 1 } });
    }
    res.status(201).json({ success: true, message: 'Report submitted. We review all reports within 24 hours.' });
  } catch (err) { next(err); }
});

// ── NOTIFICATIONS ──────────────────────────────────────────────────────────────
const notifRouter = express.Router();

notifRouter.get('/', protect, async (req, res, next) => {
  try {
    const notifs = await Notification.find({ recipient: req.user._id })
      .sort({ createdAt: -1 }).limit(50)
      .populate('sender', 'name photos');
    res.status(200).json({ success: true, notifications: notifs });
  } catch (err) { next(err); }
});

notifRouter.put('/read-all', protect, async (req, res, next) => {
  try {
    await Notification.updateMany({ recipient: req.user._id, isRead: false }, { isRead: true });
    res.status(200).json({ success: true });
  } catch (err) { next(err); }
});

// ── PREMIUM ────────────────────────────────────────────────────────────────────
const premiumRouter = express.Router();
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);

premiumRouter.post('/create-subscription', protect, async (req, res, next) => {
  try {
    const { plan, paymentMethodId } = req.body;
    const PRICE_IDS = {
      gold_monthly: 'price_gold_monthly',
      gold_annual: 'price_gold_annual',
      platinum_monthly: 'price_platinum_monthly'
    };

    let customer;
    const User = require('../models/User');
    const user = await User.findById(req.user._id);

    if (user.premium.stripeCustomerId) {
      customer = await stripe.customers.retrieve(user.premium.stripeCustomerId);
    } else {
      customer = await stripe.customers.create({ email: user.email, payment_method: paymentMethodId, invoice_settings: { default_payment_method: paymentMethodId } });
      user.premium.stripeCustomerId = customer.id;
    }

    const subscription = await stripe.subscriptions.create({
      customer: customer.id,
      items: [{ price: PRICE_IDS[plan] }],
      expand: ['latest_invoice.payment_intent']
    });

    user.premium.isActive = true;
    user.premium.plan = plan.startsWith('gold') ? 'gold' : 'platinum';
    user.premium.stripeSubscriptionId = subscription.id;
    user.premium.expiresAt = new Date(subscription.current_period_end * 1000);
    await user.save();

    res.status(200).json({ success: true, subscription });
  } catch (err) { next(err); }
});

// ── PROFILES ───────────────────────────────────────────────────────────────────
const profileRouter = express.Router();
// profiles routes re-export users routes
const usersRouter = require('./users');

module.exports = {
  matchRoutes: matchRouter,
  messageRoutes: msgRouter,
  postRoutes: postRouter,
  communityRoutes: commRouter,
  mediaRoutes: mediaRouter,
  reportRoutes: reportRouter,
  notificationRoutes: notifRouter,
  premiumRoutes: premiumRouter,
  profileRoutes: usersRouter
};
