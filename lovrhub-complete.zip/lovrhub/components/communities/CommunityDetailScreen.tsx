import { useState } from "react";
import {
  View, Text, ScrollView, Pressable, Modal,
  TextInput, KeyboardAvoidingView, Platform,
  Dimensions,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Colors } from "@constants/theme";
import { useCommunityStore } from "@/store/communityStore";
import { useActiveCommunity, useCommunityFeed, fmtNum, timeAgo } from "@/hooks/useCommunity";
import { CommunityPostCard } from "@components/communities/CommunityPostCard";
import type { CommunityPost } from "@/types/community";

const { width: W } = Dimensions.get("window");

type DetailTab = "feed" | "members" | "about" | "requests";

// ── Create post inside a community ───────────────────────────────────────────
function CreatePostSheet({ communityId, onClose }: { communityId: string; onClose: () => void }) {
  const insets   = useSafeAreaInsets();
  const addPost  = useCommunityStore((s) => s.addPost);
  const [type, setType] = useState<CommunityPost["type"]>("text");
  const [content, setContent] = useState("");
  const [title, setTitle]     = useState("");

  const POST_TYPES: { type: CommunityPost["type"]; label: string; emoji: string }[] = [
    { type: "text",  label: "Post",  emoji: "✍️" },
    { type: "image", label: "Photo", emoji: "📸" },
    { type: "poll",  label: "Poll",  emoji: "📊" },
    { type: "event", label: "Event", emoji: "📅" },
  ];

  const handleSubmit = () => {
    if (!content.trim()) return;
    addPost(communityId, { type, content, title: title.trim() || undefined, tags: [] });
    onClose();
  };

  return (
    <Modal visible animationType="slide" presentationStyle="pageSheet" onRequestClose={onClose}>
      <KeyboardAvoidingView style={{ flex: 1, backgroundColor: Colors.background }} behavior={Platform.OS === "ios" ? "padding" : "height"}>
        <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 20, paddingTop: insets.top + 16, paddingBottom: 16, borderBottomWidth: 1, borderBottomColor: Colors.border, backgroundColor: Colors.surface }}>
          <Pressable onPress={onClose}>
            <Text style={{ fontSize: 15, color: Colors.textSecondary, fontWeight: "600" }}>Cancel</Text>
          </Pressable>
          <Text style={{ fontSize: 16, fontWeight: "800", color: Colors.text }}>New Post</Text>
          <Pressable onPress={handleSubmit} disabled={!content.trim()} style={({ pressed }) => ({ opacity: content.trim() ? (pressed ? 0.7 : 1) : 0.4 })}>
            <LinearGradient colors={[Colors.primary, Colors.accent]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} style={{ paddingHorizontal: 18, paddingVertical: 8, borderRadius: 14 }}>
              <Text style={{ color: "#fff", fontWeight: "800", fontSize: 14 }}>Post</Text>
            </LinearGradient>
          </Pressable>
        </View>

        <ScrollView contentContainerStyle={{ padding: 20, gap: 16 }} keyboardShouldPersistTaps="handled">
          {/* Type selector */}
          <View style={{ flexDirection: "row", gap: 8 }}>
            {POST_TYPES.map((pt) => {
              const isActive = type === pt.type;
              return (
                <Pressable key={pt.type} onPress={() => setType(pt.type)} style={{ flex: 1 }}>
                  {isActive ? (
                    <LinearGradient colors={[Colors.primary, Colors.accent]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={{ borderRadius: 14, padding: 10, alignItems: "center", gap: 4 }}>
                      <Text style={{ fontSize: 18 }}>{pt.emoji}</Text>
                      <Text style={{ color: "#fff", fontSize: 11, fontWeight: "700" }}>{pt.label}</Text>
                    </LinearGradient>
                  ) : (
                    <View style={{ borderRadius: 14, padding: 10, alignItems: "center", gap: 4, backgroundColor: Colors.card, borderWidth: 1, borderColor: Colors.border }}>
                      <Text style={{ fontSize: 18 }}>{pt.emoji}</Text>
                      <Text style={{ color: Colors.textMuted, fontSize: 11, fontWeight: "600" }}>{pt.label}</Text>
                    </View>
                  )}
                </Pressable>
              );
            })}
          </View>

          {/* Title (for events) */}
          {(type === "event" || type === "poll") && (
            <TextInput value={title} onChangeText={setTitle} placeholder={type === "event" ? "Event name" : "Poll question"} placeholderTextColor={Colors.textMuted}
              style={{ backgroundColor: Colors.surface, borderRadius: 14, borderWidth: 1, borderColor: Colors.border, paddingHorizontal: 14, paddingVertical: 12, fontSize: 15, color: Colors.text }}
            />
          )}

          {/* Content */}
          <TextInput value={content} onChangeText={setContent}
            placeholder={type === "poll" ? "Add poll options (one per line)" : type === "event" ? "Event details, date, location…" : "Share something with the community…"}
            placeholderTextColor={Colors.textMuted} multiline numberOfLines={6} maxLength={1000}
            style={{ backgroundColor: Colors.surface, borderRadius: 16, borderWidth: 1, borderColor: Colors.border, padding: 14, fontSize: 15, color: Colors.text, lineHeight: 22, minHeight: 140, textAlignVertical: "top" }}
          />
          <Text style={{ fontSize: 11, color: Colors.textMuted, textAlign: "right" }}>{content.length}/1000</Text>
        </ScrollView>
      </KeyboardAvoidingView>
    </Modal>
  );
}

// ── Pending requests panel (owner/admin only) ─────────────────────────────────
function PendingRequestsPanel({ communityId }: { communityId: string }) {
  const community     = useCommunityStore((s) => s.communities.find((c) => c.id === communityId));
  const approveRequest = useCommunityStore((s) => s.approveRequest);
  const rejectRequest  = useCommunityStore((s) => s.rejectRequest);

  if (!community) return null;
  const requests = community.pendingRequests;

  if (requests.length === 0) {
    return (
      <View style={{ alignItems: "center", paddingVertical: 48, gap: 10 }}>
        <Text style={{ fontSize: 36 }}>✅</Text>
        <Text style={{ fontSize: 15, fontWeight: "700", color: Colors.text }}>All caught up</Text>
        <Text style={{ fontSize: 13, color: Colors.textMuted }}>No pending join requests</Text>
      </View>
    );
  }

  return (
    <View style={{ padding: 16, gap: 10 }}>
      <Text style={{ fontSize: 14, fontWeight: "700", color: Colors.textSecondary, letterSpacing: 0.3 }}>
        PENDING REQUESTS ({requests.length})
      </Text>
      {requests.map((req) => (
        <View
          key={req.id}
          style={{
            backgroundColor: Colors.surface, borderRadius: 18,
            padding: 16, gap: 12,
            borderWidth: 1, borderColor: Colors.border,
            shadowColor: "#000", shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.05, shadowRadius: 6, elevation: 2,
          }}
        >
          {/* User info */}
          <View style={{ flexDirection: "row", alignItems: "center", gap: 12 }}>
            <LinearGradient
              colors={req.gradient}
              start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
              style={{ width: 44, height: 44, borderRadius: 22, alignItems: "center", justifyContent: "center" }}
            >
              <Text style={{ fontSize: 22 }}>{req.avatarEmoji}</Text>
            </LinearGradient>
            <View style={{ flex: 1 }}>
              <Text style={{ fontSize: 14, fontWeight: "700", color: Colors.text }}>{req.userName}</Text>
              <Text style={{ fontSize: 12, color: Colors.textMuted }}>{timeAgo(req.requestedAt)}</Text>
            </View>
          </View>

          {/* Message */}
          {req.message.trim() !== "" && (
            <View style={{ backgroundColor: Colors.card, borderRadius: 12, padding: 12, borderLeftWidth: 3, borderLeftColor: Colors.violet }}>
              <Text style={{ fontSize: 13, color: Colors.textSecondary, lineHeight: 19, fontStyle: "italic" }}>
                "{req.message}"
              </Text>
            </View>
          )}

          {/* Actions */}
          <View style={{ flexDirection: "row", gap: 10 }}>
            <Pressable
              onPress={() => rejectRequest(communityId, req.id)}
              style={({ pressed }) => ({
                flex: 1, paddingVertical: 12, borderRadius: 14, alignItems: "center",
                backgroundColor: Colors.card, borderWidth: 1.5, borderColor: Colors.border,
                opacity: pressed ? 0.7 : 1,
              })}
            >
              <Text style={{ fontSize: 14, fontWeight: "700", color: Colors.textMuted }}>✕ Decline</Text>
            </Pressable>
            <Pressable
              onPress={() => approveRequest(communityId, req.id)}
              style={({ pressed }) => ({
                flex: 2, overflow: "hidden", borderRadius: 14,
                opacity: pressed ? 0.85 : 1,
              })}
            >
              <LinearGradient
                colors={[Colors.primary, Colors.accent]}
                start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
                style={{ paddingVertical: 12, alignItems: "center" }}
              >
                <Text style={{ fontSize: 14, fontWeight: "800", color: "#fff" }}>✓ Approve</Text>
              </LinearGradient>
            </Pressable>
          </View>
        </View>
      ))}
    </View>
  );
}

// ── Main detail screen ─────────────────────────────────────────────────────────
export function CommunityDetailScreen() {
  const insets             = useSafeAreaInsets();
  const community          = useActiveCommunity();
  const setActiveCommunity = useCommunityStore((s) => s.setActiveCommunity);
  const joinCommunity      = useCommunityStore((s) => s.joinCommunity);
  const leaveCommunity     = useCommunityStore((s) => s.leaveCommunity);
  const cancelJoinRequest  = useCommunityStore((s) => s.cancelJoinRequest);
  const setShowJoinRequest = useCommunityStore((s) => s.setShowJoinRequest);

  const [activeTab, setActiveTab]     = useState<DetailTab>("feed");
  const [showCreatePost, setCreatePost] = useState(false);

  const feed = useCommunityFeed(community?.id ?? "");

  if (!community) return null;

  const isMember  = community.myStatus === "member" || community.myStatus === "owner" || community.myStatus === "admin";
  const isOwner   = community.myStatus === "owner" || community.myStatus === "admin";
  const isPending = community.myStatus === "pending";

  const TABS: { id: DetailTab; label: string }[] = [
    { id: "feed",     label: "Feed" },
    { id: "members",  label: `Members (${fmtNum(community.memberCount)})` },
    { id: "about",    label: "About" },
    ...(isOwner ? [{ id: "requests" as DetailTab, label: `Requests${community.pendingRequests.length > 0 ? ` (${community.pendingRequests.length})` : ""}` }] : []),
  ];

  return (
    <View style={{ flex: 1, backgroundColor: Colors.background }}>
      {/* Cover */}
      <LinearGradient
        colors={community.coverGradient}
        start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
        style={{ height: 160 }}
      >
        {/* Back button */}
        <Pressable
          onPress={() => setActiveCommunity(null)}
          style={({ pressed }) => ({
            position: "absolute", top: insets.top + 10, left: 16,
            width: 36, height: 36, borderRadius: 18,
            backgroundColor: "rgba(0,0,0,0.35)",
            alignItems: "center", justifyContent: "center",
            opacity: pressed ? 0.7 : 1,
          })}
        >
          <Text style={{ color: "#fff", fontSize: 18 }}>←</Text>
        </Pressable>

        {/* Privacy + verified */}
        <View style={{ position: "absolute", top: insets.top + 10, right: 16, flexDirection: "row", gap: 8 }}>
          {community.isVerified && (
            <View style={{ backgroundColor: "#3b82f6", paddingHorizontal: 10, paddingVertical: 4, borderRadius: 10, flexDirection: "row", alignItems: "center", gap: 4 }}>
              <Text style={{ color: "#fff", fontSize: 11 }}>✓</Text>
              <Text style={{ color: "#fff", fontSize: 11, fontWeight: "700" }}>Verified</Text>
            </View>
          )}
          <View style={{ backgroundColor: "rgba(0,0,0,0.35)", paddingHorizontal: 10, paddingVertical: 4, borderRadius: 10 }}>
            <Text style={{ color: "#fff", fontSize: 11, fontWeight: "700" }}>
              {community.privacy === "private" ? "🔒 Private" : "🌐 Public"}
            </Text>
          </View>
        </View>

        <Text style={{ position: "absolute", bottom: 14, left: 16, fontSize: 50 }}>{community.coverEmoji}</Text>
      </LinearGradient>

      {/* Community info header */}
      <View style={{ backgroundColor: Colors.surface, paddingHorizontal: 16, paddingTop: 14, paddingBottom: 14, borderBottomWidth: 1, borderBottomColor: Colors.border, gap: 8 }}>
        <View style={{ flexDirection: "row", alignItems: "flex-start", justifyContent: "space-between" }}>
          <View style={{ flex: 1, gap: 4 }}>
            <Text style={{ fontSize: 20, fontWeight: "900", color: Colors.text, letterSpacing: -0.3 }}>{community.name}</Text>
            <Text style={{ fontSize: 13, color: Colors.textMuted }}>
              {fmtNum(community.memberCount)} members · {fmtNum(community.postCount)} posts · {community.category}
            </Text>
          </View>

          {/* Join / Leave / Pending button */}
          {isMember ? (
            community.myStatus !== "owner" && (
              <Pressable
                onPress={() => leaveCommunity(community.id)}
                style={({ pressed }) => ({
                  paddingHorizontal: 16, paddingVertical: 9, borderRadius: 14,
                  borderWidth: 1.5, borderColor: Colors.border, backgroundColor: Colors.card,
                  opacity: pressed ? 0.7 : 1,
                })}
              >
                <Text style={{ fontSize: 13, fontWeight: "700", color: Colors.textMuted }}>Leave</Text>
              </Pressable>
            )
          ) : isPending ? (
            <Pressable
              onPress={() => cancelJoinRequest(community.id)}
              style={({ pressed }) => ({
                paddingHorizontal: 16, paddingVertical: 9, borderRadius: 14,
                borderWidth: 1.5, borderColor: Colors.border, backgroundColor: Colors.card,
                opacity: pressed ? 0.7 : 1,
              })}
            >
              <Text style={{ fontSize: 13, fontWeight: "700", color: Colors.textMuted }}>⏳ Cancel Request</Text>
            </Pressable>
          ) : (
            <Pressable
              onPress={() => community.privacy === "public" ? joinCommunity(community.id) : setShowJoinRequest(community.id)}
              style={({ pressed }) => ({ opacity: pressed ? 0.85 : 1, transform: [{ scale: pressed ? 0.96 : 1 }] })}
            >
              <LinearGradient colors={[Colors.primary, Colors.accent]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} style={{ paddingHorizontal: 18, paddingVertical: 9, borderRadius: 14 }}>
                <Text style={{ color: "#fff", fontSize: 13, fontWeight: "800" }}>
                  {community.privacy === "private" ? "🔒 Request" : "Join →"}
                </Text>
              </LinearGradient>
            </Pressable>
          )}
        </View>

        <Text style={{ fontSize: 13, color: Colors.textSecondary, lineHeight: 19 }} numberOfLines={2}>
          {community.description}
        </Text>
      </View>

      {/* Tab bar */}
      <View style={{ flexDirection: "row", backgroundColor: Colors.surface, borderBottomWidth: 1, borderBottomColor: Colors.border }}>
        {TABS.map((tab) => (
          <Pressable
            key={tab.id}
            onPress={() => setActiveTab(tab.id)}
            style={{ flex: 1, paddingVertical: 12, alignItems: "center", borderBottomWidth: 2.5, borderBottomColor: activeTab === tab.id ? Colors.primary : "transparent" }}
          >
            <Text style={{ fontSize: 12, fontWeight: activeTab === tab.id ? "800" : "600", color: activeTab === tab.id ? Colors.primary : Colors.textMuted }}>
              {tab.label}
            </Text>
          </Pressable>
        ))}
      </View>

      {/* Content */}
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 100 }}>
        {/* Feed tab */}
        {activeTab === "feed" && (
          <View style={{ padding: 16, gap: 4 }}>
            {!isMember && (
              <View style={{ flexDirection: "row", alignItems: "center", gap: 10, padding: 14, borderRadius: 14, backgroundColor: Colors.card, borderWidth: 1, borderColor: Colors.border, marginBottom: 12 }}>
                <Text style={{ fontSize: 18 }}>{community.privacy === "private" ? "🔒" : "ℹ️"}</Text>
                <Text style={{ flex: 1, fontSize: 13, color: Colors.textSecondary, lineHeight: 18 }}>
                  {community.privacy === "private" ? "Join to see posts in this private community." : "Join this community to post and interact."}
                </Text>
              </View>
            )}
            {feed.length === 0 ? (
              <View style={{ alignItems: "center", paddingVertical: 48, gap: 10 }}>
                <Text style={{ fontSize: 36 }}>📝</Text>
                <Text style={{ fontSize: 15, fontWeight: "700", color: Colors.text }}>No posts yet</Text>
                {isMember && <Text style={{ fontSize: 13, color: Colors.textMuted }}>Be the first to post!</Text>}
              </View>
            ) : (
              feed.map((post) => (
                <CommunityPostCard key={post.id} post={post} communityId={community.id} />
              ))
            )}
          </View>
        )}

        {/* Members tab */}
        {activeTab === "members" && (
          <View style={{ padding: 16, gap: 10 }}>
            {community.members.map((member) => (
              <View key={member.id} style={{ flexDirection: "row", alignItems: "center", gap: 12, padding: 14, borderRadius: 16, backgroundColor: Colors.surface, borderWidth: 1, borderColor: Colors.border }}>
                <LinearGradient colors={member.gradient} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={{ width: 44, height: 44, borderRadius: 22, alignItems: "center", justifyContent: "center" }}>
                  <Text style={{ fontSize: 22 }}>{member.avatarEmoji}</Text>
                </LinearGradient>
                <View style={{ flex: 1, gap: 3 }}>
                  <Text style={{ fontSize: 14, fontWeight: "700", color: Colors.text }}>{member.name}</Text>
                  <Text style={{ fontSize: 12, color: Colors.textMuted }}>Joined {timeAgo(member.joinedAt)}</Text>
                </View>
                {(member.role === "owner" || member.role === "admin") && (
                  <View style={{
                    paddingHorizontal: 10, paddingVertical: 4, borderRadius: 10,
                    backgroundColor: member.role === "owner" ? Colors.gold + "22" : Colors.violet + "18",
                    borderWidth: 1,
                    borderColor: member.role === "owner" ? Colors.gold + "44" : Colors.violet + "33",
                  }}>
                    <Text style={{ fontSize: 11, fontWeight: "700", color: member.role === "owner" ? Colors.gold : Colors.violet }}>
                      {member.role === "owner" ? "Owner" : "Admin"}
                    </Text>
                  </View>
                )}
              </View>
            ))}
          </View>
        )}

        {/* About tab */}
        {activeTab === "about" && (
          <View style={{ padding: 16, gap: 16 }}>
            <View style={{ backgroundColor: Colors.surface, borderRadius: 18, padding: 16, gap: 12, borderWidth: 1, borderColor: Colors.border }}>
              <Text style={{ fontSize: 15, fontWeight: "800", color: Colors.text }}>About</Text>
              <Text style={{ fontSize: 14, color: Colors.textSecondary, lineHeight: 21 }}>{community.description}</Text>
              <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 6, marginTop: 4 }}>
                {community.tags.map((tag) => (
                  <View key={tag} style={{ paddingHorizontal: 10, paddingVertical: 4, borderRadius: 10, backgroundColor: Colors.card, borderWidth: 1, borderColor: Colors.border }}>
                    <Text style={{ fontSize: 12, color: Colors.textSecondary, fontWeight: "600" }}>{tag}</Text>
                  </View>
                ))}
              </View>
            </View>

            {community.rules.length > 0 && (
              <View style={{ backgroundColor: Colors.surface, borderRadius: 18, overflow: "hidden", borderWidth: 1, borderColor: Colors.border }}>
                <View style={{ padding: 16, borderBottomWidth: 1, borderBottomColor: Colors.border }}>
                  <Text style={{ fontSize: 15, fontWeight: "800", color: Colors.text }}>Community Rules</Text>
                </View>
                {community.rules.map((rule, i) => (
                  <View key={rule.id} style={{ padding: 14, borderBottomWidth: i < community.rules.length - 1 ? 1 : 0, borderBottomColor: Colors.border, gap: 4 }}>
                    <Text style={{ fontSize: 14, fontWeight: "700", color: Colors.text }}>{i + 1}. {rule.title}</Text>
                    {rule.description && <Text style={{ fontSize: 13, color: Colors.textMuted, lineHeight: 18 }}>{rule.description}</Text>}
                  </View>
                ))}
              </View>
            )}
          </View>
        )}

        {/* Requests tab (owner/admin only) */}
        {activeTab === "requests" && isOwner && (
          <PendingRequestsPanel communityId={community.id} />
        )}
      </ScrollView>

      {/* Post FAB (members only) */}
      {isMember && activeTab === "feed" && (
        <View style={{ position: "absolute", bottom: insets.bottom + 20, right: 20 }}>
          <Pressable
            onPress={() => setCreatePost(true)}
            style={({ pressed }) => ({ opacity: pressed ? 0.85 : 1, transform: [{ scale: pressed ? 0.93 : 1 }] })}
          >
            <LinearGradient
              colors={[Colors.primary, Colors.accent]}
              start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
              style={{ width: 56, height: 56, borderRadius: 28, alignItems: "center", justifyContent: "center", shadowColor: Colors.primary, shadowOffset: { width: 0, height: 6 }, shadowOpacity: 0.4, shadowRadius: 12, elevation: 8 }}
            >
              <Text style={{ color: "#fff", fontSize: 26, lineHeight: 30 }}>+</Text>
            </LinearGradient>
          </Pressable>
        </View>
      )}

      {showCreatePost && (
        <CreatePostSheet communityId={community.id} onClose={() => setCreatePost(false)} />
      )}
    </View>
  );
}
