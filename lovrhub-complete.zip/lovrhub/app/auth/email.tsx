import { useState } from "react";
import { View, Text, KeyboardAvoidingView, Platform, ScrollView, Pressable } from "react-native";
import { useRouter } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Colors } from "@constants/theme";
import { useAuthStore } from "@/store/authStore";
import { AuthInput, PrimaryButton, GhostButton, BackButton, StepHeader } from "@components/auth/AuthUI";

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const SUFFIXES  = ["@gmail.com", "@yahoo.co.in", "@outlook.com"];

function GoogleIcon() {
  return (
    <View style={{ width: 24, height: 24, borderRadius: 12, overflow: "hidden", borderWidth: 1, borderColor: "#E0E0E0", alignItems: "center", justifyContent: "center", backgroundColor: "#fff" }}>
      <Text style={{ fontSize: 14, fontWeight: "900", color: "#4285F4" }}>G</Text>
    </View>
  );
}

export default function EmailScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const updateProfile = useAuthStore((s) => s.updateProfile);

  const [email, setEmail]   = useState("");
  const [error, setError]   = useState("");
  const [loading, setLoading] = useState(false);

  const handleContinue = async () => {
    if (!EMAIL_RE.test(email)) { setError("Enter a valid email address"); return; }
    setError("");
    setLoading(true);
    await new Promise((r) => setTimeout(r, 700));
    setLoading(false);
    updateProfile({ email });
    router.push("/auth/setup");
  };

  return (
    <KeyboardAvoidingView
      style={{ flex: 1, backgroundColor: Colors.background }}
      behavior={Platform.OS === "ios" ? "padding" : "height"}
    >
      <View style={{ paddingTop: insets.top }}>
        <BackButton onPress={() => router.back()} />
      </View>

      <ScrollView
        contentContainerStyle={{ flexGrow: 1, paddingBottom: insets.bottom + 32 }}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        <StepHeader emoji="✉️" title={"What's your\nemail?"} subtitle="For account recovery and updates. No spam, ever." />

        <View style={{ paddingHorizontal: 24, gap: 16 }}>
          <AuthInput
            label="Email Address"
            placeholder="you@example.com"
            value={email}
            onChangeText={(t) => { setEmail(t.trim().toLowerCase()); if (error) setError(""); }}
            keyboardType="email-address"
            autoCapitalize="none"
            autoCorrect={false}
            error={error}
          />

          {/* Quick-fill suffixes */}
          <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8 }}>
            {SUFFIXES.map((suffix) => (
              <Pressable
                key={suffix}
                onPress={() => { const base = email.split("@")[0]; setEmail(base + suffix); setError(""); }}
                style={({ pressed }) => ({
                  paddingHorizontal: 12, paddingVertical: 7, borderRadius: 12,
                  backgroundColor: Colors.card, borderWidth: 1, borderColor: Colors.border,
                  opacity: pressed ? 0.7 : 1,
                })}
              >
                <Text style={{ fontSize: 12, color: Colors.textSecondary, fontWeight: "600" }}>{suffix}</Text>
              </Pressable>
            ))}
          </View>

          {/* Google OAuth */}
          <View>
            <View style={{ flexDirection: "row", alignItems: "center", gap: 12, marginBottom: 12 }}>
              <View style={{ flex: 1, height: 1, backgroundColor: Colors.border }} />
              <Text style={{ color: Colors.textMuted, fontSize: 13 }}>or sign in with</Text>
              <View style={{ flex: 1, height: 1, backgroundColor: Colors.border }} />
            </View>

            <Pressable
              style={({ pressed }) => ({
                borderRadius: 18, paddingVertical: 17,
                flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 12,
                borderWidth: 1.5, borderColor: Colors.border, backgroundColor: Colors.surface,
                opacity: pressed ? 0.7 : 1,
                shadowColor: "#000", shadowOffset: { width: 0, height: 2 },
                shadowOpacity: 0.05, shadowRadius: 6, elevation: 2,
              })}
            >
              <GoogleIcon />
              <View>
                <Text style={{ color: Colors.text, fontSize: 15, fontWeight: "700" }}>Continue with Google</Text>
                <Text style={{ color: Colors.textMuted, fontSize: 11, marginTop: 1 }}>Quick sign-in with your Google account</Text>
              </View>
            </Pressable>
          </View>

          <PrimaryButton label="Continue" onPress={handleContinue} loading={loading} disabled={email.length < 5} icon="→" />
          <GhostButton label="Skip for now" onPress={() => router.push("/auth/setup")} />
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}
