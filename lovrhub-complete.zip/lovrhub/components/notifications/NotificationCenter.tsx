import { useState, useMemo } from "react";
import {
  View, Text, Modal, Pressable, ScrollView,
  SectionList, Switch, Dimensions,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Colors } from "@constants/theme";
import { useNotificationStore } from "@/store/notificationStore";
import {
  useFilteredNotifications,
  useGroupUnreadCounts,
  useTotalUnread,
  groupByDate,
  GROUP_CONFIG,
  NOTIF_CONFIG,
} from "@/hooks/useNotifications";
import { NotificationRow } from "@components/notifications/NotificationRow";
import type { NotificationGroup } from "@/types/notification";

const GROUPS: (NotificationGroup | "all")[] = [
  "all", "social", "messages", "activity", "communities", "system",
];

// ── Group tab pill ─────────────────────────────────────────────────────────────
function GroupPill({
  group,
  active,
  unread,
  onPress,
}: {
  group: NotificationGroup | "all";
  active: boolean;
  unread: number;
  onPress: () => void;
}) {
  const cfg = GROUP_CONFIG[group];
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => ({ opacity: pressed ? 0.75 : 1 })}
    >
      {active ? (
        <LinearGradient
          colors={[cfg.color, cfg.color + "cc"]}
          start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
          style={{
            flexDirection: "row", alignItems: "center", gap: 5,
            paddingHorizontal: 14, paddingVertical: 8, borderRadius: 20,
          }}
        >
          <Text style={{ fontSize: 13 }}>{cfg.emoji}</Text>
          <Text style={{ color: "#fff", fontSize: 13, fontWeight: "700" }}>{cfg.label}</Text>
          {unread > 0 && (
            <View style={{ backgroundColor: "rgba(255,255,255,0.3)", paddingHorizontal: 6, paddingVertical: 1, borderRadius: 8 }}>
              <Text style={{ color: "#fff", fontSize: 10, fontWeight: "800" }}>{unread}</Text>
            </View>
          )}
        </LinearGradient>
      ) : (
        <View
          style={{
            flexDirection: "row", alignItems: "center", gap: 5,
            paddingHorizontal: 14, paddingVertical: 8, borderRadius: 20,
            backgroundColor: Colors.card, borderWidth: 1, borderColor: Colors.border,
          }}
        >
          <Text style={{ fontSize: 13 }}>{cfg.emoji}</Text>
          <Text style={{ color: Colors.textSecondary, fontSize: 13, fontWeight: "600" }}>{cfg.label}</Text>
          {unread > 0 && (
            <View style={{ backgroundColor: Colors.primary, paddingHorizontal: 6, paddingVertical: 1, borderRadius: 8 }}>
              <Text style={{ color: "#fff", fontSize: 10, fontWeight: "800" }}>{unread}</Text>
            </View>
          )}
        </View>
      )}
    </Pressable>
  );
}

// ── Date section header ────────────────────────────────────────────────────────
function SectionHeader({ title }: { title: string }) {
  return (
    <View
      style={{
        paddingHorizontal: 16,
        paddingTop: 16,
        paddingBottom: 6,
        backgroundColor: Colors.background,
      }}
    >
      <Text style={{ fontSize: 12, fontWeight: "800", color: Colors.textMuted, letterSpacing: 0.6 }}>
        {title.toUpperCase()}
      </Text>
    </View>
  );
}

// ── Empty state ────────────────────────────────────────────────────────────────
function EmptyNotifications({ group }: { group: string }) {
  return (
    <View style={{ alignItems: "center", paddingVertical: 64, gap: 14, paddingHorizontal: 32 }}>
      <View
        style={{
          width: 80, height: 80, borderRadius: 40,
          backgroundColor: Colors.card,
          borderWidth: 2, borderColor: Colors.border, borderStyle: "dashed",
          alignItems: "center", justifyContent: "center",
        }}
      >
        <Text style={{ fontSize: 36 }}>🔕</Text>
      </View>
      <Text style={{ fontSize: 17, fontWeight: "800", color: Colors.text, textAlign: "center" }}>
        {group === "all" ? "You're all caught up!" : `No ${group} notifications`}
      </Text>
      <Text style={{ fontSize: 14, color: Colors.textMuted, textAlign: "center", lineHeight: 21 }}>
        {group === "all"
          ? "New notifications will appear here when someone interacts with you."
          : `When you receive ${group} notifications they'll show up here.`}
      </Text>
    </View>
  );
}

// ── Preferences sheet (shown as second tab inside the center) ──────────────────
function PreferencesPanel() {
  const prefs           = useNotificationStore((s) => s.preferences);
  const updatePref      = useNotificationStore((s) => s.updatePreference);

  const SECTIONS: { title: string; items: { key: keyof typeof prefs; label: string; subtitle?: string; emoji: string }[] }[] = [
    {
      title: "Activity",
      items: [
        { key: "follows",      label: "Follows",        subtitle: "When someone follows you",         emoji: "👤" },
        { key: "likes",        label: "Likes",          subtitle: "Likes on your posts and profile",   emoji: "❤️" },
        { key: "comments",     label: "Comments",       subtitle: "Comments and mentions",              emoji: "💬" },
        { key: "profileViews", label: "Profile views",  subtitle: "When someone views your profile",    emoji: "👁"  },
      ],
    },
    {
      title: "Dating",
      items: [
        { key: "messages",  label: "Messages",  subtitle: "New direct messages",                  emoji: "💌" },
        { key: "matches",   label: "Matches",   subtitle: "New mutual matches",                   emoji: "💕" },
      ],
    },
    {
      title: "Communities",
      items: [
        { key: "communityPosts", label: "New posts",     subtitle: "Posts in communities you've joined", emoji: "📝" },
        { key: "joinRequests",   label: "Join requests", subtitle: "Requests to join your communities",  emoji: "🔔" },
      ],
    },
    {
      title: "Other",
      items: [
        { key: "systemUpdates", label: "System updates", subtitle: "Product news and announcements", emoji: "📣" },
        { key: "emailDigest",   label: "Email digest",   subtitle: "Weekly summary via email",       emoji: "📧" },
      ],
    },
  ];

  return (
    <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 48 }}>
      {/* Push toggle */}
      <View style={{ margin: 16, borderRadius: 18, overflow: "hidden", borderWidth: 1, borderColor: Colors.border }}>
        <LinearGradient
          colors={prefs.pushEnabled ? [Colors.primary + "18", Colors.accent + "0a"] : [Colors.card, Colors.background]}
          start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
          style={{ padding: 16, gap: 12 }}
        >
          <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between" }}>
            <View style={{ flexDirection: "row", alignItems: "center", gap: 12 }}>
              <View
                style={{
                  width: 44, height: 44, borderRadius: 14,
                  backgroundColor: prefs.pushEnabled ? Colors.primary + "22" : Colors.card,
                  alignItems: "center", justifyContent: "center",
                  borderWidth: 1, borderColor: prefs.pushEnabled ? Colors.primary + "44" : Colors.border,
                }}
              >
                <Text style={{ fontSize: 22 }}>🔔</Text>
              </View>
              <View>
                <Text style={{ fontSize: 15, fontWeight: "800", color: Colors.text }}>Push notifications</Text>
                <Text style={{ fontSize: 12, color: Colors.textMuted, marginTop: 2 }}>
                  {prefs.pushEnabled ? "Enabled — you'll get notified" : "Disabled — turn on to stay updated"}
                </Text>
              </View>
            </View>
            <Switch
              value={prefs.pushEnabled}
              onValueChange={(v) => updatePref("pushEnabled", v)}
              trackColor={{ false: Colors.border, true: Colors.primary }}
              thumbColor="#fff"
            />
          </View>
        </LinearGradient>
      </View>

      {/* Quiet hours */}
      <View style={{ marginHorizontal: 16, marginBottom: 16, borderRadius: 18, backgroundColor: Colors.surface, borderWidth: 1, borderColor: Colors.border, overflow: "hidden" }}>
        <View style={{ padding: 16, borderBottomWidth: prefs.quietHoursEnabled ? 1 : 0, borderBottomColor: Colors.border }}>
          <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between" }}>
            <View style={{ flexDirection: "row", alignItems: "center", gap: 12 }}>
              <View style={{ width: 44, height: 44, borderRadius: 14, backgroundColor: Colors.card, alignItems: "center", justifyContent: "center", borderWidth: 1, borderColor: Colors.border }}>
                <Text style={{ fontSize: 22 }}>🌙</Text>
              </View>
              <View>
                <Text style={{ fontSize: 15, fontWeight: "700", color: Colors.text }}>Quiet hours</Text>
                <Text style={{ fontSize: 12, color: Colors.textMuted, marginTop: 2 }}>
                  {prefs.quietHoursEnabled ? `${prefs.quietHoursStart} – ${prefs.quietHoursEnd}` : "Pause notifications at night"}
                </Text>
              </View>
            </View>
            <Switch
              value={prefs.quietHoursEnabled}
              onValueChange={(v) => updatePref("quietHoursEnabled", v)}
              trackColor={{ false: Colors.border, true: Colors.violet }}
              thumbColor="#fff"
            />
          </View>
        </View>
        {prefs.quietHoursEnabled && (
          <View style={{ flexDirection: "row", padding: 14, gap: 10 }}>
            {(["quietHoursStart", "quietHoursEnd"] as const).map((key, i) => (
              <View key={key} style={{ flex: 1, backgroundColor: Colors.card, borderRadius: 12, padding: 12, alignItems: "center", gap: 3, borderWidth: 1, borderColor: Colors.border }}>
                <Text style={{ fontSize: 11, color: Colors.textMuted, fontWeight: "600" }}>{i === 0 ? "FROM" : "TO"}</Text>
                <Text style={{ fontSize: 18, fontWeight: "800", color: Colors.text }}>{prefs[key]}</Text>
              </View>
            ))}
          </View>
        )}
      </View>

      {/* Preference sections */}
      {SECTIONS.map((section) => (
        <View key={section.title} style={{ marginHorizontal: 16, marginBottom: 16, borderRadius: 18, backgroundColor: Colors.surface, borderWidth: 1, borderColor: Colors.border, overflow: "hidden" }}>
          <View style={{ paddingHorizontal: 16, paddingTop: 14, paddingBottom: 8 }}>
            <Text style={{ fontSize: 12, fontWeight: "800", color: Colors.textMuted, letterSpacing: 0.6 }}>{section.title.toUpperCase()}</Text>
          </View>
          {section.items.map((item, idx) => (
            <View
              key={item.key}
              style={{
                flexDirection: "row", alignItems: "center", paddingHorizontal: 16, paddingVertical: 12,
                borderTopWidth: idx > 0 ? 1 : 0, borderTopColor: Colors.border, gap: 12,
              }}
            >
              <View style={{ width: 36, height: 36, borderRadius: 10, backgroundColor: Colors.card, alignItems: "center", justifyContent: "center", borderWidth: 1, borderColor: Colors.border }}>
                <Text style={{ fontSize: 16 }}>{item.emoji}</Text>
              </View>
              <View style={{ flex: 1, gap: 2 }}>
                <Text style={{ fontSize: 14, fontWeight: "700", color: Colors.text }}>{item.label}</Text>
                {item.subtitle && <Text style={{ fontSize: 12, color: Colors.textMuted }}>{item.subtitle}</Text>}
              </View>
              <Switch
                value={Boolean(prefs[item.key])}
                onValueChange={(v) => updatePref(item.key, v)}
                trackColor={{ false: Colors.border, true: Colors.primary }}
                thumbColor="#fff"
              />
            </View>
          ))}
        </View>
      ))}
    </ScrollView>
  );
}

// ── Main NotificationCenter ────────────────────────────────────────────────────
export function NotificationCenter() {
  const insets          = useSafeAreaInsets();
  const visible         = useNotificationStore((s) => s.panelVisible);
  const setPanelVisible = useNotificationStore((s) => s.setPanelVisible);
  const activeGroup     = useNotificationStore((s) => s.activeGroup);
  const setActiveGroup  = useNotificationStore((s) => s.setActiveGroup);
  const markAllRead     = useNotificationStore((s) => s.markAllRead);
  const markGroupRead   = useNotificationStore((s) => s.markGroupRead);
  const clearAll        = useNotificationStore((s) => s.clearAll);

  const filteredNotifs = useFilteredNotifications();
  const groupCounts    = useGroupUnreadCounts();
  const totalUnread    = useTotalUnread();
  const [innerTab, setInnerTab] = useState<"notifications" | "preferences">("notifications");

  const sections = useMemo(() => groupByDate(filteredNotifs), [filteredNotifs]);

  return (
    <Modal
      visible={visible}
      animationType="slide"
      presentationStyle="pageSheet"
      onRequestClose={() => setPanelVisible(false)}
    >
      <View style={{ flex: 1, backgroundColor: Colors.background }}>
        {/* Header */}
        <View
          style={{
            backgroundColor: Colors.surface,
            paddingTop: insets.top + 12,
            borderBottomWidth: 1,
            borderBottomColor: Colors.border,
          }}
        >
          {/* Title row */}
          <View
            style={{
              flexDirection: "row", alignItems: "center", justifyContent: "space-between",
              paddingHorizontal: 20, paddingBottom: 12,
            }}
          >
            <View>
              <Text style={{ fontSize: 22, fontWeight: "900", color: Colors.text, letterSpacing: -0.5 }}>
                Notifications
              </Text>
              {totalUnread > 0 && (
                <Text style={{ fontSize: 12, color: Colors.primary, fontWeight: "700", marginTop: 2 }}>
                  {totalUnread} unread
                </Text>
              )}
            </View>

            <View style={{ flexDirection: "row", alignItems: "center", gap: 8 }}>
              {/* Mark all read */}
              {totalUnread > 0 && (
                <Pressable
                  onPress={() => markAllRead()}
                  style={({ pressed }) => ({
                    paddingHorizontal: 12, paddingVertical: 7, borderRadius: 12,
                    backgroundColor: Colors.card, borderWidth: 1, borderColor: Colors.border,
                    opacity: pressed ? 0.7 : 1,
                  })}
                >
                  <Text style={{ fontSize: 12, color: Colors.primary, fontWeight: "700" }}>
                    Mark all read
                  </Text>
                </Pressable>
              )}

              {/* Close */}
              <Pressable
                onPress={() => setPanelVisible(false)}
                style={({ pressed }) => ({
                  width: 32, height: 32, borderRadius: 16,
                  backgroundColor: Colors.card,
                  alignItems: "center", justifyContent: "center",
                  opacity: pressed ? 0.6 : 1,
                })}
              >
                <Text style={{ fontSize: 16, color: Colors.text }}>✕</Text>
              </Pressable>
            </View>
          </View>

          {/* Inner tabs: Notifications | Preferences */}
          <View style={{ flexDirection: "row", paddingHorizontal: 20, paddingBottom: 12, gap: 8 }}>
            {(["notifications", "preferences"] as const).map((t) => {
              const isActive = innerTab === t;
              return (
                <Pressable key={t} onPress={() => setInnerTab(t)}>
                  {isActive ? (
                    <LinearGradient
                      colors={[Colors.primary, Colors.accent]}
                      start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
                      style={{ paddingHorizontal: 16, paddingVertical: 8, borderRadius: 18 }}
                    >
                      <Text style={{ color: "#fff", fontSize: 13, fontWeight: "800" }}>
                        {t === "notifications" ? "🔔 Notifications" : "⚙ Preferences"}
                      </Text>
                    </LinearGradient>
                  ) : (
                    <View style={{ paddingHorizontal: 16, paddingVertical: 8, borderRadius: 18, backgroundColor: Colors.card, borderWidth: 1, borderColor: Colors.border }}>
                      <Text style={{ color: Colors.textMuted, fontSize: 13, fontWeight: "600" }}>
                        {t === "notifications" ? "🔔 Notifications" : "⚙ Preferences"}
                      </Text>
                    </View>
                  )}
                </Pressable>
              );
            })}
          </View>

          {/* Group filter pills — only on notifications tab */}
          {innerTab === "notifications" && (
            <ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 12, gap: 8 }}
            >
              {GROUPS.map((group) => (
                <GroupPill
                  key={group}
                  group={group}
                  active={activeGroup === group}
                  unread={groupCounts[group]}
                  onPress={() => setActiveGroup(group)}
                />
              ))}
            </ScrollView>
          )}
        </View>

        {/* Content */}
        {innerTab === "preferences" ? (
          <PreferencesPanel />
        ) : (
          <>
            {sections.length === 0 ? (
              <EmptyNotifications group={activeGroup} />
            ) : (
              <SectionList
                sections={sections.map((s) => ({ title: s.label, data: s.items }))}
                keyExtractor={(item) => item.id}
                renderItem={({ item }) => <NotificationRow notif={item} />}
                renderSectionHeader={({ section }) => <SectionHeader title={section.title} />}
                showsVerticalScrollIndicator={false}
                contentContainerStyle={{ paddingBottom: insets.bottom + 32 }}
                stickySectionHeadersEnabled
                ListFooterComponent={
                  filteredNotifs.length > 0 ? (
                    <View style={{ padding: 20, alignItems: "center", gap: 12 }}>
                      <Pressable
                        onPress={() => markGroupRead(activeGroup)}
                        style={({ pressed }) => ({
                          paddingHorizontal: 20, paddingVertical: 10, borderRadius: 14,
                          backgroundColor: Colors.card, borderWidth: 1, borderColor: Colors.border,
                          opacity: pressed ? 0.7 : 1,
                        })}
                      >
                        <Text style={{ fontSize: 13, color: Colors.textSecondary, fontWeight: "700" }}>
                          Mark {activeGroup === "all" ? "all" : `${activeGroup}`} as read
                        </Text>
                      </Pressable>
                      <Pressable
                        onPress={clearAll}
                        style={({ pressed }) => ({ opacity: pressed ? 0.7 : 1 })}
                      >
                        <Text style={{ fontSize: 12, color: Colors.textMuted }}>Clear all notifications</Text>
                      </Pressable>
                    </View>
                  ) : null
                }
              />
            )}
          </>
        )}
      </View>
    </Modal>
  );
}

// ── Bell button — used in TopNavBar ────────────────────────────────────────────
export function NotificationBell() {
  const setPanelVisible = useNotificationStore((s) => s.setPanelVisible);
  const totalUnread     = useTotalUnread();

  return (
    <Pressable
      onPress={() => setPanelVisible(true)}
      hitSlop={8}
      style={({ pressed }) => ({
        opacity: pressed ? 0.6 : 1,
        width: 36, height: 36, borderRadius: 18,
        backgroundColor: Colors.card,
        alignItems: "center", justifyContent: "center",
        position: "relative",
      })}
    >
      <Text style={{ fontSize: 16 }}>🔔</Text>
      {totalUnread > 0 && (
        <View
          style={{
            position: "absolute",
            top: -1, right: -1,
            minWidth: 16, height: 16, borderRadius: 8,
            backgroundColor: Colors.primary,
            borderWidth: 1.5, borderColor: Colors.surface,
            alignItems: "center", justifyContent: "center",
            paddingHorizontal: 3,
          }}
        >
          <Text style={{ color: "#fff", fontSize: 9, fontWeight: "800", lineHeight: 13 }}>
            {totalUnread > 99 ? "99+" : totalUnread}
          </Text>
        </View>
      )}
    </Pressable>
  );
}
