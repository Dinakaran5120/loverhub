import { View, Text, Pressable } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { Colors } from "@constants/theme";
import { useDiscoverStore } from "@/store/discoverStore";

export function SpotlightBanner() {
  const users  = useDiscoverStore((s) => s.users);
  const online = users.filter((u) => u.online).length;
  const liked  = users.filter((u) => u.liked).length;
  const nearby = users.filter((u) => u.distanceKm <= 5).length;

  return (
    <Pressable style={({ pressed }) => ({ opacity: pressed ? 0.92 : 1, marginBottom: 16 })}>
      <LinearGradient
        colors={[Colors.violet, Colors.rose, Colors.accent]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 0 }}
        style={{ borderRadius: 20, padding: 16 }}
      >
        <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center" }}>
          <View>
            <Text style={{ color: "rgba(255,255,255,0.85)", fontSize: 11, fontWeight: "700", letterSpacing: 0.5 }}>
              ✨ TODAY'S SNAPSHOT
            </Text>
            <Text style={{ color: "#fff", fontSize: 16, fontWeight: "800", marginTop: 3 }}>
              {online} online · {nearby} within 5 km
            </Text>
            {liked > 0 && (
              <Text style={{ color: "rgba(255,255,255,0.8)", fontSize: 12, marginTop: 2 }}>
                You liked {liked} {liked === 1 ? "person" : "people"} today
              </Text>
            )}
          </View>
          <View
            style={{
              backgroundColor: "rgba(255,255,255,0.22)",
              paddingHorizontal: 14,
              paddingVertical: 8,
              borderRadius: 14,
            }}
          >
            <Text style={{ color: "#fff", fontSize: 12, fontWeight: "800" }}>Boost ⚡</Text>
          </View>
        </View>
      </LinearGradient>
    </Pressable>
  );
}
