import { useCallback } from "react";
import { View } from "react-native";
import { useRouter, useFocusEffect } from "expo-router";
import { useExploreStore } from "@/store/exploreStore";

/**
 * Post tab — immediately opens the CreatePostModal inside Explore
 * and redirects to the Explore tab. Explore is where the feed lives.
 */
export default function PostTab() {
  const router        = useRouter();
  const setShowCreate = useExploreStore((s) => s.setShowCreatePost);

  useFocusEffect(
    useCallback(() => {
      setShowCreate(true);
      router.replace("/(tabs)/explore");
    }, [])
  );

  return <View style={{ flex: 1 }} />;
}
