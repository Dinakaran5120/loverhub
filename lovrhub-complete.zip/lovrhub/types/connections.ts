export type MessageType = "text" | "image" | "audio" | "video" | "gif" | "system";
export type MessageStatus = "sending" | "sent" | "delivered" | "read";
export type ConversationType = "direct" | "group";
export type CallType = "audio" | "video";
export type CallStatus = "idle" | "ringing" | "active" | "ended" | "missed" | "declined";
export type ReactionEmoji = "❤️" | "😂" | "🔥" | "😮" | "👍" | "😢";

export interface ChatParticipant {
  id: string;
  name: string;
  avatarEmoji: string;
  gradient: [string, string];
  online: boolean;
  lastSeen: string;
  verified: boolean;
}

export interface MessageReaction {
  emoji: ReactionEmoji;
  count: number;
  reactedByMe: boolean;
}

export interface ChatMessage {
  id: string;
  conversationId: string;
  senderId: string;
  type: MessageType;
  text: string;
  mediaEmoji?: string;
  audioDuration?: string;
  reactions: MessageReaction[];
  replyTo?: string;           // message id being replied to
  replyPreview?: string;      // text snippet for reply preview
  status: MessageStatus;
  createdAt: string;
  deletedForMe: boolean;
}

export interface Conversation {
  id: string;
  type: ConversationType;
  participants: ChatParticipant[];
  // Group only
  groupName?: string;
  groupEmoji?: string;
  groupGradient?: [string, string];
  groupAdminId?: string;
  // Shared
  lastMessage: string;
  lastMessageTime: string;
  lastSenderId: string;
  unreadCount: number;
  isTyping: boolean;
  isPinned: boolean;
  isMuted: boolean;
}

export interface ActiveCall {
  id: string;
  conversationId: string;
  type: CallType;
  status: CallStatus;
  participants: ChatParticipant[];
  startedAt: string | null;
  duration: number;             // seconds elapsed
  isMicMuted: boolean;
  isCameraOff: boolean;
  isSpeakerOn: boolean;
}
