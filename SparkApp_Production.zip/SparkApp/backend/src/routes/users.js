// ── users.js ───────────────────────────────────────────────────────────────────
const express = require('express');
const router = express.Router();
const protect = require('../middleware/auth');
const User = require('../models/User');

// Update profile
router.put('/profile', protect, async (req, res, next) => {
  try {
    const { name, age, bio, interests, lookingFor, gender, orientation, interestedIn } = req.body;
    const updates = {};
    if (name) updates.name = name;
    if (age) updates.age = age;
    if (bio !== undefined) updates.bio = bio;
    if (interests) updates.interests = interests;
    if (lookingFor) updates.lookingFor = lookingFor;
    if (gender) updates.gender = gender;
    if (orientation) updates.orientation = orientation;
    if (interestedIn) updates.interestedIn = interestedIn;

    const completionFields = ['name','age','gender','orientation','bio','photos'];
    const user = await User.findByIdAndUpdate(req.user._id, updates, { new: true, runValidators: true });
    user.profileComplete = completionFields.every(f => f === 'photos' ? user.photos.length > 0 : !!user[f]);
    await user.save();
    res.status(200).json({ success: true, user });
  } catch (err) { next(err); }
});

// Update settings
router.put('/settings', protect, async (req, res, next) => {
  try {
    const user = await User.findById(req.user._id);
    Object.assign(user.settings, req.body);
    await user.save();
    res.status(200).json({ success: true, settings: user.settings });
  } catch (err) { next(err); }
});

// Update location
router.put('/location', protect, async (req, res, next) => {
  try {
    const { latitude, longitude, city, country } = req.body;
    await User.findByIdAndUpdate(req.user._id, {
      location: { type: 'Point', coordinates: [longitude, latitude], city, country, lastUpdated: new Date() }
    });
    res.status(200).json({ success: true });
  } catch (err) { next(err); }
});

// Block user
router.post('/block/:userId', protect, async (req, res, next) => {
  try {
    await User.findByIdAndUpdate(req.user._id, { $addToSet: { blockedUsers: req.params.userId } });
    res.status(200).json({ success: true, message: 'User blocked.' });
  } catch (err) { next(err); }
});

// Get user profile by ID
router.get('/:id', protect, async (req, res, next) => {
  try {
    const user = await User.findById(req.params.id).select('-passwordHash -blockedUsers -emailVerifyToken');
    if (!user || user.isDeleted) return res.status(404).json({ success: false, message: 'User not found.' });
    res.status(200).json({ success: true, user: user.toPublicProfile() });
  } catch (err) { next(err); }
});

module.exports = router;
