import {
  View,
  Text,
  ScrollView,
  Pressable,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { Colors } from "@constants/theme";
import { useDiscoverStore } from "@/store/discoverStore";
import { useDiscoverFilters, useActiveFilterCount } from "@/hooks/useDiscoverFilters";
import { DiscoverCard } from "@components/discover/DiscoverCard";
import { FilterSheet } from "@components/discover/FilterSheet";
import { SpotlightBanner } from "@components/discover/SpotlightBanner";
import { EmptyDiscover } from "@components/discover/EmptyDiscover";

const INTENT_TABS = ["All", "Dating", "Friends", "Hookup", "LGBTQ+"];

// ── Intent tab bar ─────────────────────────────────────────────────────────────
function IntentTabBar() {
  const active    = useDiscoverStore((s) => s.activeIntentFilter);
  const setActive = useDiscoverStore((s) => s.setActiveIntentFilter);

  return (
    <ScrollView
      horizontal
      showsHorizontalScrollIndicator={false}
      contentContainerStyle={{ paddingHorizontal: 16, paddingVertical: 10, gap: 8 }}
    >
      {INTENT_TABS.map((tab) => {
        const isActive = active === tab;
        return (
          <Pressable
            key={tab}
            onPress={() => setActive(tab)}
            style={({ pressed }) => ({ opacity: pressed ? 0.75 : 1 })}
          >
            {isActive ? (
              <LinearGradient
                colors={tab === "LGBTQ+" ? [Colors.violet, Colors.rose] : [Colors.primary, Colors.accent]}
                start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
                style={{ paddingHorizontal: 16, paddingVertical: 8, borderRadius: 20 }}
              >
                <Text style={{ color: "#fff", fontSize: 13, fontWeight: "700", letterSpacing: 0.2 }}>
                  {tab}
                </Text>
              </LinearGradient>
            ) : (
              <View style={{ paddingHorizontal: 16, paddingVertical: 8, borderRadius: 20, backgroundColor: Colors.card, borderWidth: 1, borderColor: Colors.border }}>
                <Text style={{ color: Colors.textSecondary, fontSize: 13, fontWeight: "600", letterSpacing: 0.2 }}>
                  {tab}
                </Text>
              </View>
            )}
          </Pressable>
        );
      })}
    </ScrollView>
  );
}

// ── Sub-header: count + quick toggles + filter btn ───────────────────────────
function DiscoverHeader() {
  const setShowSheet  = useDiscoverStore((s) => s.setShowFilterSheet);
  const activeCount   = useActiveFilterCount();
  const filteredUsers = useDiscoverFilters();
  const filters       = useDiscoverStore((s) => s.filters);
  const setFilters    = useDiscoverStore((s) => s.setFilters);
  const onlineOnly    = filters.onlineOnly;
  const favOnly       = filters.favouritesOnly;

  return (
    <View style={{ flexDirection: "row", alignItems: "center", paddingHorizontal: 16, paddingBottom: 10, gap: 8 }}>
      <View style={{ flex: 1 }}>
        <Text style={{ fontSize: 13, color: Colors.textMuted, fontWeight: "600" }}>
          {filteredUsers.length === 0 ? "No matches" : `${filteredUsers.length} people nearby`}
        </Text>
      </View>

      {/* Online quick toggle */}
      <Pressable
        onPress={() => setFilters({ onlineOnly: !onlineOnly })}
        style={({ pressed }) => ({
          flexDirection: "row", alignItems: "center", gap: 5,
          paddingHorizontal: 12, paddingVertical: 7, borderRadius: 14,
          backgroundColor: onlineOnly ? "#16a34a22" : Colors.card,
          borderWidth: 1.5, borderColor: onlineOnly ? "#16a34a" : Colors.border,
          opacity: pressed ? 0.7 : 1,
        })}
      >
        <View style={{ width: 7, height: 7, borderRadius: 4, backgroundColor: onlineOnly ? "#16a34a" : Colors.textMuted }} />
        <Text style={{ fontSize: 12, fontWeight: "700", color: onlineOnly ? "#16a34a" : Colors.textMuted }}>
          Online
        </Text>
      </Pressable>

      {/* Favourites quick toggle */}
      <Pressable
        onPress={() => setFilters({ favouritesOnly: !favOnly })}
        style={({ pressed }) => ({
          flexDirection: "row", alignItems: "center", gap: 5,
          paddingHorizontal: 12, paddingVertical: 7, borderRadius: 14,
          backgroundColor: favOnly ? Colors.gold + "22" : Colors.card,
          borderWidth: 1.5, borderColor: favOnly ? Colors.gold : Colors.border,
          opacity: pressed ? 0.7 : 1,
        })}
      >
        <Text style={{ fontSize: 13 }}>{favOnly ? "⭐" : "☆"}</Text>
        <Text style={{ fontSize: 12, fontWeight: "700", color: favOnly ? Colors.gold : Colors.textMuted }}>
          Saved
        </Text>
      </Pressable>

      {/* Filter button */}
      <Pressable
        onPress={() => setShowSheet(true)}
        style={({ pressed }) => ({
          flexDirection: "row", alignItems: "center", gap: 6,
          paddingHorizontal: 14, paddingVertical: 7, borderRadius: 14,
          backgroundColor: activeCount > 0 ? Colors.primary + "18" : Colors.card,
          borderWidth: 1.5, borderColor: activeCount > 0 ? Colors.primary : Colors.border,
          opacity: pressed ? 0.7 : 1,
        })}
      >
        <Text style={{ fontSize: 14 }}>⚙</Text>
        <Text style={{ fontSize: 12, fontWeight: "700", color: activeCount > 0 ? Colors.primary : Colors.textMuted }}>
          Filters{activeCount > 0 ? ` (${activeCount})` : ""}
        </Text>
      </Pressable>
    </View>
  );
}

// ── Main screen ────────────────────────────────────────────────────────────────
export default function DiscoverScreen() {
  const filteredUsers = useDiscoverFilters();

  return (
    <View style={{ flex: 1, backgroundColor: Colors.background }}>
      <IntentTabBar />
      <DiscoverHeader />

      <ScrollView
        contentContainerStyle={{ paddingHorizontal: 16, paddingBottom: 32 }}
        showsVerticalScrollIndicator={false}
      >
        <SpotlightBanner />

        {filteredUsers.length === 0 ? (
          <EmptyDiscover />
        ) : (
          <View style={{ alignItems: "center", gap: 4 }}>
            {filteredUsers.map((user) => (
              <DiscoverCard key={user.id} user={user} />
            ))}
          </View>
        )}
      </ScrollView>

      <FilterSheet />
    </View>
  );
}
