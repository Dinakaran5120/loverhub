const { messageRoutes } = require('./allRoutes'); module.exports = messageRoutes;
