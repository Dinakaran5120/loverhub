import { create } from "zustand";
import type {
  Community, CommunityPost, MembershipStatus,
  JoinRequest, PollOption,
} from "@/types/community";
import { MOCK_COMMUNITIES, MOCK_COMMUNITY_POSTS } from "@/data/mockCommunities";
import { Colors } from "@constants/theme";

interface CommunityState {
  communities: Community[];
  posts: Record<string, CommunityPost[]>;   // communityId → posts
  activeCommunityId: string | null;
  showCreateModal: boolean;
  showJoinRequestModal: string | null;      // communityId
  requestMessage: string;

  // Navigation
  setActiveCommunity: (id: string | null) => void;
  setShowCreateModal: (show: boolean) => void;
  setShowJoinRequest: (id: string | null) => void;
  setRequestMessage: (msg: string) => void;

  // Join / Leave
  joinCommunity: (id: string) => void;
  leaveCommunity: (id: string) => void;
  sendJoinRequest: (id: string, message: string) => void;
  cancelJoinRequest: (id: string) => void;

  // Owner/Admin — approve or reject requests
  approveRequest: (communityId: string, requestId: string) => void;
  rejectRequest: (communityId: string, requestId: string) => void;

  // Posts
  likePost: (communityId: string, postId: string) => void;
  voteOnPoll: (communityId: string, postId: string, optionId: string) => void;
  addPost: (
    communityId: string,
    data: Pick<CommunityPost, "type" | "content" | "title" | "mediaEmoji" | "mediaGradient" | "tags" | "pollOptions">
  ) => void;

  // Create community
  createCommunity: (data: Omit<Community, "id" | "slug" | "memberCount" | "postCount" | "members" | "pendingRequests" | "myStatus" | "createdAt" | "lastActivityAt">) => void;
}

const ME = {
  id: "me",
  name: "You",
  avatarEmoji: "😊",
  gradient: [Colors.primary, Colors.accent] as [string, string],
  role: "member" as const,
  joinedAt: new Date().toISOString(),
};

function slugify(name: string): string {
  return name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
}

export const useCommunityStore = create<CommunityState>((set, get) => ({
  communities: MOCK_COMMUNITIES,
  posts: MOCK_COMMUNITY_POSTS,
  activeCommunityId: null,
  showCreateModal: false,
  showJoinRequestModal: null,
  requestMessage: "",

  setActiveCommunity: (id) => set({ activeCommunityId: id }),
  setShowCreateModal: (show) => set({ showCreateModal: show }),
  setShowJoinRequest: (id) => set({ showJoinRequestModal: id, requestMessage: "" }),
  setRequestMessage: (msg) => set({ requestMessage: msg }),

  // ── Public join (instant) ──────────────────────────────────────────────
  joinCommunity: (id) =>
    set((state) => ({
      communities: state.communities.map((c) =>
        c.id !== id ? c : {
          ...c,
          myStatus: "member" as MembershipStatus,
          memberCount: c.memberCount + 1,
          members: [...c.members, ME],
        }
      ),
    })),

  leaveCommunity: (id) =>
    set((state) => ({
      communities: state.communities.map((c) =>
        c.id !== id ? c : {
          ...c,
          myStatus: "none" as MembershipStatus,
          memberCount: Math.max(0, c.memberCount - 1),
          members: c.members.filter((m) => m.id !== "me"),
        }
      ),
    })),

  // ── Private join request ───────────────────────────────────────────────
  sendJoinRequest: (id, message) =>
    set((state) => ({
      communities: state.communities.map((c) => {
        if (c.id !== id) return c;
        const req: JoinRequest = {
          id: `req_${Date.now()}`,
          userId: "me",
          userName: "You",
          avatarEmoji: "😊",
          gradient: [Colors.primary, Colors.accent],
          message,
          requestedAt: new Date().toISOString(),
          status: "pending",
        };
        return {
          ...c,
          myStatus: "pending" as MembershipStatus,
          pendingRequests: [...c.pendingRequests, req],
        };
      }),
      showJoinRequestModal: null,
    })),

  cancelJoinRequest: (id) =>
    set((state) => ({
      communities: state.communities.map((c) =>
        c.id !== id ? c : {
          ...c,
          myStatus: "none" as MembershipStatus,
          pendingRequests: c.pendingRequests.filter((r) => r.userId !== "me"),
        }
      ),
    })),

  // ── Owner approves a join request ─────────────────────────────────────
  approveRequest: (communityId, requestId) =>
    set((state) => {
      const community = state.communities.find((c) => c.id === communityId);
      const req = community?.pendingRequests.find((r) => r.id === requestId);
      if (!community || !req) return state;

      const newMember = {
        id: req.userId,
        name: req.userName,
        avatarEmoji: req.avatarEmoji,
        gradient: req.gradient,
        role: "member" as const,
        joinedAt: new Date().toISOString(),
      };

      return {
        communities: state.communities.map((c) =>
          c.id !== communityId ? c : {
            ...c,
            memberCount: c.memberCount + 1,
            members: [...c.members, newMember],
            pendingRequests: c.pendingRequests.filter((r) => r.id !== requestId),
          }
        ),
      };
    }),

  rejectRequest: (communityId, requestId) =>
    set((state) => ({
      communities: state.communities.map((c) =>
        c.id !== communityId ? c : {
          ...c,
          pendingRequests: c.pendingRequests.filter((r) => r.id !== requestId),
        }
      ),
    })),

  // ── Post interactions ──────────────────────────────────────────────────
  likePost: (communityId, postId) =>
    set((state) => ({
      posts: {
        ...state.posts,
        [communityId]: (state.posts[communityId] ?? []).map((p) =>
          p.id !== postId ? p : {
            ...p,
            liked: !p.liked,
            likes: p.liked ? p.likes - 1 : p.likes + 1,
          }
        ),
      },
    })),

  voteOnPoll: (communityId, postId, optionId) =>
    set((state) => ({
      posts: {
        ...state.posts,
        [communityId]: (state.posts[communityId] ?? []).map((p) => {
          if (p.id !== postId || !p.pollOptions) return p;
          const alreadyVoted = p.pollOptions.some((o) => o.votedByMe);
          return {
            ...p,
            pollOptions: p.pollOptions.map((o) => {
              if (o.id === optionId) {
                return o.votedByMe
                  ? { ...o, votes: o.votes - 1, votedByMe: false }
                  : { ...o, votes: o.votes + 1, votedByMe: true };
              }
              // Unvote any previously selected option
              return o.votedByMe ? { ...o, votes: o.votes - 1, votedByMe: false } : o;
            }),
          };
        }),
      },
    })),

  addPost: (communityId, data) => {
    const newPost: CommunityPost = {
      id: `cp_${Date.now()}`,
      communityId,
      type: data.type,
      author: ME,
      title: data.title,
      content: data.content,
      mediaEmoji: data.mediaEmoji,
      mediaGradient: data.mediaGradient,
      pollOptions: data.pollOptions,
      tags: data.tags ?? [],
      likes: 0,
      liked: false,
      commentCount: 0,
      isPinned: false,
      isAnnouncement: false,
      createdAt: new Date().toISOString(),
    };
    set((state) => ({
      posts: {
        ...state.posts,
        [communityId]: [newPost, ...(state.posts[communityId] ?? [])],
      },
      communities: state.communities.map((c) =>
        c.id !== communityId ? c : {
          ...c,
          postCount: c.postCount + 1,
          lastActivityAt: new Date().toISOString(),
        }
      ),
    }));
  },

  // ── Create community ───────────────────────────────────────────────────
  createCommunity: (data) => {
    const newCommunity: Community = {
      ...data,
      id: `comm_${Date.now()}`,
      slug: slugify(data.name),
      memberCount: 1,
      postCount: 0,
      members: [{ ...ME, role: "owner" }],
      pendingRequests: [],
      myStatus: "owner",
      createdAt: new Date().toISOString(),
      lastActivityAt: new Date().toISOString(),
    };
    set((state) => ({
      communities: [newCommunity, ...state.communities],
      posts: { ...state.posts, [newCommunity.id]: [] },
      showCreateModal: false,
      activeCommunityId: newCommunity.id,
    }));
  },
}));
