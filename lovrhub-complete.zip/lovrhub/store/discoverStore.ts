import { create } from "zustand";
import type {
  NearbyUser,
  DiscoverFilters,
  ProfileRequestStatus,
} from "@/types/discover";
import { DEFAULT_FILTERS } from "@/types/discover";
import { MOCK_NEARBY_USERS } from "@/data/mockUsers";

interface DiscoverState {
  // Data
  users: NearbyUser[];
  filters: DiscoverFilters;
  activeIntentFilter: string;   // "All" | "Dating" | "Friends" | "Hookup" | "LGBTQ+"
  showFilterSheet: boolean;

  // Actions — user interactions
  likeUser: (id: string) => void;
  superLikeUser: (id: string) => void;
  passUser: (id: string) => void;
  toggleFavourite: (id: string) => void;
  requestProfile: (id: string) => void;

  // Filter actions
  setFilters: (filters: Partial<DiscoverFilters>) => void;
  resetFilters: () => void;
  setActiveIntentFilter: (intent: string) => void;
  setShowFilterSheet: (show: boolean) => void;
}

export const useDiscoverStore = create<DiscoverState>((set) => ({
  users: MOCK_NEARBY_USERS,
  filters: DEFAULT_FILTERS,
  activeIntentFilter: "All",
  showFilterSheet: false,

  likeUser: (id) =>
    set((state) => ({
      users: state.users.map((u) =>
        u.id === id ? { ...u, liked: !u.liked, superLiked: false } : u
      ),
    })),

  superLikeUser: (id) =>
    set((state) => ({
      users: state.users.map((u) =>
        u.id === id
          ? { ...u, superLiked: !u.superLiked, liked: !u.superLiked ? true : u.liked }
          : u
      ),
    })),

  passUser: (id) =>
    set((state) => ({
      // Move passed user to end of list — they can reappear
      users: [
        ...state.users.filter((u) => u.id !== id),
        { ...state.users.find((u) => u.id === id)!, liked: false, superLiked: false },
      ],
    })),

  toggleFavourite: (id) =>
    set((state) => ({
      users: state.users.map((u) =>
        u.id === id ? { ...u, favourited: !u.favourited } : u
      ),
    })),

  requestProfile: (id) =>
    set((state) => ({
      users: state.users.map((u) => {
        if (u.id !== id) return u;
        const next: ProfileRequestStatus =
          u.requestStatus === "none" ? "pending"
          : u.requestStatus === "pending" ? "none"
          : u.requestStatus;
        return { ...u, requestStatus: next };
      }),
    })),

  setFilters: (filters) =>
    set((state) => ({
      filters: { ...state.filters, ...filters },
    })),

  resetFilters: () =>
    set({ filters: DEFAULT_FILTERS }),

  setActiveIntentFilter: (intent) =>
    set({ activeIntentFilter: intent }),

  setShowFilterSheet: (show) =>
    set({ showFilterSheet: show }),
}));
