import { View, Text, ScrollView, Pressable, Switch } from "react-native";
import { useRouter } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Colors } from "@constants/theme";
import { useNotificationStore } from "@/store/notificationStore";

const PREF_ITEMS = [
  { key: "follows"       as const, label: "Follows",           subtitle: "When someone follows you",              emoji: "👤" },
  { key: "messages"      as const, label: "Messages",          subtitle: "New direct messages",                   emoji: "💬" },
  { key: "matches"       as const, label: "Matches",           subtitle: "New mutual matches",                    emoji: "💕" },
  { key: "likes"         as const, label: "Likes",             subtitle: "Likes on posts and profile",            emoji: "❤️" },
  { key: "comments"      as const, label: "Comments",          subtitle: "Comments and mentions",                 emoji: "🗨️" },
  { key: "communityPosts"as const, label: "Community Posts",   subtitle: "Posts in communities you've joined",    emoji: "📝" },
  { key: "joinRequests"  as const, label: "Join Requests",     subtitle: "Requests to join your communities",     emoji: "🔔" },
  { key: "profileViews"  as const, label: "Profile Views",     subtitle: "When someone views your profile",       emoji: "👁" },
  { key: "systemUpdates" as const, label: "System Updates",    subtitle: "Product news and announcements",        emoji: "📣" },
  { key: "pushEnabled"   as const, label: "Push Notifications",subtitle: "Master toggle for all push alerts",     emoji: "📲" },
  { key: "emailDigest"   as const, label: "Email Digest",      subtitle: "Weekly summary email",                  emoji: "📧" },
  { key: "quietHoursEnabled" as const, label: "Quiet Hours",   subtitle: "Pause notifications at night",          emoji: "🌙" },
];

export default function NotificationsSettingsScreen() {
  const router      = useRouter();
  const insets      = useSafeAreaInsets();
  const prefs       = useNotificationStore((s) => s.preferences);
  const updatePref  = useNotificationStore((s) => s.updatePreference);

  return (
    <View style={{ flex: 1, backgroundColor: Colors.background }}>
      <View style={{ paddingTop: insets.top, backgroundColor: Colors.surface, borderBottomWidth: 1, borderBottomColor: Colors.border }}>
        <View style={{ height: 56, flexDirection: "row", alignItems: "center", paddingHorizontal: 16, gap: 12 }}>
          <Pressable onPress={() => router.back()} hitSlop={10} style={({ pressed }) => ({ opacity: pressed ? 0.6 : 1 })}>
            <Text style={{ fontSize: 22, color: Colors.text }}>←</Text>
          </Pressable>
          <Text style={{ fontSize: 17, fontWeight: "800", color: Colors.text }}>Notification Settings</Text>
        </View>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingTop: 12, paddingBottom: 48 }}>
        <View style={{ backgroundColor: Colors.surface, borderTopWidth: 1, borderBottomWidth: 1, borderColor: Colors.border }}>
          {PREF_ITEMS.map((item, i) => (
            <View key={item.key}>
              <View style={{ flexDirection: "row", alignItems: "center", paddingHorizontal: 16, paddingVertical: 13, gap: 12 }}>
                <View style={{ width: 36, height: 36, borderRadius: 10, backgroundColor: Colors.card, alignItems: "center", justifyContent: "center", borderWidth: 1, borderColor: Colors.border }}>
                  <Text style={{ fontSize: 18 }}>{item.emoji}</Text>
                </View>
                <View style={{ flex: 1, gap: 2 }}>
                  <Text style={{ fontSize: 14, fontWeight: "600", color: Colors.text }}>{item.label}</Text>
                  <Text style={{ fontSize: 12, color: Colors.textMuted }}>{item.subtitle}</Text>
                </View>
                <Switch
                  value={Boolean(prefs[item.key])}
                  onValueChange={(v) => updatePref(item.key, v)}
                  trackColor={{ false: Colors.border, true: Colors.primary }}
                  thumbColor="#fff"
                />
              </View>
              {i < PREF_ITEMS.length - 1 && <View style={{ height: 1, backgroundColor: Colors.border, marginLeft: 64 }} />}
            </View>
          ))}
        </View>
      </ScrollView>
    </View>
  );
}
