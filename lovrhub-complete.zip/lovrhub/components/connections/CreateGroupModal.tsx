import { useState } from "react";
import {
  View, Text, Modal, Pressable, TextInput,
  ScrollView, KeyboardAvoidingView, Platform,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Colors } from "@constants/theme";
import { useConnectionsStore } from "@/store/connectionsStore";
import { PARTICIPANTS } from "@/data/mockConversations";

const GROUP_EMOJIS = ["👥", "🌆", "🌈", "🔮", "🎉", "💫", "🎵", "🏖️", "☕", "🌙", "✨", "🔥"];

export function CreateGroupModal({
  visible, onClose,
}: {
  visible: boolean; onClose: () => void;
}) {
  const insets          = useSafeAreaInsets();
  const createGroupChat = useConnectionsStore((s) => s.createGroupChat);

  const [name, setName]               = useState("");
  const [emoji, setEmoji]             = useState("👥");
  const [selectedIds, setSelectedIds] = useState<string[]>([]);

  const allParticipants = Object.values(PARTICIPANTS);

  const toggle = (id: string) =>
    setSelectedIds((prev) => prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]);

  const handleCreate = () => {
    if (!name.trim() || selectedIds.length === 0) return;
    createGroupChat(name.trim(), emoji, selectedIds);
    setName(""); setEmoji("👥"); setSelectedIds([]);
    onClose();
  };

  return (
    <Modal visible={visible} animationType="slide" presentationStyle="pageSheet" onRequestClose={onClose}>
      <KeyboardAvoidingView style={{ flex: 1, backgroundColor: Colors.background }} behavior={Platform.OS === "ios" ? "padding" : "height"}>
        {/* Header */}
        <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 20, paddingTop: insets.top + 16, paddingBottom: 16, borderBottomWidth: 1, borderBottomColor: Colors.border, backgroundColor: Colors.surface }}>
          <Pressable onPress={onClose}>
            <Text style={{ fontSize: 15, color: Colors.textSecondary, fontWeight: "600" }}>Cancel</Text>
          </Pressable>
          <Text style={{ fontSize: 16, fontWeight: "800", color: Colors.text }}>New Group</Text>
          <Pressable
            onPress={handleCreate}
            disabled={!name.trim() || selectedIds.length < 2}
            style={({ pressed }) => ({ opacity: (name.trim() && selectedIds.length >= 2) ? (pressed ? 0.7 : 1) : 0.4 })}
          >
            <LinearGradient colors={[Colors.primary, Colors.accent]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} style={{ paddingHorizontal: 18, paddingVertical: 8, borderRadius: 14 }}>
              <Text style={{ color: "#fff", fontWeight: "800", fontSize: 14 }}>Create</Text>
            </LinearGradient>
          </Pressable>
        </View>

        <ScrollView contentContainerStyle={{ padding: 20, gap: 20 }} keyboardShouldPersistTaps="handled">
          {/* Emoji picker */}
          <View style={{ gap: 10 }}>
            <Text style={{ fontSize: 13, fontWeight: "700", color: Colors.textSecondary, letterSpacing: 0.3 }}>GROUP ICON</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 10 }}>
              {GROUP_EMOJIS.map((e) => (
                <Pressable
                  key={e}
                  onPress={() => setEmoji(e)}
                  style={({ pressed }) => ({
                    width: 52, height: 52, borderRadius: 16,
                    backgroundColor: emoji === e ? Colors.primary + "18" : Colors.card,
                    borderWidth: 1.5, borderColor: emoji === e ? Colors.primary : Colors.border,
                    alignItems: "center", justifyContent: "center",
                    opacity: pressed ? 0.7 : 1,
                  })}
                >
                  <Text style={{ fontSize: 26 }}>{e}</Text>
                </Pressable>
              ))}
            </ScrollView>
          </View>

          {/* Group name */}
          <View style={{ gap: 8 }}>
            <Text style={{ fontSize: 13, fontWeight: "700", color: Colors.textSecondary, letterSpacing: 0.3 }}>GROUP NAME</Text>
            <TextInput
              value={name}
              onChangeText={setName}
              placeholder={`${emoji} Give your group a name…`}
              placeholderTextColor={Colors.textMuted}
              maxLength={40}
              style={{ backgroundColor: Colors.surface, borderRadius: 16, borderWidth: 1, borderColor: Colors.border, paddingHorizontal: 14, paddingVertical: 13, fontSize: 15, color: Colors.text }}
            />
          </View>

          {/* Member picker */}
          <View style={{ gap: 10 }}>
            <Text style={{ fontSize: 13, fontWeight: "700", color: Colors.textSecondary, letterSpacing: 0.3 }}>
              ADD MEMBERS ({selectedIds.length} selected, min 2)
            </Text>
            {allParticipants.map((p) => {
              const isSelected = selectedIds.includes(p.id);
              return (
                <Pressable
                  key={p.id}
                  onPress={() => toggle(p.id)}
                  style={({ pressed }) => ({
                    flexDirection: "row", alignItems: "center", gap: 12,
                    padding: 12, borderRadius: 16,
                    backgroundColor: isSelected ? Colors.primary + "0e" : Colors.surface,
                    borderWidth: 1.5, borderColor: isSelected ? Colors.primary : Colors.border,
                    opacity: pressed ? 0.8 : 1,
                  })}
                >
                  <LinearGradient colors={p.gradient} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={{ width: 44, height: 44, borderRadius: 22, alignItems: "center", justifyContent: "center" }}>
                    <Text style={{ fontSize: 22 }}>{p.avatarEmoji}</Text>
                  </LinearGradient>
                  <View style={{ flex: 1 }}>
                    <Text style={{ fontSize: 14, fontWeight: "700", color: Colors.text }}>{p.name}</Text>
                    <View style={{ flexDirection: "row", alignItems: "center", gap: 5 }}>
                      <View style={{ width: 7, height: 7, borderRadius: 3.5, backgroundColor: p.online ? "#22c55e" : Colors.border }} />
                      <Text style={{ fontSize: 12, color: Colors.textMuted }}>{p.online ? "Online" : "Offline"}</Text>
                    </View>
                  </View>
                  <View style={{
                    width: 26, height: 26, borderRadius: 13,
                    backgroundColor: isSelected ? Colors.primary : Colors.card,
                    borderWidth: 1.5, borderColor: isSelected ? Colors.primary : Colors.border,
                    alignItems: "center", justifyContent: "center",
                  }}>
                    {isSelected && <Text style={{ color: "#fff", fontSize: 14, fontWeight: "800" }}>✓</Text>}
                  </View>
                </Pressable>
              );
            })}
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </Modal>
  );
}
