// ── swipes.js ──────────────────────────────────────────────────────────────────
const express = require('express');
const swipeRouter = express.Router();
const protect = require('../middleware/auth');
const { getDiscoveryFeed, swipe, getMatches, unmatch, getLikes } = require('../controllers/swipeController');

swipeRouter.get('/feed', protect, getDiscoveryFeed);
swipeRouter.post('/', protect, swipe);
swipeRouter.get('/likes', protect, getLikes);
module.exports = swipeRouter;
