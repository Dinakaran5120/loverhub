import { useState, useRef } from "react";
import { View, Text, ScrollView, Pressable, KeyboardAvoidingView, Platform, Dimensions, Animated } from "react-native";
import { useRouter } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { LinearGradient } from "expo-linear-gradient";
import { Colors } from "@constants/theme";
import { useAuthStore } from "@/store/authStore";
import { AuthInput, PrimaryButton, BackButton, AuthProgressBar, SelectChip, StepHeader } from "@components/auth/AuthUI";

const TOTAL_STEPS = 9;

const GENDERS = [
  { label: "Man",            emoji: "👨" },
  { label: "Woman",          emoji: "👩" },
  { label: "Non-binary",     emoji: "🧑" },
  { label: "Transgender",    emoji: "⚧️" },
  { label: "Genderqueer",    emoji: "🌈" },
  { label: "Prefer not to say", emoji: "🤐" },
];

const ORIENTATIONS = [
  { label: "Straight",       emoji: "💑",  grad: [Colors.primary, Colors.accent]     as [string,string] },
  { label: "Gay",            emoji: "🏳️‍🌈", grad: [Colors.violet, Colors.sky]         as [string,string] },
  { label: "Lesbian",        emoji: "🌸",   grad: [Colors.rose, Colors.secondary]    as [string,string] },
  { label: "Bisexual",       emoji: "💜",   grad: [Colors.rose, Colors.violet]       as [string,string] },
  { label: "Pansexual",      emoji: "💛",   grad: [Colors.gold, Colors.rose]         as [string,string] },
  { label: "Asexual",        emoji: "🖤",   grad: ["#666", "#999"]                   as [string,string] },
  { label: "Queer",          emoji: "🌈",   grad: [Colors.violet, Colors.accent]     as [string,string] },
  { label: "Questioning",    emoji: "🤔",   grad: [Colors.sky, Colors.violet]        as [string,string] },
  { label: "Prefer not to say", emoji: "🤐", grad: [Colors.muted, "#aaa"]           as [string,string] },
];

const INTERESTED_IN = [
  { label: "Men",        emoji: "👨" },
  { label: "Women",      emoji: "👩" },
  { label: "Non-binary", emoji: "🧑" },
  { label: "Everyone",   emoji: "🌍" },
];

const RELATIONSHIP_TYPES = [
  { label: "Long-term",   emoji: "💍", grad: [Colors.primary, Colors.accent]  as [string,string] },
  { label: "Casual",      emoji: "😄", grad: [Colors.accent, Colors.gold]     as [string,string] },
  { label: "Hookup",      emoji: "🔥", grad: [Colors.rose, Colors.primary]    as [string,string] },
  { label: "Friendship",  emoji: "🤝", grad: [Colors.violet, Colors.sky]      as [string,string] },
  { label: "Open to all", emoji: "✨", grad: [Colors.secondary, Colors.rose]  as [string,string] },
  { label: "Marriage",    emoji: "💒", grad: [Colors.gold, Colors.accent]     as [string,string] },
];

const LANGUAGES = [
  { label: "Hindi",     emoji: "🇮🇳" },
  { label: "English",   emoji: "🇬🇧" },
  { label: "Bengali",   emoji: "🐟"  },
  { label: "Telugu",    emoji: "🌶️"  },
  { label: "Marathi",   emoji: "🏙️"  },
  { label: "Tamil",     emoji: "🌊"  },
  { label: "Gujarati",  emoji: "🎭"  },
  { label: "Kannada",   emoji: "🌿"  },
  { label: "Malayalam", emoji: "🌴"  },
  { label: "Punjabi",   emoji: "🥁"  },
  { label: "Odia",      emoji: "🏛️"  },
  { label: "Urdu",      emoji: "📜"  },
];

const INTERESTS = [
  { label: "Music",        emoji: "🎵", grad: [Colors.primary, Colors.accent]    as [string,string] },
  { label: "Travel",       emoji: "✈️", grad: [Colors.sky, Colors.violet]        as [string,string] },
  { label: "Fitness",      emoji: "💪", grad: [Colors.accent, Colors.gold]       as [string,string] },
  { label: "Foodie",       emoji: "🍜", grad: [Colors.gold, Colors.accent]       as [string,string] },
  { label: "Movies",       emoji: "🎬", grad: [Colors.violet, Colors.rose]       as [string,string] },
  { label: "Books",        emoji: "📚", grad: [Colors.secondary, Colors.rose]    as [string,string] },
  { label: "Art",          emoji: "🎨", grad: [Colors.rose, Colors.violet]       as [string,string] },
  { label: "Gaming",       emoji: "🎮", grad: [Colors.violet, Colors.sky]        as [string,string] },
  { label: "Photography",  emoji: "📸", grad: [Colors.accent, Colors.secondary]  as [string,string] },
  { label: "Cricket",      emoji: "🏏", grad: [Colors.primary, Colors.rose]      as [string,string] },
  { label: "Yoga",         emoji: "🧘", grad: [Colors.mint, Colors.sky]          as [string,string] },
  { label: "Dancing",      emoji: "💃", grad: [Colors.rose, Colors.accent]       as [string,string] },
  { label: "Cooking",      emoji: "👨‍🍳", grad: [Colors.gold, Colors.primary]     as [string,string] },
  { label: "Tech",         emoji: "💻", grad: [Colors.sky, Colors.violet]        as [string,string] },
  { label: "Spirituality", emoji: "🕉️", grad: [Colors.secondary, Colors.gold]   as [string,string] },
  { label: "Nature",       emoji: "🌿", grad: [Colors.mint, Colors.sky]          as [string,string] },
  { label: "Bollywood",    emoji: "🎭", grad: [Colors.primary, Colors.secondary] as [string,string] },
  { label: "Pets",         emoji: "🐾", grad: [Colors.accent, Colors.gold]       as [string,string] },
];

const PHOTO_AVATARS = [
  "😊","😎","🥰","😍","🤩","😏","🥳","🌈","✨","💫",
  "🦋","🌸","🌺","🦄","🐺","🦊","🐯","🦁","🐼","🐸",
];

const AGE_QUICK = [18,19,20,21,22,23,24,25,26,27,28,29,30,32,35,40];

export default function SetupScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { updateProfile, completeAuth } = useAuthStore();

  const [step, setStep]               = useState(0);
  const [slideAnim]                   = useState(new Animated.Value(0));
  const [name, setName]               = useState("");
  const [age, setAge]                 = useState("");
  const [gender, setGender]           = useState("");
  const [orientation, setOrientation] = useState("");
  const [interestedIn, setInterested] = useState<string[]>([]);
  const [relTypes, setRelTypes]       = useState<string[]>([]);
  const [languages, setLanguages]     = useState<string[]>([]);
  const [interests, setInterests]     = useState<string[]>([]);
  const [photoEmoji, setPhotoEmoji]   = useState("");
  const [nameError, setNameError]     = useState("");
  const [ageError, setAgeError]       = useState("");

  const animateStep = () => {
    Animated.sequence([
      Animated.timing(slideAnim, { toValue: -30, duration: 120, useNativeDriver: true }),
      Animated.timing(slideAnim, { toValue: 0,   duration: 180, useNativeDriver: true }),
    ]).start();
  };

  const goNext = () => { animateStep(); setStep((s) => s + 1); };
  const goBack = () => { if (step === 0) { router.back(); return; } setStep((s) => s - 1); };

  const toggle = (val: string, list: string[], setList: (v: string[]) => void) =>
    setList(list.includes(val) ? list.filter((x) => x !== val) : [...list, val]);

  const handleFinish = () => {
    updateProfile({ name, age, gender, orientation, interestedIn, relationshipType: relTypes, languages, interests, photoEmoji });
    completeAuth();
    router.replace("/(tabs)");
  };

  const advanceName = () => {
    if (name.trim().length < 2) { setNameError("Name must be at least 2 characters"); return; }
    setNameError("");
    updateProfile({ name: name.trim() });
    goNext();
  };

  const advanceAge = () => {
    const n = parseInt(age);
    if (isNaN(n) || n < 18 || n > 80) { setAgeError("Must be between 18 and 80"); return; }
    setAgeError("");
    updateProfile({ age });
    goNext();
  };

  return (
    <KeyboardAvoidingView
      style={{ flex: 1, backgroundColor: Colors.background }}
      behavior={Platform.OS === "ios" ? "padding" : "height"}
    >
      <View style={{ paddingTop: insets.top }}>
        <BackButton onPress={goBack} />
        <AuthProgressBar current={step + 1} total={TOTAL_STEPS} />
      </View>

      <Animated.View style={{ flex: 1, transform: [{ translateX: slideAnim }] }}>
        {step === 0 && (
          <ScrollView contentContainerStyle={{ flexGrow: 1, paddingBottom: insets.bottom + 32 }} keyboardShouldPersistTaps="handled">
            <StepHeader emoji="👋" title="What should we call you?" subtitle="Your first name or nickname — shown on your profile." />
            <View style={{ paddingHorizontal: 24, gap: 16 }}>
              <AuthInput
                label="Display Name" placeholder="e.g. Arjun, Priya…"
                value={name} onChangeText={(v) => { setName(v); if (nameError) setNameError(""); }}
                autoFocus maxLength={30} error={nameError} hint="Your first name or nickname works great"
              />
              <Text style={{ textAlign: "right", fontSize: 12, color: Colors.textMuted }}>{name.length}/30</Text>
              <PrimaryButton label="Continue" onPress={advanceName} disabled={name.trim().length < 2} icon="→" />
            </View>
          </ScrollView>
        )}

        {step === 1 && (
          <ScrollView contentContainerStyle={{ flexGrow: 1, paddingBottom: insets.bottom + 32 }} keyboardShouldPersistTaps="handled">
            <StepHeader emoji="🎂" title="How old are you?" subtitle="Must be 18 or older. Shown on your profile." />
            <View style={{ paddingHorizontal: 24, gap: 16 }}>
              <AuthInput
                label="Your Age" placeholder="e.g. 24" value={age}
                onChangeText={(v) => { setAge(v.replace(/\D/g, "").slice(0, 2)); if (ageError) setAgeError(""); }}
                keyboardType="number-pad" autoFocus maxLength={2}
                error={ageError} hint="Between 18 and 80"
              />
              <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 8 }}>
                {AGE_QUICK.map((a) => (
                  <Pressable key={a} onPress={() => setAge(String(a))} style={({ pressed }) => ({ opacity: pressed ? 0.7 : 1 })}>
                    {age === String(a) ? (
                      <LinearGradient colors={[Colors.primary, Colors.accent]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} style={{ paddingHorizontal: 16, paddingVertical: 9, borderRadius: 16 }}>
                        <Text style={{ color: "#fff", fontWeight: "800", fontSize: 14 }}>{a}</Text>
                      </LinearGradient>
                    ) : (
                      <View style={{ paddingHorizontal: 16, paddingVertical: 9, borderRadius: 16, borderWidth: 1.5, borderColor: Colors.border, backgroundColor: Colors.card }}>
                        <Text style={{ color: Colors.textSecondary, fontWeight: "600", fontSize: 14 }}>{a}</Text>
                      </View>
                    )}
                  </Pressable>
                ))}
              </ScrollView>
              <PrimaryButton label="Continue" onPress={advanceAge} disabled={age.length < 1} icon="→" />
            </View>
          </ScrollView>
        )}

        {step === 2 && (
          <ScrollView contentContainerStyle={{ paddingBottom: insets.bottom + 32 }}>
            <StepHeader emoji="🌈" title="What's your gender?" subtitle="We celebrate all identities. Choose what feels right." />
            <View style={{ paddingHorizontal: 24, flexDirection: "row", flexWrap: "wrap", gap: 10 }}>
              {GENDERS.map((g) => (
                <SelectChip key={g.label} label={g.label} emoji={g.emoji}
                  selected={gender === g.label}
                  onPress={() => { setGender(g.label); setTimeout(goNext, 200); }}
                />
              ))}
            </View>
          </ScrollView>
        )}

        {step === 3 && (
          <ScrollView contentContainerStyle={{ paddingBottom: insets.bottom + 32 }}>
            <StepHeader emoji="💫" title="Sexual orientation" subtitle="Private by default — you control visibility." />
            <View style={{ paddingHorizontal: 24, flexDirection: "row", flexWrap: "wrap", gap: 10 }}>
              {ORIENTATIONS.map((o) => (
                <SelectChip key={o.label} label={o.label} emoji={o.emoji}
                  selected={orientation === o.label}
                  onPress={() => { setOrientation(o.label); setTimeout(goNext, 200); }}
                  gradientColors={o.grad}
                />
              ))}
            </View>
          </ScrollView>
        )}

        {step === 4 && (
          <ScrollView contentContainerStyle={{ paddingBottom: insets.bottom + 32 }}>
            <StepHeader emoji="👀" title="Interested in…" subtitle="Select all that apply. Change anytime." />
            <View style={{ paddingHorizontal: 24, flexDirection: "row", flexWrap: "wrap", gap: 10, marginBottom: 24 }}>
              {INTERESTED_IN.map((item) => (
                <SelectChip key={item.label} label={item.label} emoji={item.emoji}
                  selected={interestedIn.includes(item.label)}
                  onPress={() => toggle(item.label, interestedIn, setInterested)}
                />
              ))}
            </View>
            <View style={{ paddingHorizontal: 24 }}>
              <PrimaryButton label="Continue" onPress={() => { if (interestedIn.length > 0) goNext(); }} disabled={interestedIn.length === 0} icon="→" />
            </View>
          </ScrollView>
        )}

        {step === 5 && (
          <ScrollView contentContainerStyle={{ paddingBottom: insets.bottom + 32 }}>
            <StepHeader emoji="💞" title="What are you looking for?" subtitle="Pick all that match — be honest, it helps!" />
            <View style={{ paddingHorizontal: 24, flexDirection: "row", flexWrap: "wrap", gap: 10, marginBottom: 24 }}>
              {RELATIONSHIP_TYPES.map((r) => (
                <SelectChip key={r.label} label={r.label} emoji={r.emoji}
                  selected={relTypes.includes(r.label)}
                  onPress={() => toggle(r.label, relTypes, setRelTypes)}
                  gradientColors={r.grad}
                />
              ))}
            </View>
            <View style={{ paddingHorizontal: 24 }}>
              <PrimaryButton label="Continue" onPress={() => { if (relTypes.length > 0) goNext(); }} disabled={relTypes.length === 0} icon="→" />
            </View>
          </ScrollView>
        )}

        {step === 6 && (
          <ScrollView contentContainerStyle={{ paddingBottom: insets.bottom + 32 }}>
            <StepHeader emoji="🗣️" title="Languages you speak" subtitle="We'll show people you can actually talk to." />
            <View style={{ paddingHorizontal: 24, flexDirection: "row", flexWrap: "wrap", gap: 10, marginBottom: 24 }}>
              {LANGUAGES.map((lang) => (
                <SelectChip key={lang.label} label={lang.label} emoji={lang.emoji}
                  selected={languages.includes(lang.label)}
                  onPress={() => toggle(lang.label, languages, setLanguages)}
                  gradientColors={[Colors.violet, Colors.sky]}
                />
              ))}
            </View>
            <View style={{ paddingHorizontal: 24 }}>
              <Text style={{ fontSize: 12, color: Colors.textMuted, marginBottom: 12, textAlign: "center" }}>{languages.length} selected</Text>
              <PrimaryButton label="Continue" onPress={() => { if (languages.length > 0) goNext(); }} disabled={languages.length === 0} icon="→" />
            </View>
          </ScrollView>
        )}

        {step === 7 && (
          <ScrollView contentContainerStyle={{ paddingBottom: insets.bottom + 32 }}>
            <StepHeader emoji="⭐" title="What are you into?" subtitle="Pick at least 3 — shown on your profile." />
            <View style={{ paddingHorizontal: 24, flexDirection: "row", flexWrap: "wrap", gap: 10, marginBottom: 24 }}>
              {INTERESTS.map((item) => (
                <SelectChip key={item.label} label={item.label} emoji={item.emoji}
                  selected={interests.includes(item.label)}
                  onPress={() => toggle(item.label, interests, setInterests)}
                  gradientColors={item.grad}
                />
              ))}
            </View>
            <View style={{ paddingHorizontal: 24 }}>
              <Text style={{ fontSize: 12, color: interests.length >= 3 ? Colors.primary : Colors.textMuted, marginBottom: 12, textAlign: "center", fontWeight: "600" }}>
                {interests.length} / 3 minimum selected
              </Text>
              <PrimaryButton label="Continue" onPress={() => { if (interests.length >= 3) goNext(); }} disabled={interests.length < 3} icon="→" />
            </View>
          </ScrollView>
        )}

        {step === 8 && (
          <ScrollView contentContainerStyle={{ paddingBottom: insets.bottom + 32 }}>
            <StepHeader emoji="🤳" title="Pick your avatar" subtitle="Choose an emoji for now — upload a real photo later." />

            <View style={{ alignItems: "center", marginBottom: 24 }}>
              {photoEmoji ? (
                <LinearGradient
                  colors={[Colors.primary, Colors.accent]}
                  start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
                  style={{ width: 110, height: 110, borderRadius: 55, alignItems: "center", justifyContent: "center", shadowColor: Colors.primary, shadowOffset: { width: 0, height: 8 }, shadowOpacity: 0.35, shadowRadius: 20, elevation: 10 }}
                >
                  <Text style={{ fontSize: 56 }}>{photoEmoji}</Text>
                </LinearGradient>
              ) : (
                <View style={{ width: 110, height: 110, borderRadius: 55, backgroundColor: Colors.card, borderWidth: 2, borderColor: Colors.border, borderStyle: "dashed", alignItems: "center", justifyContent: "center" }}>
                  <Text style={{ fontSize: 36, opacity: 0.3 }}>👤</Text>
                </View>
              )}
              {photoEmoji && (
                <Text style={{ fontSize: 14, color: Colors.textSecondary, marginTop: 10, fontWeight: "600" }}>Looking good! ✨</Text>
              )}
            </View>

            <View style={{ paddingHorizontal: 24, flexDirection: "row", flexWrap: "wrap", gap: 12, justifyContent: "center", marginBottom: 28 }}>
              {PHOTO_AVATARS.map((emoji) => (
                <Pressable
                  key={emoji}
                  onPress={() => setPhotoEmoji(emoji)}
                  style={({ pressed }) => ({ opacity: pressed ? 0.7 : 1, transform: [{ scale: pressed ? 0.92 : photoEmoji === emoji ? 1.1 : 1 }] })}
                >
                  {photoEmoji === emoji ? (
                    <LinearGradient colors={[Colors.primary, Colors.accent]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={{ width: 58, height: 58, borderRadius: 29, alignItems: "center", justifyContent: "center", shadowColor: Colors.primary, shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.3, shadowRadius: 8, elevation: 4 }}>
                      <Text style={{ fontSize: 30 }}>{emoji}</Text>
                    </LinearGradient>
                  ) : (
                    <View style={{ width: 58, height: 58, borderRadius: 29, backgroundColor: Colors.card, borderWidth: 1.5, borderColor: Colors.border, alignItems: "center", justifyContent: "center" }}>
                      <Text style={{ fontSize: 30 }}>{emoji}</Text>
                    </View>
                  )}
                </Pressable>
              ))}
            </View>

            <View style={{ paddingHorizontal: 24, gap: 12 }}>
              <PrimaryButton label="Complete Profile 🎉" onPress={handleFinish} disabled={!photoEmoji} />
              <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 6, padding: 14, borderRadius: 14, backgroundColor: Colors.card, borderWidth: 1, borderColor: Colors.border }}>
                <Text style={{ fontSize: 14 }}>📸</Text>
                <Text style={{ fontSize: 13, color: Colors.textSecondary }}>Upload real photos from your Profile page</Text>
              </View>
            </View>
          </ScrollView>
        )}
      </Animated.View>
    </KeyboardAvoidingView>
  );
}
